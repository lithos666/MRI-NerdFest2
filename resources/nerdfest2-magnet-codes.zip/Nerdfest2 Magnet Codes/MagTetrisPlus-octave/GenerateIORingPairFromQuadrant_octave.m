function [loc_all_list, angle_all, magnet_dim_all, Br_all] = ...
    GenerateIORingPairFromQuadrant_octave(n_bar, quadrant_loc, quadrant_dim, ...
    quadrant_angle, quadrant_Br, make_plots)
%GENERATEIORINGPAIRFROMQUADRANT_OCTAVE Build complete symmetric IOring layers.
%
% This is the GNU Octave companion to GenerateIORingPairFromQuadrant.m.
% Each input row describes an upper R-Z quadrant seed magnet. A positive-Z
% seed produces an upper and a symmetry-related lower ring.

    if nargin < 6 || isempty(make_plots)
        make_plots = true;
    end

    validateattributes(n_bar, {'numeric'}, ...
        {'scalar', 'real', 'finite', 'integer', '>=', 1}, ...
        mfilename, 'n_bar', 1);
    validateattributes(quadrant_loc, {'numeric'}, ...
        {'2d', 'real', 'finite', 'nonempty', 'ncols', 2}, ...
        mfilename, 'quadrant_loc', 2);
    validateattributes(quadrant_dim, {'numeric'}, ...
        {'2d', 'real', 'finite', 'nonempty', 'ncols', 3}, ...
        mfilename, 'quadrant_dim', 3);
    validateattributes(quadrant_angle, {'numeric'}, ...
        {'vector', 'real', 'finite', 'nonempty'}, ...
        mfilename, 'quadrant_angle', 4);
    validateattributes(quadrant_Br, {'numeric'}, ...
        {'vector', 'real', 'finite', 'nonempty'}, ...
        mfilename, 'quadrant_Br', 5);

    n_layer = size(quadrant_loc, 1);
    if size(quadrant_dim, 1) ~= n_layer || ...
            numel(quadrant_angle) ~= n_layer || numel(quadrant_Br) ~= n_layer
        error('GenerateIORingPairFromQuadrant_octave:InputSizeMismatch', ...
            ['quadrant_loc, quadrant_dim, quadrant_angle, and quadrant_Br ', ...
             'must describe the same number of seed magnets.']);
    end

    quadrant_angle = quadrant_angle(:);
    quadrant_Br = quadrant_Br(:);
    r_center = quadrant_loc(:, 1);
    z_center = quadrant_loc(:, 2);
    dim_x = quadrant_dim(:, 1);
    dim_y = quadrant_dim(:, 2);
    dim_z = quadrant_dim(:, 3);
    angle = mod(quadrant_angle, 360);

    if any(r_center <= 0)
        error('GenerateIORingPairFromQuadrant_octave:InvalidRadius', ...
            'Every r_center_mm value must be greater than zero.');
    end
    if any(z_center < 0)
        error('GenerateIORingPairFromQuadrant_octave:InvalidZ', ...
            'The input must describe the Z >= 0 quadrant.');
    end
    if any(dim_x <= 0 | dim_y <= 0 | dim_z <= 0)
        error('GenerateIORingPairFromQuadrant_octave:InvalidDimensions', ...
            'All cuboid dimensions must be greater than zero.');
    end
    if any(quadrant_Br < 0)
        error('GenerateIORingPairFromQuadrant_octave:InvalidRemanence', ...
            'Remanence values must be nonnegative; use angle for direction.');
    end

    mirror_tol_mm = 1e-9;
    rings_per_layer = 1 + (z_center > mirror_tol_mm);
    n_total = n_bar * sum(rings_per_layer);
    loc_all_list = zeros(n_total, 3);
    angle_all = zeros(n_total, 3);
    magnet_dim_all = zeros(n_total, 3);
    Br_all = zeros(1, n_total);

    theta = -90 + (0:n_bar-1).' * (360 / n_bar);
    yaw = theta + 90;
    next_index = 1;

    for layer_index = 1:n_layer
        local_dims = [dim_x(layer_index), dim_y(layer_index), dim_z(layer_index)];
        xy = [r_center(layer_index) * cosd(theta), ...
              r_center(layer_index) * sind(theta)];

        upper_indices = next_index:(next_index + n_bar - 1);
        loc_all_list(upper_indices, :) = [xy, ...
            repmat(z_center(layer_index), n_bar, 1)];
        angle_all(upper_indices, :) = [yaw, zeros(n_bar, 1), ...
            repmat(angle(layer_index), n_bar, 1)];
        magnet_dim_all(upper_indices, :) = repmat(local_dims, n_bar, 1);
        Br_all(upper_indices) = quadrant_Br(layer_index);
        next_index = next_index + n_bar;

        if z_center(layer_index) > mirror_tol_mm
            lower_angle = mod(180 - angle(layer_index), 360);
            lower_indices = next_index:(next_index + n_bar - 1);
            loc_all_list(lower_indices, :) = [xy, ...
                repmat(-z_center(layer_index), n_bar, 1)];
            angle_all(lower_indices, :) = [yaw, zeros(n_bar, 1), ...
                repmat(lower_angle, n_bar, 1)];
            magnet_dim_all(lower_indices, :) = repmat(local_dims, n_bar, 1);
            Br_all(lower_indices) = quadrant_Br(layer_index);
            next_index = next_index + n_bar;
        end
    end

    assert_no_overlapping_magnets(loc_all_list, angle_all, magnet_dim_all);

    if make_plots
        plot_input_footprints(quadrant_loc, quadrant_dim, quadrant_angle);
    end
end


function assert_no_overlapping_magnets(centers, angles, dimensions)
% Check every generated pair using the separating-axis theorem for OBBs.
    n_magnet = size(centers, 1);
    half_dimensions = dimensions / 2;
    bounding_radius = sqrt(sum(half_dimensions.^2, 2));
    box_axes = magnet_box_axes(angles);
    overlap_tol_mm = 1e-9;

    for first_index = 1:(n_magnet - 1)
        other_indices = (first_index + 1):n_magnet;
        center_delta = centers(other_indices, :) - centers(first_index, :);
        center_distance_squared = sum(center_delta.^2, 2);
        radius_sum = bounding_radius(first_index) + ...
            bounding_radius(other_indices);
        possible_overlap = other_indices( ...
            center_distance_squared < radius_sum.^2);

        for second_index = possible_overlap
            if oriented_boxes_overlap( ...
                    centers(first_index, :), ...
                    squeeze(box_axes(first_index, :, :)), ...
                    half_dimensions(first_index, :), ...
                    centers(second_index, :), ...
                    squeeze(box_axes(second_index, :, :)), ...
                    half_dimensions(second_index, :), overlap_tol_mm)
                error('GenerateIORingPairFromQuadrant_octave:OverlappingMagnets', ...
                    ['Generated magnets %d and %d overlap. Centers: ', ...
                     '[%.6g, %.6g, %.6g] and [%.6g, %.6g, %.6g] mm.'], ...
                    first_index, second_index, centers(first_index, :), ...
                    centers(second_index, :));
            end
        end
    end
end


function box_axes = magnet_box_axes(angles)
% Return each magnet's three local unit axes as columns of a 3-by-3 matrix.
    yaw = angles(:, 1);
    roll_angle = angles(:, 3);
    n_magnet = size(angles, 1);
    local_x = [cosd(yaw), sind(yaw), zeros(n_magnet, 1)];
    yawed_y = [-sind(yaw), cosd(yaw), zeros(n_magnet, 1)];
    global_z = repmat([0, 0, 1], n_magnet, 1);
    local_y = cosd(roll_angle) .* yawed_y + sind(roll_angle) .* global_z;
    local_z = -sind(roll_angle) .* yawed_y + cosd(roll_angle) .* global_z;
    box_axes = zeros(n_magnet, 3, 3);
    box_axes(:, :, 1) = local_x;
    box_axes(:, :, 2) = local_y;
    box_axes(:, :, 3) = local_z;
end


function overlaps = oriented_boxes_overlap( ...
        center_a, axes_a, half_dimensions_a, ...
        center_b, axes_b, half_dimensions_b, overlap_tol_mm)
% Test the 15 candidate separating axes of two oriented cuboids.
    candidate_axes = [axes_a, axes_b, zeros(3, 9)];
    next_axis = 7;
    for axis_a = 1:3
        for axis_b = 1:3
            candidate_axes(:, next_axis) = cross( ...
                axes_a(:, axis_a), axes_b(:, axis_b));
            next_axis = next_axis + 1;
        end
    end

    center_delta = (center_b - center_a).';
    overlaps = true;
    for axis_index = 1:size(candidate_axes, 2)
        separating_axis = candidate_axes(:, axis_index);
        axis_length = norm(separating_axis);
        if axis_length < 1e-12
            continue;
        end
        separating_axis = separating_axis / axis_length;
        radius_a = sum(half_dimensions_a(:) .* ...
            abs(axes_a.' * separating_axis));
        radius_b = sum(half_dimensions_b(:) .* ...
            abs(axes_b.' * separating_axis));
        center_separation = abs(dot(center_delta, separating_axis));
        if radius_a + radius_b - center_separation <= overlap_tol_mm
            overlaps = false;
            return;
        end
    end
end


function plot_input_footprints(quadrant_loc, quadrant_dim, quadrant_angle)
% Draw the upper input quadrant and the complete R >= 0 cross-section.
    % Use the same figure numbers as the MATLAB helper so field-map figures
    % 1-3 remain available to every Octave practice script.
    plot_one_footprint(9, quadrant_loc, quadrant_dim, quadrant_angle, ...
        'IOring input quadrant', true);

    mirror_rows = quadrant_loc(:, 2) > 1e-9;
    half_loc = [quadrant_loc; ...
        quadrant_loc(mirror_rows, 1), -quadrant_loc(mirror_rows, 2)];
    half_dim = [quadrant_dim; quadrant_dim(mirror_rows, :)];
    upper_angle = mod(quadrant_angle(:), 360);
    half_angle = [upper_angle; mod(180 - upper_angle(mirror_rows), 360)];
    plot_one_footprint(11, half_loc, half_dim, half_angle, ...
        'IOring half cross-section: two R-Z quadrants', false);
end


function plot_one_footprint(fig_num, locations, dimensions, angles, ...
        title_text, clamp_to_positive_z)
    r_center = locations(:, 1);
    z_center = locations(:, 2);
    dim_y = dimensions(:, 2);
    dim_z = dimensions(:, 3);
    angles = mod(angles(:), 360);
    [r_corners, z_corners] = all_quadrant_corners( ...
        r_center, z_center, dim_y, dim_z, angles);

    margin_mm = max(0.08 * max([dim_y; dim_z]), 5);
    r_min = max(0, min(r_corners(:)) - margin_mm);
    r_max = max(r_corners(:)) + margin_mm;
    z_min = min(z_corners(:)) - margin_mm;
    if clamp_to_positive_z
        z_min = min(0, z_min);
    end
    z_max = max(z_corners(:)) + margin_mm;

    % Use a large window because these layouts are much taller than wide.
    % The axes below retain a true 1:1 R-to-Z scale so square magnets remain
    % square rather than being stretched horizontally.
    hfig = figure(fig_num, 'Visible', 'on', ...
        'Position', [80, 40, 960, 900], 'Color', 'w');
    clf(hfig, 'reset');
    set(hfig, 'Position', [80, 40, 960, 900], 'Color', 'w');
    hax = axes('Parent', hfig, 'Position', [0.12, 0.10, 0.82, 0.82]);
    hold(hax, 'on');
    for index = 1:size(locations, 1)
        plot(hax, [r_corners(index, :), r_corners(index, 1)], ...
            [z_corners(index, :), z_corners(index, 1)], ...
            'k-', 'LineWidth', 1.0);
        unit_r = -cosd(angles(index));
        unit_z = sind(angles(index));
        arrow_length = 0.72 * dim_y(index);
        tail_offset = 0.40 * dim_y(index);
        quiver(hax, ...
            r_center(index) - tail_offset * unit_r, ...
            z_center(index) - tail_offset * unit_z, ...
            arrow_length * unit_r, arrow_length * unit_z, 0, ...
            'Color', [0.05, 0.20, 0.75], ...
            'LineWidth', 1.4, 'MaxHeadSize', 0.55);
    end
    plot(hax, [r_min, r_max], [0, 0], '--k', 'LineWidth', 1);
    grid(hax, 'on');
    box(hax, 'on');
    xlim(hax, [r_min, r_max]);
    ylim(hax, [z_min, z_max]);
    axis(hax, 'equal');

    tick_step_mm = 25;
    first_tick = ceil(r_min / tick_step_mm) * tick_step_mm;
    last_tick = floor(r_max / tick_step_mm) * tick_step_mm;
    if first_tick <= last_tick
        set(hax, 'XTick', first_tick:tick_step_mm:last_tick);
    end
    xlabel(hax, 'R / mm');
    ylabel(hax, 'Z / mm');
    title(hax, title_text);
    set(hax, 'FontSize', 13, 'LineWidth', 1, 'Layer', 'top');
end


function [r_corners, z_corners] = all_quadrant_corners( ...
        r_center, z_center, dim_y, dim_z, angles)
    n_magnet = numel(r_center);
    r_corners = zeros(n_magnet, 4);
    z_corners = zeros(n_magnet, 4);
    signs = [-1, -1; 1, -1; 1, 1; -1, 1];
    for index = 1:n_magnet
        local_y_rz = [-cosd(angles(index)), sind(angles(index))];
        local_z_rz = [sind(angles(index)), cosd(angles(index))];
        center = [r_center(index), z_center(index)];
        for corner_index = 1:4
            corner = center + ...
                signs(corner_index, 1) * dim_y(index) / 2 * local_y_rz + ...
                signs(corner_index, 2) * dim_z(index) / 2 * local_z_rz;
            r_corners(index, corner_index) = corner(1);
            z_corners(index, corner_index) = corner(2);
        end
    end
end
