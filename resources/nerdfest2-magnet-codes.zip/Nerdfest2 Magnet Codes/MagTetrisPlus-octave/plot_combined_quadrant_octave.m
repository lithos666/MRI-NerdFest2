function plot_combined_quadrant_octave( ...
        main_loc, main_angle, main_dim, shim_loc, shim_angle, shim_dim)
%PLOT_COMBINED_QUADRANT_OCTAVE Plot main and shim quadrant seeds together.
% This is a separate function file so it is visible when called from an
% Octave script, including Octave versions that execute scripts sequentially.

    loc = [main_loc; shim_loc];
    angle = [main_angle(:); shim_angle(:)];
    dim = [ ...
        repmat(main_dim, size(main_loc, 1), 1); ...
        repmat(shim_dim, size(shim_loc, 1), 1)];

    if isempty(loc)
        return;
    end

    plot_combined_rz_footprint_octave( ...
        9, loc, angle, dim, ...
        'IOring input quadrant: main and shim magnets', true);

    mirror_rows = loc(:, 2) > 1e-9;
    half_loc = [ ...
        loc; ...
        loc(mirror_rows, 1), -loc(mirror_rows, 2)];
    half_angle = [ ...
        angle; ...
        mod(180 - angle(mirror_rows), 360)];
    half_dim = [dim; dim(mirror_rows, :)];

    plot_combined_rz_footprint_octave( ...
        11, half_loc, half_angle, half_dim, ...
        'IOring half cross-section: main and shim magnets', false);
end


function plot_combined_rz_footprint_octave( ...
        figure_number, loc, angle, dim, title_text, clamp_to_positive_z)
    n_magnet = size(loc, 1);
    r_corners = zeros(n_magnet, 4);
    z_corners = zeros(n_magnet, 4);
    corner_signs = [-1, -1; 1, -1; 1, 1; -1, 1];

    for magnet_index = 1:n_magnet
        local_y_rz = [ ...
            -cosd(angle(magnet_index)), sind(angle(magnet_index))];
        local_z_rz = [ ...
            sind(angle(magnet_index)), cosd(angle(magnet_index))];
        center = loc(magnet_index, :);

        for corner_index = 1:4
            corner = center + ...
                corner_signs(corner_index, 1) * ...
                dim(magnet_index, 2) / 2 * local_y_rz + ...
                corner_signs(corner_index, 2) * ...
                dim(magnet_index, 3) / 2 * local_z_rz;
            r_corners(magnet_index, corner_index) = corner(1);
            z_corners(magnet_index, corner_index) = corner(2);
        end
    end

    dimension_values = dim(:, 2:3);
    margin_mm = max(0.08 * max(dimension_values(:)), 5);
    r_min = max(0, min(r_corners(:)) - margin_mm);
    r_max = max(r_corners(:)) + margin_mm;
    z_min = min(z_corners(:)) - margin_mm;
    if clamp_to_positive_z
        z_min = min(0, z_min);
    end
    z_max = max(z_corners(:)) + margin_mm;

    hfig = figure(figure_number, 'Visible', 'on', ...
        'Position', [80, 40, 960, 900], 'Color', 'w');
    clf(hfig, 'reset');
    set(hfig, 'Position', [80, 40, 960, 900], 'Color', 'w');
    hax = axes('Parent', hfig, 'Position', [0.12, 0.10, 0.82, 0.82]);
    hold(hax, 'on');

    for magnet_index = 1:n_magnet
        plot(hax, ...
            [r_corners(magnet_index, :), r_corners(magnet_index, 1)], ...
            [z_corners(magnet_index, :), z_corners(magnet_index, 1)], ...
            'k-', 'LineWidth', 1.8);

        unit_r = -cosd(angle(magnet_index));
        unit_z = sind(angle(magnet_index));
        arrow_length = 0.72 * dim(magnet_index, 2);
        tail_offset = 0.40 * dim(magnet_index, 2);
        quiver(hax, ...
            loc(magnet_index, 1) - tail_offset * unit_r, ...
            loc(magnet_index, 2) - tail_offset * unit_z, ...
            arrow_length * unit_r, arrow_length * unit_z, 0, ...
            'Color', [0, 0, 0], 'LineWidth', 2, 'MaxHeadSize', 0.55);
    end

    plot(hax, [r_min, r_max], [0, 0], '--k', 'LineWidth', 1);
    grid(hax, 'on');
    box(hax, 'on');
    xlim(hax, [r_min, r_max]);
    ylim(hax, [z_min, z_max]);
    axis(hax, 'equal');
    xlabel(hax, 'R / mm');
    ylabel(hax, 'Z / mm');
    title(hax, title_text);
    set(hax, 'FontSize', 12, 'LineWidth', 1, 'Layer', 'top');
end
