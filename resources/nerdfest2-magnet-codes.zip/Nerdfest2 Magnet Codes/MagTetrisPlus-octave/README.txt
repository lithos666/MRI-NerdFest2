GNU OCTAVE VERSION - NERDFEST2 MAGNET CODES
===========================================

SOFTWARE: These files are intended for GNU Octave. Run the scripts from
this folder so the Octave-compatible helpers and graphics configuration are
available. For MathWorks MATLAB, use the companion files in the
MagTetrisPlus-MATLAB folder.

This folder contains the GNU Octave version of the magnetostatic simulation
toolkit for modelling permanent-magnet arrays, induced magnetization in
ferromagnetic objects, and symmetric IOring field configurations.


MAIN SCRIPTS
============

File                                      Purpose
----------------------------------------  ----------------------------------------------------
GenerateSmallIORing_32mT_octave.m         Builds and evaluates the 32 mT small-IOring reference
                                          design. It expands 27 upper-quadrant seed locations
                                          into 756 total 10 mm cuboid magnets arranged as 14
                                          magnets per ring. 

GenerateIORing_37mT_octave.m              Builds and evaluates the larger 37 mT reference design.
                                          It expands 31 seed locations into 1,736 total 12 mm
                                          cuboid magnets arranged as 28 magnets per ring. 

Magnet_FieldPractice_octave.m             Configurable single- or multi-cuboid practice script.
                                          It calculates Bx, By, and Bz on an observation plane,
                                          prints each magnet's geometry and magnetization
                                          direction, plots all three signed field components in
                                          one figure, and creates a separate rotatable 3-D
                                          geometry/magnetization display.

Generate_IORing_ShimPractice_octave.m     IOring shimming exercise with 12 mm main magnets and
                                          10 mm shim magnets. It checks design constraints,
                                          builds the main and shim arrays, calculates five-slice
                                          Bz fields, and shows the main-only, shim-only, and
                                          final summed field maps together with their mean,
                                          minimum, maximum, and peak-to-peak homogeneity
                                          metrics. It also displays both magnet groups in 3-D
                                          using different colours.

ferro_cal_application.m                   Example MagTetris+ workflow for GNU Octave. It combines
                                          a permanent-magnet array with configurable
                                          ferromagnetic objects, solves their induced
                                          magnetization, calculates Bx/By/Bz maps, and displays
                                          the equivalent magnets and field plane.


IORING GEOMETRY FUNCTION
========================

File                                      Purpose
----------------------------------------  ----------------------------------------------------
GenerateIORingPairFromQuadrant_octave.m   Expands an upper radial/axial seed layout into complete
                                          upper and symmetry-related lower rings. Each seed may
                                          have its own position, dimensions, magnetization angle,
                                          and remanence. The function validates inputs, rejects
                                          positive-volume cuboid overlaps, and can plot the input
                                          geometry footprints. 


CORE SIMULATION AND FERROMAGNETIC FUNCTIONS
===========================================

File                                      Purpose
----------------------------------------  ----------------------------------------------------
MagTetris.m                               Main simulation class. Stores cuboid and fan-shaped
                                          magnets; rotates and combines arrays; evaluates fields
                                          on regular planes or arbitrary 3-D points; estimates
                                          forces; converts fan geometry into numerical
                                          approximations; and calculates total magnet weight.

MagTetrisPlus.m                           High-level ferromagnetic wrapper. Discretizes each
                                          supplied ferromagnetic object, solves its induced
                                          remanence, and returns the result as equivalent cuboid
                                          magnets in a second MagTetris object.

PrepareFerromagneticDomains.m             Classifies ferromagnetic objects as plate-, rod-, or
                                          cube-like and divides them into smaller cuboid
                                          calculation domains.

FerroCalculation.m                       Iteratively solves induced domain magnetization using
                                          the initial iron magnetization curve, demagnetization,
                                          mutual coupling, damping, anisotropy approximations,
                                          and saturation.

ComputeDemagnetization.m                  Calculates approximate cuboid demagnetization factors
                                          or effective local demagnetization tensors for
                                          discretized ferromagnetic domains.

Br3D2Cuboid.m                             Decomposes each arbitrary 3-D remanence vector into as
                                          many as three co-located, axis-aligned equivalent
                                          cuboid magnets.

RotationUtils.m                           Provides shared yaw-pitch-roll rotation matrices, vector
                                          rotation, and rotation-matrix-to-angle conversion
                                          utilities.


OCTAVE GRAPHICS FUNCTIONS
=========================

File                                      Purpose
----------------------------------------  ----------------------------------------------------
ConfigureOctaveGraphics.m                 Makes figures visible and selects an available Octave
                                          graphics toolkit, preferring gnuplot and falling back
                                          to Qt or FLTK.

PlotFieldMap.m                            Plots a 2-D field component with Octave-safe imagesc
                                          rendering, explicit NaN transparency, labelled axes,
                                          and an mT colourbar. It can create a standalone figure
                                          or draw into supplied axes for multi-panel layouts.

DrawMagnetization.m                       Draws batched line-based cuboid outlines, black
                                          magnetization-direction arrows, and optional field
                                          contours in a rotatable 3-D figure. Its optional
                                          reset_figure argument permits differently coloured
                                          magnet groups to be overlaid safely.


DISPLAY AND DATA CONVENTIONS
============================

- Geometry and locations are expressed in millimetres.
- Magnetic field and remanence values are expressed in tesla unless a
  script explicitly converts them to millitesla for reporting or display.
- An unrotated cuboid magnet is polarized along its local +Y direction.
- Orientations use yaw, pitch, and roll angles in degrees.