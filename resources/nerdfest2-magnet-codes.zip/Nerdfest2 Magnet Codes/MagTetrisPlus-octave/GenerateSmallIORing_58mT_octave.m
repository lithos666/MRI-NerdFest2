clear;
close all;
tic;
% Generate and evaluate the 32 mT small IOring reference geometry.
% This GNU Octave version is intended to be run from MagTetrisPlus-octave.

script_dir = fileparts(mfilename('fullpath'));
if isempty(script_dir)
    script_dir = pwd;
end
addpath(script_dir);

draw_3d = true;

FOV_half = 10;
slice_offsets_mm = [-2, -1, 0, 1, 2];
make_plots = true;
ConfigureOctaveGraphics();

FOV_half_1 = FOV_half;
FOV_1 = -FOV_half_1:1:FOV_half_1;
FOV_half_2 = FOV_half;
FOV_2 = -FOV_half_2:1:FOV_half_2;
FOV_3 = 0;
surface_name = 'z';
n_per_group = 1;
font_size = 18;
n_bar = 14;

% The same row number across these four arrays describes one seed magnet.
%   quadrant_loc   : [R, Z] in mm
%   quadrant_dim   : local [dim_x, dim_y, dim_z] in mm
%   quadrant_angle : magnetization angle in the R-Z plane, in degrees
%   quadrant_Br    : remanence in T
%
% GenerateIORingPairFromQuadrant_octave creates each complete upper ring
% and its IOring-symmetric lower ring automatically.

% Seed center coordinates: radial position R and axial position Z [mm].
quadrant_loc = [ ...
    100, 169; ...
     90, 169; ...
     80, 169; ...
     70, 169; ...
     60, 169; ...
    100, 143; ...
     90, 143; ...
     80, 143; ...
     70, 143; ...
     60, 143; ...
    100, 117; ...
     90, 117; ...
     80, 117; ...
     70, 117; ...
     60, 117; ...
    100,  91; ...
     90,  91; ...
     80,  91; ...
     70,  91; ...
     60,  91; ...
     92,  65; ...
     82,  65; ...
     63,  65; ...
     94,  39; ...
     77,  39; ...
     60,  39; ...
     99,  13; ...
     89,  13; ...
     79,  13; ...
     60,  13];

quadrant_angle = [ ...
    180 * ones(24, 1); ...
      0; ...
    270; ...
    180 * ones(3, 1); ...
    270];

quadrant_dim = repmat([10, 10, 10], size(quadrant_loc, 1), 1);
quadrant_Br = 1.43 * ones(size(quadrant_loc, 1), 1);

[loc_all_list, angle_all, magnet_dim_all, Br_all] = ...
    GenerateIORingPairFromQuadrant_octave( ...
        n_bar, quadrant_loc, quadrant_dim, quadrant_angle, quadrant_Br, ...
        make_plots);

% Basic geometry checks.
n_expected = n_bar * sum(1 + (quadrant_loc(:, 2) > 1e-9));
assert(size(loc_all_list, 1) == n_expected, ...
    'Expected %d magnets, but generated %d.', n_expected, size(loc_all_list, 1));
assert(isequal(size(angle_all), [n_expected, 3]), 'Unexpected angle_all size.');
assert(isequal(size(magnet_dim_all), [n_expected, 3]), ...
    'Unexpected magnet_dim_all size.');
assert(isequal(size(Br_all), [1, n_expected]), 'Unexpected Br_all size.');

generated_radius = hypot(loc_all_list(:, 1), loc_all_list(:, 2));
for layer_index = 1:size(quadrant_loc, 1)
    layer_radius = quadrant_loc(layer_index, 1);
    layer_z = quadrant_loc(layer_index, 2);
    layer_mask = abs(generated_radius - layer_radius) < 1e-9;

    assert(sum(layer_mask & abs(loc_all_list(:, 3) - layer_z) < 1e-9) == n_bar, ...
        'Upper ring %d does not contain n_bar magnets.', layer_index);
    if layer_z > 1e-9
        assert(sum(layer_mask & abs(loc_all_list(:, 3) + layer_z) < 1e-9) == n_bar, ...
            'Lower ring %d does not contain n_bar magnets.', layer_index);
    end
end
assert(all(Br_all >= 0), 'Generated remanence values must be nonnegative.');

fprintf('Geometry checks passed.\n');
fprintf('Quadrant seed magnets       : %d\n', size(quadrant_loc, 1));
fprintf('Total generated magnets     : %d\n', size(loc_all_list, 1));

% Create the MagTetris object and calculate five planes around the center.
% Homogeneity uses every finite sample in the full masked 3-D Bz stack;
% the corresponding-pixel average is retained for plotting.
IOring_MT = MagTetris().AssignCuboid( ...
    loc_all_list, angle_all, Br_all, magnet_dim_all);

% Calculate the five parallel Z planes inline. This matches the MATLAB
% averaged_field2d helper while remaining compatible with Octave versions
% that do not reliably resolve local functions below executable scripts.
n_slice = numel(slice_offsets_mm);
assert(n_slice > 0, 'slice_offsets_mm cannot be empty.');
[Bx_slice, By_slice, Bz_slice] = IOring_MT.Field2D( ...
    FOV_1, FOV_2, slice_offsets_mm(1), 'z', n_per_group);
stack_size = [size(Bz_slice), n_slice];
Bx_slices = zeros(stack_size);
By_slices = zeros(stack_size);
Bz_slices = zeros(stack_size);
Bx_slices(:, :, 1) = Bx_slice;
By_slices(:, :, 1) = By_slice;
Bz_slices(:, :, 1) = Bz_slice;
for slice_index = 2:n_slice
    [Bx_slices(:, :, slice_index), ...
        By_slices(:, :, slice_index), ...
        Bz_slices(:, :, slice_index)] = IOring_MT.Field2D( ...
            FOV_1, FOV_2, slice_offsets_mm(slice_index), 'z', n_per_group);
end
Bx = mean(Bx_slices, 3);
By = mean(By_slices, 3);
Bz = mean(Bz_slices, 3);

% Keep only the circular FoV.
[FOV_x, FOV_y] = meshgrid(FOV_1, FOV_2);
outside_FOV = hypot(FOV_x, FOV_y) > FOV_half_1;
Bx(outside_FOV) = NaN;
By(outside_FOV) = NaN;
Bz(outside_FOV) = NaN;

% Convert tesla to millitesla and apply the identical mask to every slice.
Bx = Bx * 1e3;
By = By * 1e3;
Bz = Bz * 1e3;
Bx_slices = Bx_slices * 1e3;
By_slices = By_slices * 1e3;
Bz_slices = Bz_slices * 1e3;
for slice_index = 1:n_slice
    Bx_slice = Bx_slices(:, :, slice_index);
    By_slice = By_slices(:, :, slice_index);
    Bz_slice = Bz_slices(:, :, slice_index);
    Bx_slice(outside_FOV) = NaN;
    By_slice(outside_FOV) = NaN;
    Bz_slice(outside_FOV) = NaN;
    Bx_slices(:, :, slice_index) = Bx_slice;
    By_slices(:, :, slice_index) = By_slice;
    Bz_slices(:, :, slice_index) = Bz_slice;
end

% Calculate the same full-stack homogeneity metrics as the MATLAB script.
B_valid = Bz_slices(isfinite(Bz_slices));
if isempty(B_valid)
    error('Bmap contains no valid finite values.');
end
B0_ref = mean(B_valid);
if B0_ref == 0
    error('B0_ref cannot be zero.');
end
metrics = struct();
metrics.B0_ref = B0_ref;
metrics.Bmax = max(B_valid);
metrics.Bmin = min(B_valid);
metrics.Bmean = mean(B_valid);
metrics.Bstd = std(B_valid);
metrics.deltaB_pp = metrics.Bmax - metrics.Bmin;
metrics.hom_ppm_pp = metrics.deltaB_pp / abs(B0_ref) * 1e6;
metrics.hom_ppm_std = metrics.Bstd / abs(B0_ref) * 1e6;

fprintf('3-D stack slice Z values    : %s mm\n', mat2str(slice_offsets_mm));
fprintf('Mean Bz                     : %.6f mT\n', metrics.Bmean);
fprintf('Max Bz                     : %.6f mT\n', metrics.Bmax);
fprintf('Min Bz                     : %.6f mT\n', metrics.Bmin);
fprintf('Peak-to-peak homogeneity    : %.6f ppm\n', metrics.hom_ppm_pp);
fprintf('Standard-deviation homogeneity: %.6f ppm\n\n', metrics.hom_ppm_std);

if make_plots
    % Apply a display-only 0.1 mT deadband. Bz and all metrics remain
    % unchanged.
    Bz_plot = Bz;
    Bz_plot(abs(Bz_plot) < 0.1) = 0;

    plot_title = sprintf( ...
        'Average Bz map', ...
        metrics.hom_ppm_pp, metrics.Bmean);
    finite_Bz = Bz_plot(isfinite(Bz_plot));
    PlotFieldMap(1, FOV_1, FOV_2, Bz_plot, surface_name, plot_title, ...
        [min(finite_Bz), max(finite_Bz)], font_size, true);

    if draw_3d
        DrawMagnetization(loc_all_list, angle_all, magnet_dim_all, ...
            [0.85, 0.10, 0.10], FOV_1, FOV_2, FOV_3, ...
            surface_name, Bz_plot);
    end
end

toc;
