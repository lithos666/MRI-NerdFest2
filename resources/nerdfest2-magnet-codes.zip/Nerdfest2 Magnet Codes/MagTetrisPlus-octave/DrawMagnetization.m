function DrawMagnetization(loc_all, angle_all, magnet_dim_all, color_value, FOV_1, FOV_2, FOV_3, surface_name, B_field, reset_figure)
%DRAWMAGNETIZATION Draw magnet geometry and an optional field contour map.
%
% The Octave renderer always uses the rotatable safe rendering path:
% batched line-based cuboids and line-based field contours. No render-mode
% input is required.
% reset_figure:
%   true  - clear Figure 10 and create a new 3-D axes (default).
%   false - add another magnet group to the existing 3-D axes. This is
%           used to display main and shim magnets in different colors.

if nargin < 10 || isempty(reset_figure)
    reset_figure = true;
end

hfig = figure(100, 'Visible', 'on');
if reset_figure
    % Keep the established Figure 10 creation path. Switching the global
    % default toolkit before creating this figure can prevent it from
    % appearing on some Windows Octave installations.
    try
        graphics_toolkit(hfig, 'fltk');
    catch
        try
            graphics_toolkit(hfig, 'qt');
        catch
            % Use the figure's existing toolkit when neither GUI toolkit
            % is available.
        end
    end
    clf(hfig, 'reset');
    set(hfig, 'Visible', 'on', 'Color', 'w');
    hax = axes('Parent', hfig, 'Tag', 'MagTetris3DAxes');
else
    hax = findobj(hfig, 'Type', 'axes', 'Tag', 'MagTetris3DAxes');
    if isempty(hax)
        hax = axes('Parent', hfig, 'Tag', 'MagTetris3DAxes');
    else
        hax = hax(1);
    end
end
hold(hax, 'on');
view(hax, 3);
axis(hax, 'equal');
grid(hax, 'on');
box(hax, 'on');
xlabel(hax, 'X [mm]');
ylabel(hax, 'Y [mm]');
zlabel(hax, 'Z [mm]');
title(hax, '3D Visualization of Magnets');

% Draw all magnet outlines in one line object to keep large rings responsive.
DrawCuboidsSafeBatch(loc_all, angle_all, magnet_dim_all, color_value, hax);

% Magnetization direction vectors.
dir_vectors = zeros(size(loc_all));
for idx = 1:size(loc_all, 1)
    R_yaw = [cosd(angle_all(idx,1)), -sind(angle_all(idx,1)), 0; ...
             sind(angle_all(idx,1)),  cosd(angle_all(idx,1)), 0; ...
             0,                       0,                      1];
    R_pitch = [ cosd(angle_all(idx,2)), 0, sind(angle_all(idx,2)); ...
                0,                      1, 0; ...
               -sind(angle_all(idx,2)), 0, cosd(angle_all(idx,2))];
    R_roll = [1, 0,                       0; ...
              0, cosd(angle_all(idx,3)), -sind(angle_all(idx,3)); ...
              0, sind(angle_all(idx,3)),  cosd(angle_all(idx,3))];
    dir_vector = R_yaw * R_pitch * R_roll * [0; 1; 0];
    dir_vectors(idx, :) = dir_vector.';
end

scale_factor = 2 * magnet_dim_all(:,2);
scaled_dir_vectors = dir_vectors .* scale_factor;
new_start_points = loc_all - 0.5 * scaled_dir_vectors;

hquiver = quiver3(hax, new_start_points(:,1), new_start_points(:,2), new_start_points(:,3), ...
    scaled_dir_vectors(:,1), scaled_dir_vectors(:,2), scaled_dir_vectors(:,3), ...
    0, 'Color', 'k', 'LineWidth', 1.2);
DisableHitTesting(hquiver);

% Optional field visualization.
if nargin >= 9 && ~isempty(B_field)
    DrawFieldContoursSafe(hax, FOV_1, FOV_2, FOV_3, surface_name, B_field);
end

axis(hax, 'vis3d');
drawnow('expose');

% Restore the data axes and enable rotation. Keep interaction setup
% non-fatal so Figure 10 remains visible even on older Octave versions with
% a more limited rotate3d implementation.
try
    set(hfig, 'CurrentAxes', hax);
    pan(hfig, 'off');
    zoom(hfig, 'off');
    rotate3d(hfig, 'off');
    rotate3d(hfig, 'on');
catch
    try
        figure(hfig);
        axes(hax);
        rotate3d on;
    catch
        warning('DrawMagnetization:RotationUnavailable', ...
            'Figure 10 opened, but interactive rotation could not be enabled.');
    end
end
drawnow('expose');
end

function DrawCuboidsSafeBatch(loc_all, angle_all, magnet_dim_all, color_value, hax)
% Draw all cuboid edges with a single NaN-separated line object.
[X, Y, Z] = meshgrid([-1, 1], [-1, 1], [-1, 1]);
base_vertices = [X(:), Y(:), Z(:)] .* 0.5;
faces = [1,2,4,3; 5,6,8,7; 1,5,7,3; ...
         2,6,8,4; 1,5,6,2; 3,7,8,4];

edge_pairs = zeros(0, 2);
for face_idx = 1:size(faces, 1)
    face = faces(face_idx, :);
    candidates = [face([1,2]); face([2,3]); ...
        face([3,4]); face([4,1])];
    edge_pairs = [edge_pairs; sort(candidates, 2)]; %#ok<AGROW>
end
edge_pairs = unique(edge_pairs, 'rows');

n_magnets = size(loc_all, 1);
n_edges = size(edge_pairs, 1);
points_per_magnet = n_edges * 3;
line_x = NaN(1, n_magnets * points_per_magnet);
line_y = NaN(1, n_magnets * points_per_magnet);
line_z = NaN(1, n_magnets * points_per_magnet);

for idx = 1:n_magnets
    angles = angle_all(idx, :);
    vertices = base_vertices .* magnet_dim_all(idx, :);
    R_yaw = [cosd(angles(1)), -sind(angles(1)), 0; ...
             sind(angles(1)),  cosd(angles(1)), 0; ...
             0,                0,               1];
    R_pitch = [ cosd(angles(2)), 0, sind(angles(2)); ...
                0,               1, 0; ...
               -sind(angles(2)), 0, cosd(angles(2))];
    R_roll = [1, 0,                0; ...
              0, cosd(angles(3)), -sind(angles(3)); ...
              0, sind(angles(3)),  cosd(angles(3))];
    vertices = ((R_yaw * R_pitch * R_roll) * vertices.').';
    vertices = vertices + loc_all(idx, :);

    first_point = (idx - 1) * points_per_magnet + 1;
    for edge_idx = 1:n_edges
        point_indices = first_point + (edge_idx - 1) * 3 + (0:2);
        edge_vertices = vertices(edge_pairs(edge_idx, :), :);
        line_x(point_indices) = [edge_vertices(:, 1).', NaN];
        line_y(point_indices) = [edge_vertices(:, 2).', NaN];
        line_z(point_indices) = [edge_vertices(:, 3).', NaN];
    end
end

hedges = plot3(hax, line_x, line_y, line_z, '-', ...
    'Color', color_value, 'LineWidth', 0.8);
DisableHitTesting(hedges);
end

function DrawFieldContoursSafe(hax, FOV_1, FOV_2, FOV_3, surface_name, B_field)
% Draw field contours as ordinary line objects on the observation plane.
x_values = linspace(min(FOV_1(:)), max(FOV_1(:)), size(B_field, 2));
y_values = linspace(min(FOV_2(:)), max(FOV_2(:)), size(B_field, 1));
finite_values = B_field(isfinite(B_field));
if isempty(finite_values)
    return;
end

vmin = min(finite_values);
vmax = max(finite_values);
if vmin == vmax
    levels = vmin;
else
    levels = linspace(vmin, vmax, 12);
end

C = contourc(x_values, y_values, B_field, levels);
map = jet(max(numel(levels), 2));
column = 1;
while column < size(C, 2)
    level = C(1, column);
    point_count = C(2, column);
    points = C(:, column+1:column+point_count);

    if vmax > vmin
        color_index = 1 + round((level-vmin)/(vmax-vmin) * (size(map,1)-1));
    else
        color_index = 1;
    end
    color_index = max(1, min(size(map, 1), color_index));
    line_color = map(color_index, :);

    switch lower(surface_name)
        case 'x'
            hcontour = plot3(hax, FOV_3*ones(1, point_count), ...
                points(1, :), points(2, :), ...
                'Color', line_color, 'LineWidth', 0.8);
        case 'y'
            hcontour = plot3(hax, points(1, :), ...
                FOV_3*ones(1, point_count), points(2, :), ...
                'Color', line_color, 'LineWidth', 0.8);
        case 'z'
            hcontour = plot3(hax, points(1, :), points(2, :), ...
                FOV_3*ones(1, point_count), ...
                'Color', line_color, 'LineWidth', 0.8);
        otherwise
            error('DrawMagnetization:InvalidSurface', ...
                'surface must be ''x'', ''y'', or ''z''.');
    end

    DisableHitTesting(hcontour);
    column = column + point_count + 1;
end
end

function DisableHitTesting(graphics_handle)
% Let mouse gestures reach the axes instead of being captured by objects.
try
    set(graphics_handle, 'HitTest', 'off');
catch
    % HitTest is not exposed by some older Octave graphics implementations.
end
end
