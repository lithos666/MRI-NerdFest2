function toolkit_name = ConfigureOctaveGraphics()
%CONFIGUREOCTAVEGRAPHICS Enable visible plotting and select a robust toolkit.
%
% MagTetris+ uses image, surface, patch, and 3-D graphics.  Some Windows
% OpenGL drivers can display normal line plots while leaving surface/patch
% objects blank.  For this reason the Octave port prefers gnuplot when it is
% installed, then falls back to qt and fltk. Filled magnet patches use
% triangular faces so they remain compatible with gnuplot.
%
% This function is harmless in MATLAB.

set(0, 'defaultfigurevisible', 'on');
toolkit_name = '';

if exist('OCTAVE_VERSION', 'builtin')
    toolkits = available_graphics_toolkits();

    % Prefer gnuplot for this application because it does not use the Qt or
    % FLTK OpenGL screen renderer.  Fall back to the native toolkits.
    preferred = {'gnuplot', 'qt', 'fltk'};

    for idx = 1:numel(preferred)
        if any(strcmp(toolkits, preferred{idx}))
            try
                graphics_toolkit(preferred{idx});
                toolkit_name = graphics_toolkit();
                break;
            catch
                % Try the next available toolkit.
            end
        end
    end

    if isempty(toolkit_name)
        if isempty(toolkits)
            warning('MagTetrisPlus:NoGraphicsToolkit', ...
                ['No GNU Octave graphics toolkit is available. ', ...
                 'Install/use the GNU Octave GUI build with Qt or gnuplot support.']);
        else
            toolkit_name = graphics_toolkit();
        end
    end
else
    toolkit_name = 'MATLAB graphics';
end
end
