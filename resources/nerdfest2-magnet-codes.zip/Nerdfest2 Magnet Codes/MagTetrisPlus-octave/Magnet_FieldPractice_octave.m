clear;
close all;
tic;
% Permanent-magnet field practice for GNU Octave.
% This follows the same script structure and plotting helpers as the
% Octave IOring examples.

script_dir = fileparts(mfilename('fullpath'));
if isempty(script_dir)
    script_dir = pwd;
end
addpath(script_dir);

draw_3d = true;
make_plots = true;
ConfigureOctaveGraphics();

%% Controls

magnet_dim = [12, 12, 12];       % [x, y, z] dimensions in mm
magnet_Br = [1.43];              % remanence in tesla
magnet_loc = [0, 40, 0];         % magnet center [x, y, z] in mm
magnet_angle = [0, 0, 0];        % [yaw, pitch, roll] in degrees

%% Observation plane

FOV_half_mm = 25;
FOV_x = -FOV_half_mm:1:FOV_half_mm;
FOV_y = -FOV_half_mm:1:FOV_half_mm;
FOV_z = 0;
surface_name = 'z';
n_per_group = 1;
font_size = 18;

n_magnets = size(magnet_loc, 1);

assert(size(magnet_loc, 2) == 3, ...
    'Each magnet_loc row must contain [x, y, z].');
assert(isequal(size(magnet_angle), [n_magnets, 3]), ...
    'magnet_angle must contain one [yaw, pitch, roll] row per magnet.');
assert(isequal(size(magnet_dim), [n_magnets, 3]), ...
    'magnet_dim must contain one [x, y, z] dimension row per magnet.');
assert(numel(magnet_Br) == n_magnets, ...
    'magnet_Br must contain one remanence value per magnet.');
assert(all(magnet_dim(:) > 0), 'All magnet dimensions must be positive.');
assert(all(magnet_Br(:) > 0), 'All magnet_Br values must be positive.');

%% Calculate the field

mt = MagTetris().AssignCuboid( ...
    magnet_loc, magnet_angle, magnet_Br, magnet_dim);

[Bx, By, Bz] = mt.Field2D( ...
    FOV_x, FOV_y, FOV_z, surface_name, n_per_group);

Bx_mT = 1e3 * Bx;
By_mT = 1e3 * By;
Bz_mT = 1e3 * Bz;

% Display-only copies suppress field magnitudes below 0.1 mT. The original
% Bx, By, Bz and their millitesla conversions remain unchanged.
Bx_plot_mT = Bx_mT;
By_plot_mT = By_mT;
Bz_plot_mT = Bz_mT;
Bx_plot_mT(abs(Bx_plot_mT) < 0.1) = 0;
By_plot_mT(abs(By_plot_mT) < 0.1) = 0;
Bz_plot_mT(abs(Bz_plot_mT) < 0.1) = 0;

magnetization_direction = zeros(n_magnets, 3);
for magnet_index = 1:n_magnets
    magnetization_direction(magnet_index, :) = RotationUtils.rotate3D( ...
        [0, 1, 0], magnet_angle(magnet_index, :), 1);
end

fprintf('\nNumber of cuboid magnets: %d\n', n_magnets);
for magnet_index = 1:n_magnets
    fprintf('\nMagnet %d\n', magnet_index);
    fprintf('  Dimensions [x y z]        : [%8.3f %8.3f %8.3f] mm\n', ...
        magnet_dim(magnet_index, :));
    fprintf('  Remanence                 : %8.3f T\n', ...
        magnet_Br(magnet_index));
    fprintf('  Centre [x y z]            : [%8.3f %8.3f %8.3f] mm\n', ...
        magnet_loc(magnet_index, :));
    fprintf('  Yaw, pitch, roll          : [%8.3f %8.3f %8.3f] deg\n', ...
        magnet_angle(magnet_index, :));
    fprintf('  Magnetization unit vector : [%8.4f %8.4f %8.4f]\n', ...
        magnetization_direction(magnet_index, :));
end

%% Plot all three signed field components

if make_plots
    field_maps = {Bx_plot_mT, By_plot_mT, Bz_plot_mT};
    field_titles = {'Bx field', 'By field', 'Bz field'};

    hfield = figure(1, 'Visible', 'on');
    clf(hfield, 'reset');
    set(hfield, 'Units', 'pixels', 'Color', 'w');
    field_figure_position = get(hfield, 'Position');
    field_figure_position(3) = max(field_figure_position(3), 1500);
    field_figure_position(4) = max(field_figure_position(4), 600);
    set(hfield, 'Position', field_figure_position);
    drawnow('expose');

    % Fixed normalized positions keep the complete three-panel group
    % centered. Automatic subplot/colorbar placement otherwise shifts and
    % shrinks each axes by a different amount in Octave.
    field_axes_positions = [ ...
        0.055, 0.16, 0.205, 0.64; ...
        0.365, 0.16, 0.205, 0.64; ...
        0.675, 0.16, 0.205, 0.64];
    field_colorbar_positions = [ ...
        0.275, 0.16, 0.014, 0.64; ...
        0.585, 0.16, 0.014, 0.64; ...
        0.895, 0.16, 0.014, 0.64];

    for component_index = 1:3
        current_field = field_maps{component_index};
        finite_values = current_field(isfinite(current_field));
        color_limits = [min(finite_values), max(finite_values)];
        hcomponent = axes('Parent', hfield, 'Units', 'normalized', ...
            'Position', field_axes_positions(component_index, :));
        [hcomponent, hcolorbar] = PlotFieldMap(1, ...
            FOV_x, FOV_y, current_field, ...
            surface_name, field_titles{component_index}, color_limits, ...
            font_size, false, hcomponent);
        set(hcomponent, 'Units', 'normalized', ...
            'Position', field_axes_positions(component_index, :));
        set(hcolorbar, 'Units', 'normalized', ...
            'Position', field_colorbar_positions(component_index, :));
    end

    % Match the figure-wide description used by the MATLAB version.
    if n_magnets == 1
        field_figure_title = sprintf( ...
            ['Single magnet at [%.0f, %.0f, %.0f] mm, ', ...
             'yaw/pitch/roll = [%.0f, %.0f, %.0f] deg'], ...
            magnet_loc, magnet_angle);
    else
        field_figure_title = sprintf( ...
            '%d magnets: total signed field components', n_magnets);
    end

    htitle_axes = axes('Parent', hfield, 'Units', 'normalized', ...
        'Position', [0, 0.91, 1, 0.07], 'Visible', 'off', ...
        'Tag', 'FieldFigureTitleAxes');
    text(htitle_axes, 0.5, 0.5, field_figure_title, ...
        'Units', 'normalized', ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'middle', ...
        'FontSize', font_size, ...
        'Clipping', 'off');
    drawnow('expose');

    if draw_3d
        DrawMagnetization(magnet_loc, magnet_angle, magnet_dim, ...
            [0.85, 0.15, 0.15], FOV_x, FOV_y, FOV_z, ...
            surface_name, By_plot_mT);

        hfig = figure(100);
        hax = findobj(hfig, 'Type', 'axes', 'Tag', 'MagTetris3DAxes');
        if ~isempty(hax)
            if n_magnets == 1
                title(hax(1), ...
                    'Single magnet geometry and magnetization direction');
            else
                title(hax(1), sprintf( ...
                    '%d-magnet geometry and magnetization directions', ...
                    n_magnets));
            end
        end
    end
end

toc;
