clear;
close all;
tic;
% GNU Octave version of IOring_Array8_Practice.m.

script_dir = fileparts(mfilename('fullpath'));
if isempty(script_dir)
    script_dir = pwd;
end
addpath(script_dir);

draw_3d = true;
make_plots = true;
ConfigureOctaveGraphics();

%% Field of view and design settings

FOV_half = 25;
FOV_1 = -FOV_half:1:FOV_half;
FOV_2 = -FOV_half:1:FOV_half;
FOV_3 = 0;
slice_offsets_mm = [-2, -1, 0, 1, 2];
surface_name = 'z';
n_per_group = 1;
font_size = 14;



bar_pitch_deg = 0;
array_rotation_deg = bar_pitch_deg / 2;

%% Main array with 30 mm magnets

% Fill locations as [R, positive Z] in mm, one row per seed.
% Set either location or angle to [] to disable this group.
quadrant_main_loc = [];
quadrant_main_angle = [];

main_dim = [30, 30, 30];
main_Br = 1.43;
n_bar_main = 8;

%% Shim array with 10 mm magnets
quadrant_shim_loc = [];
quadrant_shim_angle = [];

shim_dim = [10, 10, 10];
shim_Br = 1.43;
n_bar_shim = 40;

%% Optional group activation

main_parameters_empty = ...
    isempty(quadrant_main_loc) || isempty(quadrant_main_angle);
shim_parameters_empty = ...
    isempty(quadrant_shim_loc) || isempty(quadrant_shim_angle);

main_radius_min = NaN;
main_radius_max = NaN;

if ~main_parameters_empty
    main_radius_min = min(quadrant_main_loc(:, 1));
    main_radius_max = max(quadrant_main_loc(:, 1));
end

%% Generate and separate the main and shim arrays

if main_parameters_empty
    active_main_loc = zeros(0, 2);
    active_main_angle = zeros(0, 1);
else
    active_main_loc = quadrant_main_loc;
    active_main_angle = quadrant_main_angle;
end

if shim_parameters_empty
    active_quadrant_shim_loc = zeros(0, 2);
    active_quadrant_shim_angle = zeros(0, 1);
else
    active_quadrant_shim_loc = quadrant_shim_loc;
    active_quadrant_shim_angle = quadrant_shim_angle;
end

Main_MT = [];
Shim_MT = [];
n_main = 0;
n_shim = 0;

rotation_xy = [cosd(array_rotation_deg), -sind(array_rotation_deg); ...
               sind(array_rotation_deg),  cosd(array_rotation_deg)];

if ~main_parameters_empty
    main_quadrant_dim = repmat( ...
        main_dim, size(active_main_loc, 1), 1);
    main_quadrant_Br = main_Br * ones(size(active_main_loc, 1), 1);

    [main_loc, main_angle, main_magnet_dim, main_magnet_Br] = ...
        GenerateIORingPairFromQuadrant_octave( ...
        n_bar_main, active_main_loc, main_quadrant_dim, ...
        active_main_angle, main_quadrant_Br, make_plots);

    main_loc(:, 1:2) = main_loc(:, 1:2) * rotation_xy.';
    main_angle(:, 1) = mod( ...
        main_angle(:, 1) + array_rotation_deg, 360);
    n_main = size(main_loc, 1);

    Main_MT = MagTetris().AssignCuboid( ...
        main_loc, main_angle, main_magnet_Br, main_magnet_dim);
end

if ~shim_parameters_empty
    shim_quadrant_dim = repmat( ...
        shim_dim, size(active_quadrant_shim_loc, 1), 1);
    shim_quadrant_Br = shim_Br * ones( ...
        size(active_quadrant_shim_loc, 1), 1);

    [shim_loc, shim_angle, shim_magnet_dim, shim_magnet_Br] = ...
        GenerateIORingPairFromQuadrant_octave( ...
        n_bar_shim, active_quadrant_shim_loc, shim_quadrant_dim, ...
        active_quadrant_shim_angle, shim_quadrant_Br, make_plots);

    shim_loc(:, 1:2) = shim_loc(:, 1:2) * rotation_xy.';
    shim_angle(:, 1) = mod( ...
        shim_angle(:, 1) + array_rotation_deg, 360);
    n_shim = size(shim_loc, 1);

    Shim_MT = MagTetris().AssignCuboid( ...
        shim_loc, shim_angle, shim_magnet_Br, shim_magnet_dim);
end

% Run the Array8 overlap assertions directly in this script. Keeping this
% code inline avoids Octave's script-local-function visibility limitation.
overlap_locations = {};
overlap_angles = {};
overlap_dimensions = {};
overlap_names = {};

if ~main_parameters_empty
    overlap_locations{end + 1} = main_loc;
    overlap_angles{end + 1} = main_angle(:, 1);
    overlap_dimensions{end + 1} = main_magnet_dim;
    overlap_names{end + 1} = 'main array';
end
if ~shim_parameters_empty
    overlap_locations{end + 1} = shim_loc;
    overlap_angles{end + 1} = shim_angle(:, 1);
    overlap_dimensions{end + 1} = shim_magnet_dim;
    overlap_names{end + 1} = 'shim array';
end
if ~main_parameters_empty && ~shim_parameters_empty
    overlap_locations{end + 1} = [main_loc; shim_loc];
    overlap_angles{end + 1} = [main_angle(:, 1); shim_angle(:, 1)];
    overlap_dimensions{end + 1} = [main_magnet_dim; shim_magnet_dim];
    overlap_names{end + 1} = 'combined main and shim arrays';
end

for overlap_group_index = 1:numel(overlap_names)
    overlap_loc = overlap_locations{overlap_group_index};
    overlap_angle_deg = overlap_angles{overlap_group_index};
    overlap_dim = overlap_dimensions{overlap_group_index};
    overlap_group_name = overlap_names{overlap_group_index};
    overlap_count = size(overlap_loc, 1);

    assert(size(overlap_loc, 2) == 3, sprintf( ...
        '%s: magnet locations must have 3 columns.', overlap_group_name));
    assert(size(overlap_dim, 1) == overlap_count && ...
        size(overlap_dim, 2) == 3, sprintf( ...
        '%s: magnet dimensions must be N x 3.', overlap_group_name));
    assert(numel(overlap_angle_deg) == overlap_count, sprintf( ...
        '%s: need one z-rotation angle per magnet.', overlap_group_name));
    assert(all(isfinite(overlap_loc(:))) && ...
        all(isfinite(overlap_dim(:))) && ...
        all(isfinite(overlap_angle_deg(:))), sprintf( ...
        '%s: geometry contains non-finite values.', overlap_group_name));
    assert(all(overlap_dim(:) > 0), sprintf( ...
        '%s: magnet dimensions must be positive.', overlap_group_name));

    overlap_angle_deg = overlap_angle_deg(:);
    overlap_half_dim = overlap_dim / 2;
    overlap_tolerance = 1e-9;
    overlap_axes = zeros(3, 3, overlap_count);

    for magnet_index = 1:overlap_count
        cosine = cosd(overlap_angle_deg(magnet_index));
        sine = sind(overlap_angle_deg(magnet_index));
        overlap_axes(:, :, magnet_index) = [ ...
            cosine, -sine, 0; sine, cosine, 0; 0, 0, 1];
    end

    for first_index = 1:(overlap_count - 1)
        for second_index = (first_index + 1):overlap_count
            axes_first = overlap_axes(:, :, first_index);
            axes_second = overlap_axes(:, :, second_index);
            half_first = overlap_half_dim(first_index, :).';
            half_second = overlap_half_dim(second_index, :).';

            rotation = axes_first.' * axes_second;
            abs_rotation = abs(rotation) + 1e-12;
            translation = axes_first.' * ...
                (overlap_loc(second_index, :).' - ...
                 overlap_loc(first_index, :).');
            separated = false;

            for first_axis = 1:3
                radius_first = half_first(first_axis);
                radius_second = sum( ...
                    half_second .* abs_rotation(first_axis, :).');
                if abs(translation(first_axis)) >= ...
                        radius_first + radius_second - overlap_tolerance
                    separated = true;
                    break;
                end
            end
            if separated
                continue;
            end

            for second_axis = 1:3
                radius_first = sum( ...
                    half_first .* abs_rotation(:, second_axis));
                radius_second = half_second(second_axis);
                distance = abs(translation.' * rotation(:, second_axis));
                if distance >= ...
                        radius_first + radius_second - overlap_tolerance
                    separated = true;
                    break;
                end
            end
            if separated
                continue;
            end

            for first_axis = 1:3
                for second_axis = 1:3
                    first_axis_1 = mod(first_axis, 3) + 1;
                    first_axis_2 = mod(first_axis + 1, 3) + 1;
                    second_axis_1 = mod(second_axis, 3) + 1;
                    second_axis_2 = mod(second_axis + 1, 3) + 1;

                    radius_first = ...
                        half_first(first_axis_1) * ...
                        abs_rotation(first_axis_2, second_axis) + ...
                        half_first(first_axis_2) * ...
                        abs_rotation(first_axis_1, second_axis);
                    radius_second = ...
                        half_second(second_axis_1) * ...
                        abs_rotation(first_axis, second_axis_2) + ...
                        half_second(second_axis_2) * ...
                        abs_rotation(first_axis, second_axis_1);
                    distance = abs( ...
                        translation(first_axis_2) * ...
                        rotation(first_axis_1, second_axis) - ...
                        translation(first_axis_1) * ...
                        rotation(first_axis_2, second_axis));

                    if distance >= ...
                            radius_first + radius_second - overlap_tolerance
                        separated = true;
                        break;
                    end
                end
                if separated
                    break;
                end
            end

            assert(separated, sprintf( ...
                '%s: magnets %d and %d overlap.', ...
                overlap_group_name, first_index, second_index));
        end
    end

    fprintf('Overlap check passed: %s (%d magnets).\n', ...
        overlap_group_name, overlap_count);
end

if make_plots
    plot_combined_quadrant_octave( ...
        active_main_loc, active_main_angle, main_dim, ...
        active_quadrant_shim_loc, active_quadrant_shim_angle, shim_dim);
end

fprintf('Main magnets                : %d\n', n_main);
fprintf('Shim magnets                : %d\n', n_shim);
fprintf('Main radial range           : %.1f to %.1f mm\n', ...
    main_radius_min, main_radius_max);
fprintf('Shim seed rings\n');
for shim_index = 1:size(active_quadrant_shim_loc, 1)
    fprintf('  R = %.1f mm, Z = +/-%.1f mm, angle = %.0f degrees\n', ...
        active_quadrant_shim_loc(shim_index, 1), ...
        active_quadrant_shim_loc(shim_index, 2), ...
        active_quadrant_shim_angle(shim_index));
end
fprintf('\n');

%% Calculate the unshimmed and shimmed five-slice Bz fields

n_slice = numel(slice_offsets_mm);

field_objects = {Main_MT, Shim_MT};
Bz_averages = cell(2, 1);
Bz_stacks = cell(2, 1);

for object_index = 1:2
    current_MT = field_objects{object_index};
    if isempty(current_MT)
        % An absent magnet group contributes a correctly sized zero field.
        % Do not call MagTetris methods on the [] sentinel used above.
        current_stack = zeros(numel(FOV_2), numel(FOV_1), n_slice);
    else
        [~, ~, Bz_slice] = current_MT.Field2D( ...
            FOV_1, FOV_2, slice_offsets_mm(1), 'z', n_per_group);
        current_stack = zeros([size(Bz_slice), n_slice]);
        current_stack(:, :, 1) = Bz_slice;

        for slice_index = 2:n_slice
            [~, ~, current_stack(:, :, slice_index)] = ...
                current_MT.Field2D(FOV_1, FOV_2, ...
                    slice_offsets_mm(slice_index), 'z', n_per_group);
        end
    end

    Bz_stacks{object_index} = current_stack;
    Bz_averages{object_index} = mean(current_stack, 3);
end

Bz_main = Bz_averages{1};
Bz_shim = Bz_averages{2};
Bz_main_slices = Bz_stacks{1};
Bz_shim_slices = Bz_stacks{2};
Bz_total = Bz_main + Bz_shim;
Bz_total_slices = Bz_main_slices + Bz_shim_slices;

% Keep only the circular field of view and convert tesla to millitesla.
[FOV_x, FOV_y] = meshgrid(FOV_1, FOV_2);
outside_FOV = hypot(FOV_x, FOV_y) > FOV_half;

Bz_main_mT = 1e3 * Bz_main;
Bz_shim_mT = 1e3 * Bz_shim;
Bz_total_mT = 1e3 * Bz_total;
Bz_main_mT(outside_FOV) = NaN;
Bz_shim_mT(outside_FOV) = NaN;
Bz_total_mT(outside_FOV) = NaN;

Bz_main_slices_mT = 1e3 * Bz_main_slices;
Bz_shim_slices_mT = 1e3 * Bz_shim_slices;
Bz_total_slices_mT = 1e3 * Bz_total_slices;
for slice_index = 1:n_slice
    main_slice = Bz_main_slices_mT(:, :, slice_index);
    shim_slice = Bz_shim_slices_mT(:, :, slice_index);
    total_slice = Bz_total_slices_mT(:, :, slice_index);
    main_slice(outside_FOV) = NaN;
    shim_slice(outside_FOV) = NaN;
    total_slice(outside_FOV) = NaN;
    Bz_main_slices_mT(:, :, slice_index) = main_slice;
    Bz_shim_slices_mT(:, :, slice_index) = shim_slice;
    Bz_total_slices_mT(:, :, slice_index) = total_slice;
end

% Calculate the same metrics for the main, shim-only, and summed fields.
metric_stacks = { ...
    Bz_main_slices_mT, Bz_shim_slices_mT, Bz_total_slices_mT};
metric_results = cell(3, 1);
for metric_index = 1:3
    B_valid = metric_stacks{metric_index};
    B_valid = B_valid(isfinite(B_valid));
    if isempty(B_valid)
        error('Bmap contains no valid finite values.');
    end

    current_metrics = struct();
    current_metrics.Bmax = max(B_valid);
    current_metrics.Bmin = min(B_valid);
    current_metrics.Bmean = mean(B_valid);
    current_metrics.Bstd = std(B_valid);
    current_metrics.deltaB_pp = ...
        current_metrics.Bmax - current_metrics.Bmin;
    if abs(current_metrics.Bmean) <= eps
        % Relative homogeneity is undefined for a zero-mean absent group.
        current_metrics.hom_ppm_pp = NaN;
        current_metrics.hom_ppm_std = NaN;
    else
        current_metrics.hom_ppm_pp = current_metrics.deltaB_pp / ...
            abs(current_metrics.Bmean) * 1e6;
        current_metrics.hom_ppm_std = current_metrics.Bstd / ...
            abs(current_metrics.Bmean) * 1e6;
    end
    metric_results{metric_index} = current_metrics;
end

metrics_before = metric_results{1};
metrics_shim = metric_results{2};
metrics_after = metric_results{3};
improvement_percent = 100 * ...
    (1 - metrics_after.hom_ppm_pp / metrics_before.hom_ppm_pp);

metric_labels = {'Before shimming', 'Shim-only field', 'After shimming'};
metrics_to_print = {metrics_before, metrics_shim, metrics_after};
for metric_index = 1:3
    current_metrics = metrics_to_print{metric_index};
    if metric_index > 1
        fprintf('\n');
    end
    fprintf('%s\n', metric_labels{metric_index});
    fprintf('Mean Bz                     : %.6f mT\n', ...
        current_metrics.Bmean);
    fprintf('Maximum Bz                  : %.6f mT\n', ...
        current_metrics.Bmax);
    fprintf('Minimum Bz                  : %.6f mT\n', ...
        current_metrics.Bmin);
    fprintf('Peak-to-peak homogeneity    : %.6f ppm\n', ...
        current_metrics.hom_ppm_pp);
    fprintf('Standard-deviation homogeneity: %.6f ppm\n', ...
        current_metrics.hom_ppm_std);
end
fprintf('\nPeak-to-peak improvement    : %.2f %%\n\n', ...
    improvement_percent);

%% Plot the main, shim-only, and final Bz fields

if make_plots
    % Display-only copies suppress field magnitudes below 0.1 mT. The
    % original maps and all previously calculated metrics remain unchanged.
    Bz_main_plot_mT = Bz_main_mT;
    Bz_shim_plot_mT = Bz_shim_mT;
    Bz_total_plot_mT = Bz_total_mT;
    Bz_main_plot_mT(abs(Bz_main_plot_mT) < 0.1) = 0;
    Bz_shim_plot_mT(abs(Bz_shim_plot_mT) < 0.1) = 0;
    Bz_total_plot_mT(abs(Bz_total_plot_mT) < 0.1) = 0;

    performance_maps = { ...
        Bz_main_plot_mT, Bz_shim_plot_mT, Bz_total_plot_mT};
    performance_names = {'Main magnets', 'Shim magnets only', 'Final sum'};
    performance_metrics = {metrics_before, metrics_shim, metrics_after};

    % Match the MATLAB version: show all three performance maps together in
    % one wide Figure 2, with each map's metrics in its title.
    hperformance = figure(2, 'Visible', 'on');
    clf(hperformance, 'reset');
    set(hperformance, 'Units', 'pixels', 'Color', 'w');
    performance_figure_position = get(hperformance, 'Position');
    performance_figure_position(3) = max(performance_figure_position(3), 1600);
    performance_figure_position(4) = max(performance_figure_position(4), 700);
    set(hperformance, 'Position', performance_figure_position);
    drawnow('expose');

    performance_axes_positions = [ ...
        0.055, 0.10, 0.205, 0.48; ...
        0.365, 0.10, 0.205, 0.48; ...
        0.675, 0.10, 0.205, 0.48];
    performance_colorbar_positions = [ ...
        0.275, 0.10, 0.014, 0.48; ...
        0.585, 0.10, 0.014, 0.48; ...
        0.895, 0.10, 0.014, 0.48];
    performance_metric_positions = [ ...
        0.055, 0.64, 0.205, 0.24; ...
        0.365, 0.64, 0.205, 0.24; ...
        0.675, 0.64, 0.205, 0.24];
    metric_line_y = [0.88, 0.62, 0.36, 0.10];

    for map_index = 1:3
        current_map = performance_maps{map_index};
        current_metrics = performance_metrics{map_index};
        finite_values = current_map(isfinite(current_map));
        metric_title_lines = { ...
            performance_names{map_index}; ...
            sprintf('Mean %.4f mT', current_metrics.Bmean); ...
            sprintf('Min %.4f | Max %.4f mT', ...
                current_metrics.Bmin, current_metrics.Bmax); ...
            sprintf('Peak-to-peak %.1f ppm', ...
                current_metrics.hom_ppm_pp)};

        hmap = axes('Parent', hperformance, 'Units', 'normalized', ...
            'Position', performance_axes_positions(map_index, :));
        [hmap, hcolorbar] = PlotFieldMap(2, FOV_1, FOV_2, current_map, ...
            surface_name, '', ...
            [min(finite_values), max(finite_values)], ...
            font_size, false, hmap);
        set(hmap, 'Units', 'normalized', ...
            'Position', performance_axes_positions(map_index, :));
        set(hcolorbar, 'Units', 'normalized', ...
            'Position', performance_colorbar_positions(map_index, :));

        % The FLTK title renderer displays only the first line of multiline
        % titles. Draw four independent text rows in a dedicated invisible
        % axes so every field metric is always visible.
        hmetrics = axes('Parent', hperformance, 'Units', 'normalized', ...
            'Position', performance_metric_positions(map_index, :), ...
            'Visible', 'off', 'XLim', [0, 1], 'YLim', [0, 1], ...
            'Tag', sprintf('FieldMetricsAxes%d', map_index));
        for metric_line_index = 1:4
            text(hmetrics, 0.5, metric_line_y(metric_line_index), ...
                metric_title_lines{metric_line_index}, ...
                'Units', 'normalized', ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'middle', ...
                'FontSize', font_size, ...
                'FontWeight', 'bold', ...
                'Clipping', 'off');
        end
    end
    drawnow('expose');

    if draw_3d
        if n_main > 0
            DrawMagnetization(Main_MT.cub_loc, Main_MT.cub_angle, ...
                Main_MT.cub_dim, [0.85, 0.15, 0.15], ...
                FOV_1, FOV_2, FOV_3, surface_name, ...
                Bz_total_plot_mT, true);
        end
        if n_shim > 0
            if n_main > 0
                shim_field_map = [];
                reset_3d_figure = false;
            else
                shim_field_map = Bz_total_plot_mT;
                reset_3d_figure = true;
            end
            DrawMagnetization(Shim_MT.cub_loc, Shim_MT.cub_angle, ...
                Shim_MT.cub_dim, [0.15, 0.35, 0.90], ...
                FOV_1, FOV_2, FOV_3, surface_name, ...
                shim_field_map, reset_3d_figure);
        end

        if n_main > 0 || n_shim > 0
            hfig = figure(100);
            hax = findobj(hfig, 'Type', 'axes', 'Tag', 'MagTetris3DAxes');
            if ~isempty(hax)
                if n_main > 0 && n_shim > 0
                    figure_title = ...
                        'Main magnets (red) and shim magnets (blue)';
                elseif n_main > 0
                    figure_title = 'Main magnets (red)';
                else
                    figure_title = 'Shim magnets (blue)';
                end
                title(hax(1), figure_title);
            end
        end
    end
end

toc;
