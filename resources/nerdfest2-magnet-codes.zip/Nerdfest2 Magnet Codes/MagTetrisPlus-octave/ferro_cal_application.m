% Example MagTetris+ application for GNU Octave.
% The 3-D visualization uses filled field surfaces and magnet patches.

clear;
close all;

root_dir = fileparts(mfilename('fullpath'));
addpath(root_dir);

graphics_toolkit_name = ConfigureOctaveGraphics();
fprintf('Graphics toolkit: %s\n', graphics_toolkit_name);

% PMA
Br_all = [1.43, 1.43];
angle_all = [0,0,90; 20,50,0];
magnet_dim_all = [10,10,10; 10,10,10];
loc_all_list = [0,0,-7; 15,0,-7];

% Ferromagnetic domains
orient_angle_raw = [0,0,0; 0,0,0];
geo_param_raw = [10,10,10; 5,5,5];
ferro_loc_raw = [0,0,6; 0,10,6];

orient_angle_raw = [0,0,0];
geo_param_raw = [10,10,1];
ferro_loc_raw = [0,0,6];

orient_angle_raw = [];
geo_param_raw = [];
ferro_loc_raw = [];

% Field of view
fov_size = 15;
fov_plane_value = 15;
res = 1.0;  % Use 0.5 or 0.1 only after confirming the serial port works.
FOV_1 = -fov_size:res:fov_size;
FOV_2 = -fov_size:res:fov_size;
FOV_3 = fov_plane_value;
surface_name = 'z';

PMA_MT = MagTetris();
PMA_MT = PMA_MT.AssignCuboid(loc_all_list, angle_all, Br_all, magnet_dim_all);

solver_options.verbose = false;
fprintf('1/5 Solving ferromagnetic magnetization...\n');
tic;
Ferro_MT = MagTetrisPlus(PMA_MT, ferro_loc_raw, orient_angle_raw, ...
    geo_param_raw, solver_options);

All_MT = PMA_MT;
All_MT = All_MT.ConcatMT(Ferro_MT);

fprintf('2/5 Calculating the field map...\n');
[Bx, By, Bz] = All_MT.Field2D(FOV_1, FOV_2, FOV_3, surface_name, 1);

% Preserve the original example's upper-bound trimming.
trim_upper_limit = round(fov_size*2/res);
trim_upper_limit = min([trim_upper_limit, size(Bx,1), size(Bx,2), ...
                        numel(FOV_1), numel(FOV_2)]);
Bx = Bx(1:trim_upper_limit, 1:trim_upper_limit);
By = By(1:trim_upper_limit, 1:trim_upper_limit);
Bz = Bz(1:trim_upper_limit, 1:trim_upper_limit);
FOV_1 = FOV_1(1:trim_upper_limit);
FOV_2 = FOV_2(1:trim_upper_limit);

% Keep only the circular region.
[FOV_X, FOV_Y] = meshgrid(FOV_1, FOV_2);
outside = hypot(FOV_X, FOV_Y) > fov_size;
Bx(outside) = NaN;
By(outside) = NaN;
Bz(outside) = NaN;

% T to mT
Bx = Bx * 1e3;
By = By * 1e3;
Bz = Bz * 1e3;

finite_values = [Bx(isfinite(Bx)); By(isfinite(By)); Bz(isfinite(Bz))];
if isempty(finite_values)
    error('ferro_cal_application:NoFiniteFieldValues', ...
        'The calculated field maps do not contain any finite values.');
end
min_all = min(finite_values);
max_all = max(finite_values);
if min_all == max_all
    delta = max(abs(min_all)*1e-6, 1e-9);
    min_all = min_all - delta;
    max_all = max_all + delta;
end

fprintf('Field range: %.9g to %.9g mT\n', min_all, max_all);
fprintf('Finite samples: Bx=%d, By=%d, Bz=%d\n', ...
    nnz(isfinite(Bx)), nnz(isfinite(By)), nnz(isfinite(Bz)));

fprintf('3/5 Creating field-map figures 1, 2, and 3...\n');
font_size = 10;
color_limits = [min_all, max_all];
PlotFieldMap(1, FOV_1, FOV_2, Bx, surface_name, 'Bx(M+)', color_limits, font_size, true);
PlotFieldMap(2, FOV_1, FOV_2, By, surface_name, 'By(M+)', color_limits, font_size, true);
PlotFieldMap(3, FOV_1, FOV_2, Bz, surface_name, 'Bz(M+)', color_limits, font_size, true);
drawnow('expose');

fprintf('4/5 Creating 3-D magnetization figure 10...\n');
h100 = figure(10, 'Visible', 'on');
clf(h100, 'reset');
DrawMagnetization(All_MT.cub_loc, All_MT.cub_angle, All_MT.cub_dim, ...
    [0.55, 0.55, 0.55], FOV_1, FOV_2, FOV_3, surface_name, Bz);
DrawMagnetization(PMA_MT.cub_loc, PMA_MT.cub_angle, PMA_MT.cub_dim, ...
    [0.85, 0.10, 0.10], FOV_1, FOV_2, FOV_3, surface_name, [], false);
drawnow('expose');

fprintf('5/5 Saving PNG copies...\n');
output_dir = fullfile(root_dir, 'output_figures');
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end
for figure_number = [1, 2, 3, 100]
    h = figure(figure_number);
    png_path = fullfile(output_dir, sprintf('figure_%d.png', figure_number));
    try
        print(h, png_path, '-dpng', '-r120');
        fprintf('  Saved %s\n', png_path);
    catch err
        warning('Could not save figure %d: %s', figure_number, err.message);
    end
end

toc;
fprintf('Finished. Figures 1, 2, 3, and 100 should contain visible graphics.\n');
fprintf('PNG copies are in: %s\n', output_dir);
figure(1);
drawnow('expose');
