clear;
close all;
tic;
% Generate the optimized BIGBLACK IOring geometry and evaluate its field.
% This GNU Octave version is intended to be run from MagTetrisPlus-octave.

script_dir = fileparts(mfilename('fullpath'));
if isempty(script_dir)
    script_dir = pwd;
end
addpath(script_dir);

draw_3d = true;

Fov_half = 75;
make_plots = true;
ConfigureOctaveGraphics();

rs = 1;
FOV_half_1 = Fov_half;
FOV_1 = -FOV_half_1:rs:FOV_half_1;
FOV_half_2 = Fov_half;
FOV_2 = -FOV_half_2:rs:FOV_half_2;
FOV_3 = 0;
slice_offsets_mm = [FOV_3-2, FOV_3-1, FOV_3, FOV_3+1, FOV_3+2];
surface_name = 'z';
n_per_group = 1;
font_size = 18;

% Peak-to-peak-homogeneity optimized BIGBLACK inputs. Homogeneity below is
% evaluated over every finite sample in the full five-slice 3-D Bz stack.
n_bar = 28;
bar_pitch_deg = 360 / n_bar;
array_rotation_deg = bar_pitch_deg / 2;

% Each row describes one upper R-Z quadrant seed magnet: [R, Z] in mm.
quadrant_loc = [ ...
    185, 247; ...
    164, 247; ...
    152, 247; ...
    140, 247; ...
    128, 247; ...
    186, 209; ...
    174, 209; ...
    162, 209; ...
    150, 209; ...
    138, 209; ...
    126, 209; ...
    186, 171; ...
    174, 171; ...
    162, 171; ...
    150, 171; ...
    138, 171; ...
    186, 133; ...
    174, 133; ...
    162, 133; ...
    150, 133; ...
    138, 133; ...
    126, 133; ...
    175,  95; ...
    150,  95; ...
    127,  95; ...
    186,  57; ...
    156,  57; ...
    132,  57; ...
    186,  19; ...
    162,  19; ...
    127,  19];

quadrant_angle = [ ...
    180 * ones(22, 1); ...
    0; ...
    270 * ones(3, 1); ...
    180; ...
    270 * ones(2, 1); ...
    180; ...
    270];


quadrant_dim = repmat([12, 12, 12], size(quadrant_loc, 1), 1);
quadrant_Br = 1.43 * ones(size(quadrant_loc, 1), 1);

[loc_all_list, angle_all, magnet_dim_all, Br_all] = ...
    GenerateIORingPairFromQuadrant_octave( ...
        n_bar, quadrant_loc, quadrant_dim, quadrant_angle, quadrant_Br, ...
        make_plots);

% Rotate the complete array by half a bar pitch so each Cartesian axis
% bisects neighboring magnet groups.
rotation_xy = [cosd(array_rotation_deg), -sind(array_rotation_deg); ...
               sind(array_rotation_deg),  cosd(array_rotation_deg)];
loc_all_list(:, 1:2) = loc_all_list(:, 1:2) * rotation_xy.';
angle_all(:, 1) = mod(angle_all(:, 1) + array_rotation_deg, 360);

% Basic geometry checks.
n_expected = n_bar * sum(1 + (quadrant_loc(:, 2) > 1e-9));
assert(size(loc_all_list, 1) == n_expected, ...
    'Expected %d magnets, but generated %d.', n_expected, size(loc_all_list, 1));
assert(isequal(size(angle_all), [n_expected, 3]), 'Unexpected angle_all size.');
assert(isequal(size(magnet_dim_all), [n_expected, 3]), ...
    'Unexpected magnet_dim_all size.');
assert(isequal(size(Br_all), [1, n_expected]), 'Unexpected Br_all size.');

generated_radius = hypot(loc_all_list(:, 1), loc_all_list(:, 2));
for layer_index = 1:size(quadrant_loc, 1)
    layer_radius = quadrant_loc(layer_index, 1);
    layer_z = quadrant_loc(layer_index, 2);
    layer_mask = abs(generated_radius - layer_radius) < 1e-9;
    assert(sum(layer_mask & abs(loc_all_list(:, 3) - layer_z) < 1e-9) == n_bar, ...
        'Upper ring %d does not contain n_bar magnets.', layer_index);
    if layer_z > 1e-9
        assert(sum(layer_mask & abs(loc_all_list(:, 3) + layer_z) < 1e-9) == n_bar, ...
            'Lower ring %d does not contain n_bar magnets.', layer_index);
    end
end
assert(all(Br_all >= 0), 'Generated remanence values must be nonnegative.');

axis_angles_deg = [0, 90, 180, 270];
generated_angles_deg = mod(atan2d(loc_all_list(:, 2), loc_all_list(:, 1)), 360);
for axis_index = 1:numel(axis_angles_deg)
    angular_distance = abs(mod(generated_angles_deg - ...
        axis_angles_deg(axis_index) + 180, 360) - 180);
    assert(abs(min(angular_distance) - array_rotation_deg) < 1e-9, ...
        'A Cartesian axis does not bisect adjacent magnet groups.');
end

fprintf('Geometry checks passed.\n');
fprintf('Array rotation              : %.9f degrees\n', array_rotation_deg);
fprintf('Quadrant seed magnets       : %d\n', size(quadrant_loc, 1));
fprintf('Total generated magnets     : %d\n', size(loc_all_list, 1));

IOring_MT = MagTetris().AssignCuboid( ...
    loc_all_list, angle_all, Br_all, magnet_dim_all);

% Optional ferromagnetic plate shim.
ferro_loc_raw = [];
orient_angle_raw = [];
geo_param_raw = [];


ferro_parameters_empty = isempty(ferro_loc_raw) || ...
    isempty(orient_angle_raw) || isempty(geo_param_raw);
Ferro_MT = MagTetris();

if ~ferro_parameters_empty
    n_ferro = size(ferro_loc_raw, 1);
    assert(isequal(size(ferro_loc_raw), [n_ferro, 3]), ...
        'ferro_loc_raw must contain one [x, y, z] row per object.');
    assert(isequal(size(orient_angle_raw), [n_ferro, 3]), ...
        ['orient_angle_raw must contain one [yaw, pitch, roll] row ', ...
         'per object.']);
    assert(isequal(size(geo_param_raw), [n_ferro, 3]), ...
        'geo_param_raw must contain one [x, y, z] dimension row per object.');
    assert(all(geo_param_raw(:) > 0), ...
        'All ferromagnetic-object dimensions must be positive.');

    solver_options.verbose = true;
    Ferro_MT = MagTetrisPlus(IOring_MT, ferro_loc_raw, ...
        orient_angle_raw, geo_param_raw, solver_options);
    IOring_MT = IOring_MT.ConcatMT(Ferro_MT);
else
    fprintf('No ferromagnetic shim specified; using the permanent magnets only.\n');
end

% Calculate parallel Z planes. Homogeneity uses the full 3-D stack, while
% the corresponding-pixel average is retained for plotting. This is inline
% because Octave scripts do not reliably resolve functions declared after
% executable script statements on all supported versions.
n_slice = numel(slice_offsets_mm);
assert(n_slice > 0, 'slice_offsets_mm cannot be empty.');
[Bx_slice, By_slice, Bz_slice] = IOring_MT.Field2D( ...
    FOV_1, FOV_2, slice_offsets_mm(1), 'z', n_per_group);
stack_size = [size(Bz_slice), n_slice];
Bx_slices = zeros(stack_size);
By_slices = zeros(stack_size);
Bz_slices = zeros(stack_size);
Bx_slices(:, :, 1) = Bx_slice;
By_slices(:, :, 1) = By_slice;
Bz_slices(:, :, 1) = Bz_slice;
for slice_index = 2:n_slice
    [Bx_slices(:, :, slice_index), ...
        By_slices(:, :, slice_index), ...
        Bz_slices(:, :, slice_index)] = IOring_MT.Field2D( ...
            FOV_1, FOV_2, slice_offsets_mm(slice_index), 'z', n_per_group);
end
Bx = mean(Bx_slices, 3);
By = mean(By_slices, 3);
Bz = mean(Bz_slices, 3);

% Keep only the circular field of view.
[FOV_x, FOV_y] = meshgrid(FOV_1, FOV_2);
outside_FOV = hypot(FOV_x, FOV_y) > FOV_half_1;
Bx(outside_FOV) = NaN;
By(outside_FOV) = NaN;
Bz(outside_FOV) = NaN;

Bx = Bx * 1e3;
By = By * 1e3;
Bz = Bz * 1e3;
Bx_slices = Bx_slices * 1e3;
By_slices = By_slices * 1e3;
Bz_slices = Bz_slices * 1e3;
for slice_index = 1:n_slice
    Bx_slice = Bx_slices(:, :, slice_index);
    By_slice = By_slices(:, :, slice_index);
    Bz_slice = Bz_slices(:, :, slice_index);
    Bx_slice(outside_FOV) = NaN;
    By_slice(outside_FOV) = NaN;
    Bz_slice(outside_FOV) = NaN;
    Bx_slices(:, :, slice_index) = Bx_slice;
    By_slices(:, :, slice_index) = By_slice;
    Bz_slices(:, :, slice_index) = Bz_slice;
end

B_valid = Bz_slices(isfinite(Bz_slices));
if isempty(B_valid)
    error('Bz_slices contains no valid finite values.');
end
B0_ref = mean(B_valid);
if B0_ref == 0
    error('The mean Bz reference cannot be zero.');
end
metrics = struct();
metrics.B0_ref = B0_ref;
metrics.Bmax = max(B_valid);
metrics.Bmin = min(B_valid);
metrics.Bmean = mean(B_valid);
metrics.Bstd = std(B_valid);
metrics.deltaB_pp = metrics.Bmax - metrics.Bmin;
metrics.hom_ppm_pp = metrics.deltaB_pp / abs(B0_ref) * 1e6;
metrics.hom_ppm_std = metrics.Bstd / abs(B0_ref) * 1e6;
fprintf('3-D stack slice Z values    : %s mm\n', mat2str(slice_offsets_mm));
fprintf('Mean Bz                     : %.6f mT\n', metrics.Bmean);
fprintf('Max Bz                      : %.6f mT\n', metrics.Bmax);
fprintf('Min Bz                      : %.6f mT\n', metrics.Bmin);
fprintf('Peak-to-peak homogeneity    : %.6f ppm\n', metrics.hom_ppm_pp);
fprintf('Standard-deviation homogeneity: %.6f ppm\n\n', metrics.hom_ppm_std);

if make_plots
    % Apply a display-only 0.1 mT deadband. Bz and all metrics remain
    % unchanged.
    Bx_plot = Bx;
    Bx_plot(abs(Bx_plot) < 0.1) = 0;
    By_plot = By;
    By_plot(abs(By_plot) < 0.1) = 0;
    Bz_plot = Bz;
    Bz_plot(abs(Bz_plot) < 0.1) = 0;


    plot_title = sprintf('Bx map');
    finite_Bx = Bx_plot(isfinite(Bx_plot));
    PlotFieldMap(1, FOV_1, FOV_2, Bx_plot, surface_name, plot_title, ...
        [min(finite_Bx), max(finite_Bx)], font_size, true);

    plot_title = sprintf('By map');
    finite_By = By_plot(isfinite(By_plot));
    PlotFieldMap(2, FOV_1, FOV_2, By_plot, surface_name, plot_title, ...
        [min(finite_By), max(finite_By)], font_size, true);

    plot_title = sprintf( ...
        'Average Bz map', ...
        metrics.hom_ppm_pp, metrics.Bmean);
    finite_Bz = Bz_plot(isfinite(Bz_plot));
    PlotFieldMap(3, FOV_1, FOV_2, Bz_plot, surface_name, plot_title, ...
        [min(finite_Bz), max(finite_Bz)], font_size, true);

    if draw_3d
        fprintf('Creating Figure 10 with the batched 3-D renderer...\n');
        % Octave's port takes the cuboid color before the FoV arguments.
        DrawMagnetization(loc_all_list, angle_all, magnet_dim_all, ...
            [0.85, 0.10, 0.10], FOV_1, FOV_2, FOV_3, ...
            surface_name, Bz_plot);
        if ~ferro_parameters_empty && Ferro_MT.cub_numMag > 0
            DrawMagnetization(Ferro_MT.cub_loc, Ferro_MT.cub_angle, ...
                Ferro_MT.cub_dim, [0.55, 0.55, 0.55], ...
                FOV_1, FOV_2, FOV_3, surface_name, [], false);
        end
    else
        fprintf(['Skipping Figure 10']);
    end
    fprintf('Plotting complete.\n');
end

toc;
