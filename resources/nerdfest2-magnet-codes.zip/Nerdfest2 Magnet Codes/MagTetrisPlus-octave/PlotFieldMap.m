function [hax, cb] = PlotFieldMap(fig_num, FOV_1, FOV_2, B_field, surface_name, title_text, color_limits, font_size, reset_figure, target_axes)
%PLOTFIELDMAP Plot a 2-D magnetic-field map using an Octave-safe renderer.
%
% imagesc is intentionally used instead of pcolor.  pcolor creates a
% surface object, which can be blank on Windows when the Qt/OpenGL driver is
% not working correctly.  imagesc creates a 2-D image object and is much
% more reliable while representing the same sampled field map.
% target_axes is optional. When supplied, the map is drawn in those axes so
% several field components can share one figure.

if nargin < 9
    reset_figure = true;
end

if nargin < 10
    target_axes = [];
end

standalone_layout = isempty(target_axes);
if standalone_layout
    hfig = figure(fig_num, 'Visible', 'on');
    if reset_figure
        clf(hfig, 'reset');
    end
else
    hax = target_axes;
    hfig = get(hax, 'Parent');
    cla(hax, 'reset');
end

% Octave's automatic axes/colorbar layout can clip the x label and the
% colorbar tick labels, especially with the 18-point font used by the
% IOring examples.  Keep a readable minimum window size and reserve fixed
% normalized margins for the axes and colorbar.
if standalone_layout
    set(hfig, 'Units', 'pixels');
    figure_position = get(hfig, 'Position');
    figure_position(3) = max(figure_position(3), 900);
    figure_position(4) = max(figure_position(4), 650);
    set(hfig, 'Position', figure_position, 'Color', 'w');

    axes_position = [0.10, 0.16, 0.62, 0.70];
    colorbar_position = [0.78, 0.16, 0.035, 0.70];
end

% Validate and sanitize data before plotting.
if isempty(B_field) || ~ismatrix(B_field)
    error('PlotFieldMap:InvalidField', 'B_field must be a non-empty 2-D matrix.');
end

finite_mask = isfinite(B_field);
if ~any(finite_mask(:))
    error('PlotFieldMap:NoFiniteValues', 'B_field contains no finite values.');
end

if nargin < 7 || numel(color_limits) ~= 2 || any(~isfinite(color_limits))
    values = B_field(finite_mask);
    color_limits = [min(values), max(values)];
end

% Octave rejects or displays a blank map for identical color limits.
if color_limits(1) == color_limits(2)
    delta = max(abs(color_limits(1))*1e-6, 1e-9);
    color_limits = color_limits + [-delta, delta];
end

if standalone_layout
    hax = axes('Parent', hfig, 'Units', 'normalized', ...
        'Position', axes_position);
end

% Keep NaN samples out of the rendered field map. Octave's graphics
% toolkits do not all treat NaN image pixels consistently, so provide an
% explicit transparency mask and harmless finite CData for those pixels.
display_field = B_field;
display_field(~finite_mask) = color_limits(1);
himg = imagesc(FOV_1, FOV_2, display_field, 'Parent', hax);
set(himg, 'AlphaData', double(finite_mask), 'AlphaDataMapping', 'none');
set(hax, 'YDir', 'normal', 'Visible', 'on', 'FontSize', font_size, ...
    'Color', [1, 1, 1]);
axis(hax, 'image');
axis(hax, 'tight');
caxis(hax, color_limits);
colormap(hfig, jet(256));

cb = colorbar('peer', hax);
try
    % A title above the colorbar matches the MATLAB plots and uses less
    % horizontal space than a vertical ylabel.
    set(get(cb, 'Title'), 'String', 'mT', 'FontSize', font_size);
catch
    try
        ylabel(cb, 'mT', 'FontSize', font_size);
    catch
        % Very old Octave versions may not expose a colorbar label handle.
    end
end
if standalone_layout
    set(cb, 'Units', 'normalized', 'Position', colorbar_position, ...
        'FontSize', font_size);

    % colorbar() changes the peer axes position automatically. Restore the
    % explicit layout after creating and positioning the colorbar.
    set(hax, 'Units', 'normalized', 'Position', axes_position);
else
    set(cb, 'FontSize', font_size);
end

switch lower(surface_name)
    case 'x'
        xlabel(hax, 'y/mm', 'FontSize', font_size);
        ylabel(hax, 'z/mm', 'FontSize', font_size);
    case 'y'
        xlabel(hax, 'x/mm', 'FontSize', font_size);
        ylabel(hax, 'z/mm', 'FontSize', font_size);
    case 'z'
        xlabel(hax, 'x/mm', 'FontSize', font_size);
        ylabel(hax, 'y/mm', 'FontSize', font_size);
    otherwise
        error('PlotFieldMap:InvalidSurface', 'surface must be ''x'', ''y'', or ''z''.');
end

title(hax, title_text, 'FontSize', font_size);
box(hax, 'on');
drawnow('expose');
end
