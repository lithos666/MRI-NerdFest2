clear;
close all;
tic;
% Simple IOring permanent-magnet shimming practice for GNU Octave.
% This follows the same script structure and plotting helpers as the

script_dir = fileparts(mfilename('fullpath'));
if isempty(script_dir)
    script_dir = pwd;
end
addpath(script_dir);

draw_3d = true;
make_plots = true;
ConfigureOctaveGraphics();

%% Field of view and design settings

FOV_half = 25;
FOV_1 = -FOV_half:1:FOV_half;
FOV_2 = -FOV_half:1:FOV_half;
FOV_3 = 0;
slice_offsets_mm = [-2, -1, 0, 1, 2];
surface_name = 'z';
n_per_group = 1;
font_size = 14;
n_bar = 10;
target_homogeneity_ppm = 1000;
main_z_spacing_mm = 38;

bar_pitch_deg = 360 / n_bar;
array_rotation_deg = bar_pitch_deg / 2;

%% Main array with 12mm magnets

% Each row is [radial position R, positive axial position Z] in mm.
quadrant_main_loc = [];
quadrant_main_angle = [];

main_dim = [12, 12, 12];
main_Br = 1.43;

%% Shim array with 10mm magnets

% Each row is [radial position R, positive axial position Z] in mm.
quadrant_shim_loc = [];
quadrant_shim_angle = [];

shim_dim = [10, 10, 10];
shim_Br = 1.43;

%% Check the design constraints

main_parameters_empty = ...
    isempty(quadrant_main_loc) || isempty(quadrant_main_angle);
shim_parameters_empty = ...
    isempty(quadrant_shim_loc) || isempty(quadrant_shim_angle);

main_z_positions = [];
main_radius_min = NaN;
main_radius_max = NaN;
spacing_tolerance = 1e-9;

if ~main_parameters_empty
    main_z_positions = sort(unique(quadrant_main_loc(:, 2)));
    n_main_z_positions = sum(1 + (main_z_positions > 1e-9));
    main_radius_min = min(quadrant_main_loc(:, 1));
    main_radius_max = max(quadrant_main_loc(:, 1));

    assert(all(abs(diff(main_z_positions) - main_z_spacing_mm) < ...
        spacing_tolerance), ...
        'Adjacent positive-Z main-magnet planes must be 38 mm apart.');
    assert(abs(2 * main_z_positions(1) - main_z_spacing_mm) < ...
        spacing_tolerance, ...
        ['The two main-magnet planes nearest Z = 0 must also be ', ...
         '38 mm apart.']);
    assert(n_main_z_positions <= 10, ...
        'The complete array may use at most 10 main-magnet Z positions.');
    assert(all(quadrant_main_loc(:, 1) > FOV_half), ...
        'Every main-magnet radius must be larger than FOV_half.');
    assert(all(ismember(mod(quadrant_main_angle, 360), [0, 180])), ...
        'Main-magnet angles are restricted to 0 or 180 degrees.');
    assert(numel(unique(mod(quadrant_main_angle, 360))) == 1, ...
        ['All main magnets on the positive-Z side must face the ', ...
         'same direction.']);

    % Enforce touching equal-angle cubes and a 12 mm edge gap when the
    % magnetization angle changes.
    main_plane_positions = unique(quadrant_main_loc(:, 2));
    for z_index = 1:numel(main_plane_positions)
        rows = find(abs(quadrant_main_loc(:, 2) - ...
            main_plane_positions(z_index)) < spacing_tolerance);
        [sorted_radius, order] = sort(quadrant_main_loc(rows, 1));
        sorted_angle = mod(quadrant_main_angle(rows(order)), 360);
        radial_spacing = diff(sorted_radius);
        same_angle = sorted_angle(1:end-1) == sorted_angle(2:end);

        assert(all(abs(radial_spacing(same_angle) - main_dim(2)) < ...
            spacing_tolerance), ...
            ['Main magnets with the same angle must have center ', ...
             'spacing equal to one cube width so their radial edges touch.']);
        assert(all(radial_spacing(~same_angle) >= ...
            2 * main_dim(2) - spacing_tolerance), ...
            ['Main magnets with different angles must have at least ', ...
             'one cube width of clear radial space between their edges.']);
    end
end

if ~shim_parameters_empty
    assert(all(quadrant_shim_loc(:, 1) > FOV_half), ...
        'Every shim radius must be larger than FOV_half.');
    assert(all(ismember(mod(quadrant_shim_angle, 360), ...
        [0, 90, 180, 270])), ...
        'Shim angles must be 0, 90, 180, or 270 degrees.');

    if ~main_parameters_empty
        all_nonnegative_z_positions = unique( ...
            [quadrant_main_loc(:, 2); quadrant_shim_loc(:, 2)]);
        assert(numel(all_nonnegative_z_positions) <= 10, ...
            'The nonnegative-Z design may use at most 10 unique Z positions.');
        assert(all(quadrant_shim_loc(:, 1) >= main_radius_min & ...
                   quadrant_shim_loc(:, 1) <= main_radius_max), ...
            ['Shim radii must remain inside the radial range of the ', ...
             'main magnets.']);

        % Keep each shim plane at a legal main-magnet gap midpoint.
        shim_radial_size = shim_dim(2);
        shim_axial_size = shim_dim(3);
        main_shim_clearance = (main_dim(3) + shim_axial_size) / 2;
        gap_midpoints = [0; ...
            (main_z_positions(1:end-1) + ...
             main_z_positions(2:end)) / 2];
        midpoint_clearance = [main_z_positions(1); ...
            diff(main_z_positions) / 2];

        for shim_index = 1:size(quadrant_shim_loc, 1)
            shim_z = quadrant_shim_loc(shim_index, 2);
            midpoint_index = find( ...
                abs(gap_midpoints - shim_z) < spacing_tolerance, 1);
            assert(~isempty(midpoint_index), ...
                ['Every shim must be at the exact axial midpoint ', ...
                 'between two adjacent main-magnet planes.']);
            assert(midpoint_clearance(midpoint_index) >= ...
                    main_shim_clearance - spacing_tolerance, ...
                'A shim does not fit inside its main-magnet axial gap.');
        end

        % Shim cubes may touch but cannot overlap in the R-Z quadrant.
        for first_index = 1:(size(quadrant_shim_loc, 1) - 1)
            for second_index = (first_index + 1):size(quadrant_shim_loc, 1)
                radial_spacing = abs( ...
                    quadrant_shim_loc(second_index, 1) - ...
                    quadrant_shim_loc(first_index, 1));
                axial_spacing = abs( ...
                    quadrant_shim_loc(second_index, 2) - ...
                    quadrant_shim_loc(first_index, 2));
                assert(radial_spacing >= ...
                        shim_radial_size - spacing_tolerance || ...
                       axial_spacing >= ...
                        shim_axial_size - spacing_tolerance, ...
                    'Shim cubes must not overlap in the R-Z quadrant.');
            end
        end
    end
end

%% Generate and separate the main and shim arrays

if main_parameters_empty
    active_main_loc = zeros(0, 2);
    active_main_angle = zeros(0, 1);
else
    active_main_loc = quadrant_main_loc;
    active_main_angle = quadrant_main_angle;
end

if shim_parameters_empty
    active_quadrant_shim_loc = zeros(0, 2);
    active_quadrant_shim_angle = zeros(0, 1);
else
    active_quadrant_shim_loc = quadrant_shim_loc;
    active_quadrant_shim_angle = quadrant_shim_angle;
end

if main_parameters_empty && shim_parameters_empty
    warning(['No complete main- or shim-magnet parameter pair was ', ...
             'supplied. Field calculation was skipped.']);
    return;
end

all_quadrant_loc = [active_main_loc; active_quadrant_shim_loc];
all_quadrant_angle = [active_main_angle; active_quadrant_shim_angle];
all_quadrant_dim = [ ...
    repmat(main_dim, size(active_main_loc, 1), 1); ...
    repmat(shim_dim, size(active_quadrant_shim_loc, 1), 1)];
all_quadrant_Br = [ ...
    main_Br * ones(size(active_main_loc, 1), 1); ...
    shim_Br * ones(size(active_quadrant_shim_loc, 1), 1)];

[loc_all, angle_all, dim_all, Br_all] = ...
    GenerateIORingPairFromQuadrant_octave( ...
        n_bar, all_quadrant_loc, all_quadrant_dim, ...
        all_quadrant_angle, all_quadrant_Br, make_plots);

% Apply the same half-bar-pitch rigid rotation as the MATLAB practice.
rotation_xy = [cosd(array_rotation_deg), -sind(array_rotation_deg); ...
               sind(array_rotation_deg),  cosd(array_rotation_deg)];
loc_all(:, 1:2) = loc_all(:, 1:2) * rotation_xy.';
angle_all(:, 1) = mod(angle_all(:, 1) + array_rotation_deg, 360);

n_main = n_bar * sum(1 + (active_main_loc(:, 2) > 1e-9));
main_indices = 1:n_main;
shim_indices = (n_main + 1):size(loc_all, 1);

Main_MT = MagTetris().AssignCuboid( ...
    loc_all(main_indices, :), angle_all(main_indices, :), ...
    Br_all(main_indices), dim_all(main_indices, :));
Shim_MT = MagTetris().AssignCuboid( ...
    loc_all(shim_indices, :), angle_all(shim_indices, :), ...
    Br_all(shim_indices), dim_all(shim_indices, :));

fprintf('Main magnets                : %d\n', Main_MT.cub_numMag);
fprintf('Shim magnets                : %d\n', Shim_MT.cub_numMag);
fprintf('Main radial range           : %.1f to %.1f mm\n', ...
    main_radius_min, main_radius_max);
fprintf('Shim seed rings\n');
for shim_index = 1:size(active_quadrant_shim_loc, 1)
    fprintf('  R = %.1f mm, Z = +/-%.1f mm, angle = %.0f degrees\n', ...
        active_quadrant_shim_loc(shim_index, 1), ...
        active_quadrant_shim_loc(shim_index, 2), ...
        active_quadrant_shim_angle(shim_index));
end
fprintf('\n');

%% Calculate the unshimmed and shimmed five-slice Bz fields

n_slice = numel(slice_offsets_mm);
assert(n_slice > 0, 'slice_offsets_mm cannot be empty.');

field_objects = {Main_MT, Shim_MT};
Bz_averages = cell(2, 1);
Bz_stacks = cell(2, 1);

for object_index = 1:2
    current_MT = field_objects{object_index};
    [~, ~, Bz_slice] = current_MT.Field2D( ...
        FOV_1, FOV_2, slice_offsets_mm(1), 'z', n_per_group);
    current_stack = zeros([size(Bz_slice), n_slice]);
    current_stack(:, :, 1) = Bz_slice;

    for slice_index = 2:n_slice
        [~, ~, current_stack(:, :, slice_index)] = ...
            current_MT.Field2D(FOV_1, FOV_2, ...
                slice_offsets_mm(slice_index), 'z', n_per_group);
    end

    Bz_stacks{object_index} = current_stack;
    Bz_averages{object_index} = mean(current_stack, 3);
end

Bz_main = Bz_averages{1};
Bz_shim = Bz_averages{2};
Bz_main_slices = Bz_stacks{1};
Bz_shim_slices = Bz_stacks{2};
Bz_total = Bz_main + Bz_shim;
Bz_total_slices = Bz_main_slices + Bz_shim_slices;

% Keep only the circular field of view and convert tesla to millitesla.
[FOV_x, FOV_y] = meshgrid(FOV_1, FOV_2);
outside_FOV = hypot(FOV_x, FOV_y) > FOV_half;

Bz_main_mT = 1e3 * Bz_main;
Bz_shim_mT = 1e3 * Bz_shim;
Bz_total_mT = 1e3 * Bz_total;
Bz_main_mT(outside_FOV) = NaN;
Bz_shim_mT(outside_FOV) = NaN;
Bz_total_mT(outside_FOV) = NaN;

Bz_main_slices_mT = 1e3 * Bz_main_slices;
Bz_shim_slices_mT = 1e3 * Bz_shim_slices;
Bz_total_slices_mT = 1e3 * Bz_total_slices;
for slice_index = 1:n_slice
    main_slice = Bz_main_slices_mT(:, :, slice_index);
    shim_slice = Bz_shim_slices_mT(:, :, slice_index);
    total_slice = Bz_total_slices_mT(:, :, slice_index);
    main_slice(outside_FOV) = NaN;
    shim_slice(outside_FOV) = NaN;
    total_slice(outside_FOV) = NaN;
    Bz_main_slices_mT(:, :, slice_index) = main_slice;
    Bz_shim_slices_mT(:, :, slice_index) = shim_slice;
    Bz_total_slices_mT(:, :, slice_index) = total_slice;
end

% Calculate the same metrics for the main, shim-only, and summed fields.
metric_stacks = { ...
    Bz_main_slices_mT, Bz_shim_slices_mT, Bz_total_slices_mT};
metric_results = cell(3, 1);
for metric_index = 1:3
    B_valid = metric_stacks{metric_index};
    B_valid = B_valid(isfinite(B_valid));
    if isempty(B_valid)
        error('Bmap contains no valid finite values.');
    end

    current_metrics = struct();
    current_metrics.Bmax = max(B_valid);
    current_metrics.Bmin = min(B_valid);
    current_metrics.Bmean = mean(B_valid);
    current_metrics.Bstd = std(B_valid);
    current_metrics.deltaB_pp = ...
        current_metrics.Bmax - current_metrics.Bmin;
    current_metrics.hom_ppm_pp = current_metrics.deltaB_pp / ...
        abs(current_metrics.Bmean) * 1e6;
    current_metrics.hom_ppm_std = current_metrics.Bstd / ...
        abs(current_metrics.Bmean) * 1e6;
    metric_results{metric_index} = current_metrics;
end

metrics_before = metric_results{1};
metrics_shim = metric_results{2};
metrics_after = metric_results{3};
improvement_percent = 100 * ...
    (1 - metrics_after.hom_ppm_pp / metrics_before.hom_ppm_pp);

if ~main_parameters_empty
    assert(metrics_before.Bmin > 0, ...
        ['Main-array Bz must point in the positive Z direction ', ...
         'throughout the sampled FOV.']);
end

if ~main_parameters_empty && ~shim_parameters_empty
    assert(metrics_after.hom_ppm_pp < metrics_before.hom_ppm_pp, ...
        'The selected shim layout did not improve peak-to-peak homogeneity.');
    assert(metrics_after.Bmin > 0, ...
        'Final Bz must point in the positive Z direction throughout the sampled FOV.');
end

metric_labels = {'Before shimming', 'Shim-only field', 'After shimming'};
metrics_to_print = {metrics_before, metrics_shim, metrics_after};
for metric_index = 1:3
    current_metrics = metrics_to_print{metric_index};
    if metric_index > 1
        fprintf('\n');
    end
    fprintf('%s\n', metric_labels{metric_index});
    fprintf('Mean Bz                     : %.6f mT\n', ...
        current_metrics.Bmean);
    fprintf('Maximum Bz                  : %.6f mT\n', ...
        current_metrics.Bmax);
    fprintf('Minimum Bz                  : %.6f mT\n', ...
        current_metrics.Bmin);
    fprintf('Peak-to-peak homogeneity    : %.6f ppm\n', ...
        current_metrics.hom_ppm_pp);
    fprintf('Standard-deviation homogeneity: %.6f ppm\n', ...
        current_metrics.hom_ppm_std);
end
fprintf('\nPeak-to-peak improvement    : %.2f %%\n\n', ...
    improvement_percent);

%% Plot the main, shim-only, and final Bz fields

if make_plots
    % Display-only copies suppress field magnitudes below 0.1 mT. The
    % original maps and all previously calculated metrics remain unchanged.
    Bz_main_plot_mT = Bz_main_mT;
    Bz_shim_plot_mT = Bz_shim_mT;
    Bz_total_plot_mT = Bz_total_mT;
    Bz_main_plot_mT(abs(Bz_main_plot_mT) < 0.1) = 0;
    Bz_shim_plot_mT(abs(Bz_shim_plot_mT) < 0.1) = 0;
    Bz_total_plot_mT(abs(Bz_total_plot_mT) < 0.1) = 0;

    performance_maps = { ...
        Bz_main_plot_mT, Bz_shim_plot_mT, Bz_total_plot_mT};
    performance_names = {'Main magnets', 'Shim magnets only', 'Final sum'};
    performance_metrics = {metrics_before, metrics_shim, metrics_after};

    % Match the MATLAB version: show all three performance maps together in
    % one wide Figure 2, with each map's metrics in its title.
    hperformance = figure(2, 'Visible', 'on');
    clf(hperformance, 'reset');
    set(hperformance, 'Units', 'pixels', 'Color', 'w');
    performance_figure_position = get(hperformance, 'Position');
    performance_figure_position(3) = max(performance_figure_position(3), 1600);
    performance_figure_position(4) = max(performance_figure_position(4), 700);
    set(hperformance, 'Position', performance_figure_position);
    drawnow('expose');

    performance_axes_positions = [ ...
        0.055, 0.10, 0.205, 0.48; ...
        0.365, 0.10, 0.205, 0.48; ...
        0.675, 0.10, 0.205, 0.48];
    performance_colorbar_positions = [ ...
        0.275, 0.10, 0.014, 0.48; ...
        0.585, 0.10, 0.014, 0.48; ...
        0.895, 0.10, 0.014, 0.48];
    performance_metric_positions = [ ...
        0.055, 0.64, 0.205, 0.24; ...
        0.365, 0.64, 0.205, 0.24; ...
        0.675, 0.64, 0.205, 0.24];
    metric_line_y = [0.88, 0.62, 0.36, 0.10];

    for map_index = 1:3
        current_map = performance_maps{map_index};
        current_metrics = performance_metrics{map_index};
        finite_values = current_map(isfinite(current_map));
        metric_title_lines = { ...
            performance_names{map_index}; ...
            sprintf('Mean %.4f mT', current_metrics.Bmean); ...
            sprintf('Min %.4f | Max %.4f mT', ...
                current_metrics.Bmin, current_metrics.Bmax); ...
            sprintf('Peak-to-peak %.1f ppm', ...
                current_metrics.hom_ppm_pp)};

        hmap = axes('Parent', hperformance, 'Units', 'normalized', ...
            'Position', performance_axes_positions(map_index, :));
        [hmap, hcolorbar] = PlotFieldMap(2, FOV_1, FOV_2, current_map, ...
            surface_name, '', ...
            [min(finite_values), max(finite_values)], ...
            font_size, false, hmap);
        set(hmap, 'Units', 'normalized', ...
            'Position', performance_axes_positions(map_index, :));
        set(hcolorbar, 'Units', 'normalized', ...
            'Position', performance_colorbar_positions(map_index, :));

        % The FLTK title renderer displays only the first line of multiline
        % titles. Draw four independent text rows in a dedicated invisible
        % axes so every field metric is always visible.
        hmetrics = axes('Parent', hperformance, 'Units', 'normalized', ...
            'Position', performance_metric_positions(map_index, :), ...
            'Visible', 'off', 'XLim', [0, 1], 'YLim', [0, 1], ...
            'Tag', sprintf('FieldMetricsAxes%d', map_index));
        for metric_line_index = 1:4
            text(hmetrics, 0.5, metric_line_y(metric_line_index), ...
                metric_title_lines{metric_line_index}, ...
                'Units', 'normalized', ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'middle', ...
                'FontSize', font_size, ...
                'FontWeight', 'bold', ...
                'Clipping', 'off');
        end
    end
    drawnow('expose');

    if draw_3d
        DrawMagnetization(Main_MT.cub_loc, Main_MT.cub_angle, ...
            Main_MT.cub_dim, [0.85, 0.15, 0.15], ...
            FOV_1, FOV_2, FOV_3, surface_name, ...
            Bz_total_plot_mT, true);
        DrawMagnetization(Shim_MT.cub_loc, Shim_MT.cub_angle, ...
            Shim_MT.cub_dim, [0.15, 0.35, 0.90], ...
            FOV_1, FOV_2, FOV_3, surface_name, ...
            [], false);

        hfig = figure(100);
        hax = findobj(hfig, 'Type', 'axes', 'Tag', 'MagTetris3DAxes');
        if ~isempty(hax)
            title(hax(1), 'Main magnets (red) and shim magnets (blue)');
        end
    end
end

toc;
