% Example MagTetris+ application for a small permanent magnet and ferromagnetic setup.
% Edit the script variables below to change the magnet, ferro, and FOV setup.

clear;
%close all;

% PMA 
Br_all = [1.43,1.43];
angle_all = [0,0,90;20,50,0];
magnet_dim_all = [10,10,10;10,10,10];
loc_all_list = [0,0,-7;15,0,-7];

% Default ferro 
orient_angle_raw = [0,0,0;0,0,0];
geo_param_raw = [10,10,10;5,5,5];
ferro_loc_raw = [0,0,6;0,10,6;];



% FoV settings
fov_size = 15;
fov_plane_value = 15;
res = 0.1;  % the lower it is, the more clear the image
% FOV definition
FOV_half_1 = fov_size;
FOV_1 = -FOV_half_1:res:FOV_half_1;

FOV_half_2 = FOV_half_1;
FOV_2 = -FOV_half_2:res:FOV_half_2;

FOV_3 = fov_plane_value;

surface = 'z';      % 'x' - yz plane, 'y' - xz plane, 'z' - xy plane


PMA_MT = MagTetris();
PMA_MT = PMA_MT.AssignCuboid(loc_all_list,angle_all,Br_all,magnet_dim_all);

% Ferromagnetic Calculation
solver_options.verbose = false;

tic;
Ferro_MT = MagTetrisPlus(PMA_MT, ferro_loc_raw, orient_angle_raw, geo_param_raw, solver_options);

All_MT = PMA_MT;
All_MT = All_MT.ConcatMT(Ferro_MT);


[ferro_Bx,ferro_By,ferro_Bz] = All_MT.Field2D(FOV_1,FOV_2,FOV_3,surface,1);

Bx = ferro_Bx;
By = ferro_By;
Bz = ferro_Bz;

trim_upper_limit=FOV_half_1*2/res;
Bx = Bx(1:trim_upper_limit, 1:trim_upper_limit);
By = By(1:trim_upper_limit, 1:trim_upper_limit);
Bz = Bz(1:trim_upper_limit, 1:trim_upper_limit);

FOV_1 = FOV_1(1:trim_upper_limit);
FOV_2 = FOV_2(1:trim_upper_limit);

% Only keep the circular region
for idx_1=1:length(FOV_1)
    for idx_2=1:length(FOV_2)
        r = sqrt(FOV_1(idx_1)^2 + FOV_2(idx_2)^2);
        if r > FOV_half_1
            Bx(idx_2,idx_1) = NaN;
            By(idx_2,idx_1) = NaN;
            Bz(idx_2,idx_1) = NaN;
        end
    end
end

% Change the unit from [T] to [mT]
Bx = Bx*1e3;
By = By*1e3;
Bz = Bz*1e3;

% Colorbar for all plots
min_all = min(min(min(min(Bx)),  min(min(By))) , min(min(Bz)));
max_all = max(max(max(max(Bx)),  max(max(By))) , max(max(Bz)));

% Plot the Bx/By/Bz field component
font_size = 10;
color_limits = [min_all, max_all];
PlotFieldMap(1, FOV_1, FOV_2, Bx, surface, 'Bx(M+)', color_limits, font_size, false);
PlotFieldMap(2, FOV_1, FOV_2, By, surface, 'By(M+)', color_limits, font_size, false);
PlotFieldMap(3, FOV_1, FOV_2, Bz, surface, 'Bz(M+)', color_limits, font_size, false);

toc;

DrawMagnetization(PMA_MT.cub_loc,PMA_MT.cub_angle,PMA_MT.cub_dim,"red",FOV_1,FOV_2,FOV_3,surface, Bz);
clf reset;
% Visualization of the magnetization
DrawMagnetization(All_MT.cub_loc,All_MT.cub_angle,All_MT.cub_dim,[0.8 0.8 0.8],FOV_1,FOV_2,FOV_3,surface, Bz);
DrawMagnetization(PMA_MT.cub_loc,PMA_MT.cub_angle,PMA_MT.cub_dim,"red",FOV_1,FOV_2,FOV_3);
