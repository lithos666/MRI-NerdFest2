% The class definition of MagTetris with the support of cuboid and
% arc-shaped/fan-shaped permanent magnets. The current PMA-rotation (self.RotateArray)
% and force calculation functions only supports cuboid magnets.
% @author  Ting-Ou Liang
% @version 2024/02/23


classdef MagTetris
    % Analytical magnetic-field, force, and weight utilities for permanent magnets.
    % Input:
    %   None for the class itself. Create an object with MagTetris().
    % Output:
    %   MagTetris object containing cuboid and fan-shaped magnet definitions.

    properties
        % Parameters for cuboid magnets
        cub_loc         % Center location [mm]
        cub_angle       % Orientation angle (yaw,pitch,roll) [degree] with respect to +y polarization
        cub_dim         % Magnet dimension (x,y,z) [mm] when placed to have +y polarization
        cub_Br          % Magnet remanence in [T]

        % Parameters for fan-shaped magnets
        fan_rho         % Each row is the inner & outer radii [R_in, R_out] for each fan magnet
        fan_phi         % HALF of the angle span of each fan magnet
        fan_z           % The z-boundaries [Z_low, Z_upp] for each fan magnet
        fan_angle       % 3D orientation angles (yaw,pitch,roll) of all magnets
        fan_Br          % Magnet remanence in [T]
        fan_pol         % The polarization mode of each magnet (1: inward, 2: outward)
        fan_center_loc  % Each row is the local origin (x,y,z) for each magnet polar coordinate

        % Other useful parameters
        % Total number of magnets
        cub_numMag      % The number of cuboid magnets
        fan_numMag      % The number of fan-shaped magnets
        
        % Variables for PMA rotation
        cub_locRot      % The center location of all cuboid magnets after a rotation of the whole PMA
        angleRot        % The orientation angle of all magnets after a rotation of the whole PMA
    end

    methods
        % ========= Initialization Functions ========== %
        % Initialization function
        function self = MagTetris()
        % Create an empty MagTetris object.
        % Input:
        %   None.
        % Output:
        %   self - Empty MagTetris object with zero cuboid and fan magnets.
            self.cub_numMag = 0;
            self.fan_numMag = 0;
        end

        % Assign design parameters for cuboid magnets
        function self = AssignCuboid(self,loc_list,angle_list,Br_list,dim_list)
        % Assign cuboid permanent magnets to the MagTetris object.
        % Input:
        %   self - MagTetris object.
        %   loc_list - Cuboid center locations [mm].
        %   angle_list - Cuboid yaw, pitch, and roll angles [degree].
        %   Br_list - Cuboid remanence values [T].
        %   dim_list - Cuboid dimensions [mm].
        % Output:
        %   self - Updated MagTetris object.

            % loc: [n,3] matrix with each row as (x,y,z)
		    self.cub_loc = loc_list;
		    % angle: [n,3] matrix with each row as (yaw,pitch,roll)
		    self.cub_angle = angle_list;
		    % dim: [n,3] matrix with each row as (dim_x,dim_y,dim_z)
		    self.cub_dim = dim_list;
		    % Br: length n vector
		    self.cub_Br = Br_list;

            self.cub_numMag = length(self.cub_Br);

            self.cub_locRot = self.cub_loc;
            self.angleRot = self.cub_angle;
        end

        % Assign design parameters for fan magnets
        function self = AssignFan(self,center_loc_list,rho_list,phi_list,z_list,angle_list,Br_list,pol_list)
        % Assign fan-shaped permanent magnets to the MagTetris object.
        % Input:
        %   self - MagTetris object.
        %   center_loc_list - Fan local-origin locations [mm].
        %   rho_list - Inner and outer radii [R_in, R_out] [mm].
        %   phi_list - Half-angle span for each fan magnet [degree].
        %   z_list - Axial length or bounds for each fan magnet [mm].
        %   angle_list - Fan yaw, pitch, and roll angles [degree].
        %   Br_list - Fan remanence values [T].
        %   pol_list - Polarization mode, 1 inward or 2 outward.
        % Output:
        %   self - Updated MagTetris object.

            % center_loc: [n,3] matrix with each row as (xc,yc,zc)
            self.fan_center_loc = center_loc_list;
            % rho: [n,2] matrix with each row as (R_in, R_out)
		    self.fan_rho = rho_list;
            % phi: length n vector
		    self.fan_phi = phi_list;
            % z: length n vector
		    self.fan_z = z_list;
		    % angle: [n,3] matrix with each row as (yaw,pitch,roll)
		    self.fan_angle = angle_list;
		    % Br: length n vector
		    self.fan_Br = Br_list;
            % pol_mode: length n vector
		    self.fan_pol = pol_list;

            self.fan_numMag = length(self.fan_Br);

            self.angleRot = self.fan_angle;
        end

        % Rotate the whole array w.r.t. a pivot.
        % If not given, the pivot will be the origin (0,0,0)
        % Currently the rotation is only for cuboid magnets
        function self = RotateArray(self,angle_rot,pivot)
        % Rotate the cuboid magnet array around the origin or a pivot.
        % Input:
        %   self - MagTetris object.
        %   angle_rot - Array yaw, pitch, and roll rotation [degree].
        %   pivot - Optional pivot point for the rotation [mm].
        % Output:
        %   self - Updated MagTetris object with rotated cuboid locations.

            % Assign new angle
		    self.angleRot(:,1) = self.cub_angle(:,1) + angle_rot(1);
		    self.angleRot(:,2) = self.cub_angle(:,2) + angle_rot(2);
		    self.angleRot(:,3) = self.cub_angle(:,3) + angle_rot(3);


            % If a pivot is given
            if nargin == 3
                % Shift the location
                loc_shift = self.cub_loc - pivot;
                loc_shift_rot = RotationUtils.rotate3D(loc_shift,angle_rot,1);
                self.cub_locRot = loc_shift_rot + pivot;
            else
		        self.cub_locRot = RotationUtils.rotate3D(self.cub_loc,angle_rot,1);
            end
        end

        % Concatenate another MagTetris object with the existing one
        function self = ConcatMT(self,other_MT)
        % Append magnets from another MagTetris object.
        % Input:
        %   self - MagTetris object to update.
        %   other_MT - MagTetris object to append.
        % Output:
        %   self - Concatenated MagTetris object.
            if other_MT.cub_numMag ~= 0
                self.cub_numMag = self.cub_numMag + other_MT.cub_numMag;
                self.cub_loc = [self.cub_loc;other_MT.cub_loc];
                self.cub_angle = [self.cub_angle;other_MT.cub_angle];
                self.cub_Br = [self.cub_Br,other_MT.cub_Br];
                self.cub_dim = [self.cub_dim;other_MT.cub_dim];
            end

            if other_MT.fan_numMag ~= 0
                self.fan_numMag = self.fan_numMag + other_MT.fan_numMag;
                self.fan_rho = [self.fan_rho,other_MT.fan_rho];
                self.fan_phi = [self.fan_phi,other_MT.fan_phi];
                self.fan_z = [self.fan_z,other_MT.fan_z];
                self.fan_angle = [self.fan_angle;other_MT.fan_angle];
                self.fan_Br = [self.fan_Br,other_MT.fan_Br];
                self.fan_pol = [self.fan_pol,other_MT.fan_pol];
                self.fan_center_loc = [self.fan_center_loc,other_MT.fan_center_loc];
            end
        end
        % ========= Magnetic Field Calculation ========== %

        % Compute magnetic field for a specified 2D FoV
        function [Bx,By,Bz] = Field2D(self,FOV_1,FOV_2,FOV_3,surface,n_per_group)
        % Compute magnetic field components on a 2D observation plane.
        % Input:
        %   self - MagTetris object.
        %   FOV_1 - First coordinate vector for the observation plane [mm].
        %   FOV_2 - Second coordinate vector for the observation plane [mm].
        %   FOV_3 - Fixed coordinate for the observation plane [mm].
        %   surface - Plane selector: 'x', 'y', 'z', 'c', or 's'.
        %   n_per_group - Number of magnets grouped for vectorized calculation.
        % Output:
        %   Bx - X-component magnetic field map [T].
        %   By - Y-component magnetic field map [T].
        %   Bz - Z-component magnetic field map [T].

            FOV1_len = length(FOV_1);
            FOV2_len = length(FOV_2);
            Bx = zeros(FOV2_len,FOV1_len);
            By = zeros(FOV2_len,FOV1_len);
            Bz = zeros(FOV2_len,FOV1_len);

            % ===== cuboid magnet =====
            % Group selection
            if n_per_group > 1 && self.cub_numMag ~= 0
                % Multiple magnets in a group
                num_whole = floor(self.cub_numMag/n_per_group);
                n_part = mod(self.cub_numMag,n_per_group);
                for i=0:num_whole
                    idx_start = i*n_per_group + 1;
                    if i == num_whole
                        loc_curr = self.cub_loc(idx_start:end,:);
                        angle_curr = self.cub_angle(idx_start:end,:);
                        dim_curr = self.cub_dim(idx_start:end,:);
                        Br_curr = self.cub_Br(idx_start:end);

                        [Bx_curr, By_curr, Bz_curr] = self.Field2DMultiCuboid(FOV1_len,FOV2_len,n_part,FOV_1,FOV_2,FOV_3,dim_curr,loc_curr,angle_curr,Br_curr,surface);

                        Bx = Bx + Bx_curr;
				        By = By + By_curr;
				        Bz = Bz + Bz_curr;

                        %fprintf('Cuboid Magnet #%d\n',self.cub_numMag);
                    else
                        idx_end = (i+1)*n_per_group;
                        loc_curr = self.cub_loc(idx_start:idx_end,:);
                        angle_curr = self.cub_angle(idx_start:idx_end,:);
                        dim_curr = self.cub_dim(idx_start:idx_end,:);
                        Br_curr = self.cub_Br(idx_start:idx_end);

                        [Bx_curr, By_curr, Bz_curr] = self.Field2DMultiCuboid(FOV1_len,FOV2_len,n_per_group,FOV_1,FOV_2,FOV_3,dim_curr,loc_curr,angle_curr,Br_curr,surface);

                        Bx = Bx + Bx_curr;
				        By = By + By_curr;
				        Bz = Bz + Bz_curr;

                        %fprintf('Magnet #%d\n',idx_end);
                    end
                end
            else
                % Loop through every magnet
                parfor mag_idx=1:self.cub_numMag
                    loc_curr = self.cub_loc(mag_idx,:);
                    angle_curr = self.cub_angle(mag_idx,:);
                    dim_curr = self.cub_dim(mag_idx,:);
                    Br_curr = self.cub_Br(mag_idx);

                    [Bx_curr, By_curr, Bz_curr] = self.Field2DSingleCuboid(FOV1_len,FOV2_len,FOV_1,FOV_2,FOV_3,dim_curr,loc_curr,angle_curr,Br_curr,surface);

                    Bx = Bx + Bx_curr;
			        By = By + By_curr;
			        Bz = Bz + Bz_curr;

%                     if mod(mag_idx,50) == 0 || mag_idx == self.cub_numMag
%                         fprintf('Cuboid Magnet #%d\n',mag_idx);
%                     end
                end
            end

            % ===== fan magnet =====
            % Loop through every magnet
            for mag_idx=1:self.fan_numMag
                rho_curr = self.fan_rho(mag_idx,:);
                phi_curr = self.fan_phi(mag_idx);
                z_curr = self.fan_z(mag_idx);
                center_loc_curr = self.fan_center_loc(mag_idx,:);
                angle_curr = self.fan_angle(mag_idx,:);
                Br_curr = self.fan_Br(mag_idx);
                pol_curr = self.fan_pol(mag_idx);

                [Bx_curr, By_curr, Bz_curr] = self.Field2DSingleFan(FOV1_len,FOV2_len,FOV_1,FOV_2,FOV_3,center_loc_curr,angle_curr,rho_curr,phi_curr,z_curr,Br_curr,pol_curr,surface,n_per_group);

                Bx = Bx + Bx_curr;
		        By = By + By_curr;
		        Bz = Bz + Bz_curr;

                if mod(mag_idx,5) == 0 || mag_idx == self.fan_numMag
                    fprintf('Fan Magnet #%d\n',mag_idx);
                end
            end
        end

        % Compute magnetic field for a given set of observation points
        function [Bx,By,Bz] = Field2DFree(self,FOV_x,FOV_y,FOV_z)
        % Compute magnetic field components at arbitrary observation points.
        % Input:
        %   self - MagTetris object.
        %   FOV_x - X coordinates of observation points [mm].
        %   FOV_y - Y coordinates of observation points [mm].
        %   FOV_z - Z coordinates of observation points [mm].
        % Output:
        %   Bx - X-component magnetic field values [T].
        %   By - Y-component magnetic field values [T].
        %   Bz - Z-component magnetic field values [T].

            FOV_len = length(FOV_x);
            Bx = zeros(FOV_len,1);
            By = zeros(FOV_len,1);
            Bz = zeros(FOV_len,1);

            % ===== cuboid magnet =====
            
            % Loop through every magnet
            for mag_idx=1:self.cub_numMag
                loc_curr = self.cub_loc(mag_idx,:);
                angle_curr = self.cub_angle(mag_idx,:);
                dim_curr = self.cub_dim(mag_idx,:);
                Br_curr = self.cub_Br(mag_idx);

                [Bx_curr, By_curr, Bz_curr] = self.Field2DSingleCuboidFree(FOV_x,FOV_y,FOV_z,dim_curr,loc_curr,angle_curr,Br_curr);

                Bx = Bx + Bx_curr;
		        By = By + By_curr;
		        Bz = Bz + Bz_curr;

            end

            % ===== fan magnet =====
            % Loop through every magnet
            for mag_idx=1:self.fan_numMag
                rho_curr = self.fan_rho(mag_idx,:);
                phi_curr = self.fan_phi(mag_idx);
                z_curr = self.fan_z(mag_idx);
                center_loc_curr = self.fan_center_loc(mag_idx,:);
                angle_curr = self.fan_angle(mag_idx,:);
                Br_curr = self.fan_Br(mag_idx);
                pol_curr = self.fan_pol(mag_idx);

                [Bx_curr, By_curr, Bz_curr] = self.Field2DSingleFanFree(FOV_x,FOV_y,FOV_z,center_loc_curr,angle_curr,rho_curr,phi_curr,z_curr,Br_curr,pol_curr);

                Bx = Bx + Bx_curr;
		        By = By + By_curr;
		        Bz = Bz + Bz_curr;

            end
        end

        % ========= Helper Functions ========= %

        % Compute the 2D magnetic field produced by a single cuboid magnet
        function [Bx,By,Bz] = Field2DSingleCuboid(self,FOV1_len,FOV2_len,FOV_1,FOV_2,FOV_3,magnet_dim,magnet_loc,angle,Br,surface)
	    % Compute field components from one cuboid magnet on a 2D plane.
        % Input:
        %   self - MagTetris object.
        %   FOV1_len - Number of points in the first FOV direction.
        %   FOV2_len - Number of points in the second FOV direction.
        %   FOV_1 - First coordinate vector for the observation plane [mm].
        %   FOV_2 - Second coordinate vector for the observation plane [mm].
        %   FOV_3 - Fixed coordinate for the observation plane [mm].
        %   magnet_dim - Cuboid dimensions [mm].
        %   magnet_loc - Cuboid center location [mm].
        %   angle - Cuboid yaw, pitch, and roll angles [degree].
        %   Br - Cuboid remanence [T].
        %   surface - Plane selector: 'x', 'y', 'z', 'c', or 's'.
        % Output:
        %   Bx - X-component magnetic field map [T].
        %   By - Y-component magnetic field map [T].
        %   Bz - Z-component magnetic field map [T].
            
            B_all_local = zeros(FOV1_len*FOV2_len,3);
            if Br == 0
			    Bx = zeros(FOV2_len,FOV1_len);
			    By = zeros(FOV2_len,FOV1_len);
			    Bz = zeros(FOV2_len,FOV1_len);
			    return;
            end

            % Change the coordinates
            % normal vector = y: XZ slice, z: XY slice, x: YZ slice
            if surface == 'x'
                [FOV_y,FOV_z] = meshgrid(FOV_1,FOV_2);
                shifted_x = FOV_3 - magnet_loc(1);
                shifted_y = FOV_y - magnet_loc(2);
                shifted_z = FOV_z - magnet_loc(3);
                FOV_shifted = ones(numel(FOV_y),3);
                FOV_shifted(:,1) = FOV_shifted(:,1)*shifted_x;
                FOV_shifted(:,2) = reshape(shifted_y,[],1);
                FOV_shifted(:,3) = reshape(shifted_z,[],1);
            elseif surface == 'y'
                [FOV_x,FOV_z] = meshgrid(FOV_1,FOV_2);
                shifted_x = FOV_x - magnet_loc(1);
                shifted_y = FOV_3 - magnet_loc(2);
                shifted_z = FOV_z - magnet_loc(3);
                FOV_shifted = ones(numel(FOV_x),3);
                FOV_shifted(:,1) = reshape(shifted_x,[],1);
                FOV_shifted(:,2) = FOV_shifted(:,2)*shifted_y;
                FOV_shifted(:,3) = reshape(shifted_z,[],1);
            elseif surface == 'z'
                [FOV_x,FOV_y] = meshgrid(FOV_1,FOV_2);
                shifted_x = FOV_x - magnet_loc(1);
                shifted_y = FOV_y - magnet_loc(2);
                shifted_z = FOV_3 - magnet_loc(3);
                FOV_shifted = ones(numel(FOV_x),3);
                FOV_shifted(:,1) = reshape(shifted_x,[],1);
                FOV_shifted(:,2) = reshape(shifted_y,[],1);
                FOV_shifted(:,3) = FOV_shifted(:,3)*shifted_z;
            elseif surface == 'c'
                % Cylindrical surface
                [FOV_phi,FOV_z] = meshgrid(FOV_1,FOV_2);
                FOV_rho = FOV_3*ones(size(FOV_phi));
                [FOV_x,FOV_y] = pol2cart(FOV_phi+pi/2,FOV_rho);
                shifted_x = FOV_x - magnet_loc(1);
                shifted_y = FOV_y - magnet_loc(2);
                shifted_z = FOV_z - magnet_loc(3);
                FOV_shifted = ones(numel(FOV_x),3);
                FOV_shifted(:,1) = reshape(shifted_x,[],1);
                FOV_shifted(:,2) = reshape(shifted_y,[],1);
                FOV_shifted(:,3) = reshape(shifted_z,[],1);
            elseif surface == 's'
                % Spherical surface
                [FOV_azi,FOV_elev] = meshgrid(FOV_1,FOV_2);
                FOV_rho = FOV_3*ones(size(FOV_azi));
                [FOV_x,FOV_y,FOV_z] = sph2cart(FOV_azi,FOV_elev,FOV_rho);
                shifted_x = FOV_x - magnet_loc(1);
                shifted_y = FOV_y - magnet_loc(2);
                shifted_z = FOV_z - magnet_loc(3);
                FOV_shifted = ones(numel(FOV_x),3);
                FOV_shifted(:,1) = reshape(shifted_x,[],1);
                FOV_shifted(:,2) = reshape(shifted_y,[],1);
                FOV_shifted(:,3) = reshape(shifted_z,[],1);
            end

            angle_rot = -angle;
            FOV_rotated = RotationUtils.rotate3D(FOV_shifted,angle_rot,2);

            % Source points of the magnet
            px = [-magnet_dim(1)/2,magnet_dim(1)/2];
            py = [-magnet_dim(2)/2,magnet_dim(2)/2];
            pz = [-magnet_dim(3)/2,magnet_dim(3)/2];
            C = {[1,2],[1,2],[1,2]};
            D = C;
            [D{:}] = ndgrid(C{:});
            zip_list = cell2mat(cellfun(@(m)m(:),D,'uni',0));
            num_elem = length(zip_list);
            % Calculated the field map
            for elem_idx=1:num_elem
                i = zip_list(elem_idx,1);
                j = zip_list(elem_idx,2);
                k = zip_list(elem_idx,3);
                % Distance between the observation point and the source point
                xd = FOV_rotated(:,1)-px(i);
                yd = FOV_rotated(:,2)-py(j);
                zd = FOV_rotated(:,3)-pz(k);
                r = sqrt((xd.^2)+(yd.^2)+(zd.^2));
                
                % Bx
                % For points aligned with the source points, the value
                % inside log() will be zero, but there is always a pair
                % of such value with opposite sign, so we set it to 0
                tmp_sum = zd+r;
                if sum(sum(tmp_sum==0))~=0
                    tmp_sum(tmp_sum==0) = 1;
                end
                Bx_curr = ((-1)^(i+j+k))*log(tmp_sum);
                B_all_local(:,1) = B_all_local(:,1) + Bx_curr;
                % By
                nume = xd.*zd;
                denom = yd.*r;
                B_all_local(:,2) = B_all_local(:,2) + ((-1)^(i+j+k+1))*(atan2(nume,denom));
                % Bz
                tmp_sum = xd+r;
                if sum(sum(tmp_sum==0))~=0
                    tmp_sum(tmp_sum==0) = 1;
                end
                Bz_curr = ((-1)^(i+j+k))*log(tmp_sum);
                B_all_local(:,3) = B_all_local(:,3) + Bz_curr;

            end
            % Multiply Bx/By/Bz by the common factor -Br/4pi
            B_all_local = -1*B_all_local*Br/(4*pi);
            % Change back the coordinates
            angle_rot = angle;
            B_all = RotationUtils.rotate3D(B_all_local,angle_rot,1);
            Bx = reshape(B_all(:,1),FOV2_len,FOV1_len);
            By = reshape(B_all(:,2),FOV2_len,FOV1_len);
            Bz = reshape(B_all(:,3),FOV2_len,FOV1_len);
        end

        % (FoV as points) Compute the 2D magnetic field produced by a single cuboid magnet
        function [Bx,By,Bz] = Field2DSingleCuboidFree(self,FOV_x,FOV_y,FOV_z,magnet_dim,magnet_loc,angle,Br)
	    % Compute field components from one cuboid magnet at arbitrary points.
        % Input:
        %   self - MagTetris object.
        %   FOV_x - X coordinates of observation points [mm].
        %   FOV_y - Y coordinates of observation points [mm].
        %   FOV_z - Z coordinates of observation points [mm].
        %   magnet_dim - Cuboid dimensions [mm].
        %   magnet_loc - Cuboid center location [mm].
        %   angle - Cuboid yaw, pitch, and roll angles [degree].
        %   Br - Cuboid remanence [T].
        % Output:
        %   Bx - X-component magnetic field values [T].
        %   By - Y-component magnetic field values [T].
        %   Bz - Z-component magnetic field values [T].
            
            FOV_len = length(FOV_x);
            B_all_local = zeros(FOV_len,3);
            if Br == 0
			    Bx = zeros(FOV_len,1);
			    By = zeros(FOV_len,1);
			    Bz = zeros(FOV_len,1);
			    return;
            end

            % Change the coordinates
            shifted_x = FOV_x - magnet_loc(1);
            shifted_y = FOV_y - magnet_loc(2);
            shifted_z = FOV_z - magnet_loc(3);
            FOV_shifted = [shifted_x,shifted_y,shifted_z];

            angle_rot = -angle;
            FOV_rotated = RotationUtils.rotate3D(FOV_shifted,angle_rot,2);

            % Source points of the magnet
            px = [-magnet_dim(1)/2,magnet_dim(1)/2];
            py = [-magnet_dim(2)/2,magnet_dim(2)/2];
            pz = [-magnet_dim(3)/2,magnet_dim(3)/2];
            C = {[1,2],[1,2],[1,2]};
            D = C;
            [D{:}] = ndgrid(C{:});
            zip_list = cell2mat(cellfun(@(m)m(:),D,'uni',0));
            num_elem = length(zip_list);
            % Calculated the field map
            for elem_idx=1:num_elem
                i = zip_list(elem_idx,1);
                j = zip_list(elem_idx,2);
                k = zip_list(elem_idx,3);
                % Distance between the observation point and the source point
                xd = FOV_rotated(:,1)-px(i);
                yd = FOV_rotated(:,2)-py(j);
                zd = FOV_rotated(:,3)-pz(k);
                r = sqrt((xd.^2)+(yd.^2)+(zd.^2));
                
                % Bx
                % For points aligned with the source points, the value
                % inside log() will be zero, but there is always a pair
                % of such value with opposite sign, so we set it to 0
                tmp_sum = zd+r;
                if sum(sum(tmp_sum==0))~=0
                    tmp_sum(tmp_sum==0) = 1;
                end
                Bx_curr = ((-1)^(i+j+k))*log(tmp_sum);
                B_all_local(:,1) = B_all_local(:,1) + Bx_curr;
                % By
                nume = xd.*zd;
                denom = yd.*r;
                B_all_local(:,2) = B_all_local(:,2) + ((-1)^(i+j+k+1))*(atan2(nume,denom));
                % Bz
                tmp_sum = xd+r;
                if sum(sum(tmp_sum==0))~=0
                    tmp_sum(tmp_sum==0) = 1;
                end
                Bz_curr = ((-1)^(i+j+k))*log(tmp_sum);
                B_all_local(:,3) = B_all_local(:,3) + Bz_curr;

            end
            % Multiply Bx/By/Bz by the common factor -Br/4pi
            B_all_local = -1*B_all_local*Br/(4*pi);
            % Change back the coordinates
            angle_rot = angle;
            B_all = RotationUtils.rotate3D(B_all_local,angle_rot,1);
            Bx = B_all(:,1);
            By = B_all(:,2);
            Bz = B_all(:,3);
        end

        % Compute the 2D magnetic field produced by multiple cuboid magnets
        function [Bx,By,Bz] = Field2DMultiCuboid(self,FOV1_len,FOV2_len,n_mag,FOV_1,FOV_2,FOV_3,magnet_dim,magnet_loc,angle,Br,surface)
        % Compute field components from multiple cuboid magnets on a 2D plane.
        % Input:
        %   self - MagTetris object.
        %   FOV1_len - Number of points in the first FOV direction.
        %   FOV2_len - Number of points in the second FOV direction.
        %   n_mag - Number of cuboid magnets in the batch.
        %   FOV_1 - First coordinate vector for the observation plane [mm].
        %   FOV_2 - Second coordinate vector for the observation plane [mm].
        %   FOV_3 - Fixed coordinate for the observation plane [mm].
        %   magnet_dim - Cuboid dimensions [mm].
        %   magnet_loc - Cuboid center locations [mm].
        %   angle - Cuboid yaw, pitch, and roll angles [degree].
        %   Br - Cuboid remanence values [T].
        %   surface - Plane selector: 'x', 'y', 'z', or 'c'.
        % Output:
        %   Bx - X-component magnetic field map [T].
        %   By - Y-component magnetic field map [T].
        %   Bz - Z-component magnetic field map [T].

            N_FOV = FOV1_len*FOV2_len;
            Bx_local = zeros(n_mag,N_FOV);
            By_local = zeros(n_mag,N_FOV);
            Bz_local = zeros(n_mag,N_FOV);

            % Change the coordinates
            % normal vector = y: XZ slice, z: XY slice, x: YZ slice
            pos_rep_x = reshape(repmat(reshape(magnet_loc(:,1),1,[]),FOV2_len,1),[],1);
            pos_rep_y = reshape(repmat(reshape(magnet_loc(:,2),1,[]),FOV2_len,1),[],1);
            pos_rep_z = reshape(repmat(reshape(magnet_loc(:,3),1,[]),FOV2_len,1),[],1);
            if surface == 'x'
                [FOV_y,FOV_z] = meshgrid(FOV_1,FOV_2);
                shifted_x = ones(FOV2_len*n_mag,FOV1_len)*FOV_3 - pos_rep_x;
                shifted_y = repmat(FOV_y,n_mag,1) - pos_rep_y;
                shifted_z = repmat(FOV_z,n_mag,1) - pos_rep_z;
                FOV_shifted = ones(numel(FOV_y)*n_mag,3);
                FOV_shifted(:,1) = reshape(shifted_x,[],1);
                FOV_shifted(:,2) = reshape(shifted_y,[],1);
                FOV_shifted(:,3) = reshape(shifted_z,[],1);
            elseif surface == 'y'
                [FOV_x,FOV_z] = meshgrid(FOV_1,FOV_2);
                shifted_x = repmat(FOV_x,n_mag,1) - pos_rep_x;
                shifted_y = ones(FOV2_len*n_mag,FOV1_len)*FOV_3 - pos_rep_y;
                shifted_z = repmat(FOV_z,n_mag,1) - pos_rep_z;
                FOV_shifted = ones(numel(FOV_x)*n_mag,3);
                FOV_shifted(:,1) = reshape(shifted_x,[],1);
                FOV_shifted(:,2) = reshape(shifted_y,[],1);
                FOV_shifted(:,3) = reshape(shifted_z,[],1);
            elseif surface == 'z'
                [FOV_x,FOV_y] = meshgrid(FOV_1,FOV_2);
                shifted_x = repmat(FOV_x,n_mag,1) - pos_rep_x;
                shifted_y = repmat(FOV_y,n_mag,1) - pos_rep_y;
                shifted_z = ones(FOV2_len*n_mag,FOV1_len)*FOV_3 - pos_rep_z;
                FOV_shifted = ones(numel(FOV_x)*n_mag,3);
                FOV_shifted(:,1) = reshape(shifted_x',[],1);
                FOV_shifted(:,2) = reshape(shifted_y',[],1);
                FOV_shifted(:,3) = reshape(shifted_z',[],1);
            else
                % Curvy surface
                [FOV_phi,FOV_z] = meshgrid(FOV_1,FOV_2);
                FOV_rho = FOV_3*ones(size(FOV_phi));
                [FOV_x,FOV_y] = pol2cart(FOV_phi+pi/2,FOV_rho);
                shifted_x = FOV_x - magnet_loc(1);
                shifted_y = FOV_y - magnet_loc(2);
                shifted_z = FOV_z - magnet_loc(3);
                FOV_shifted = ones(numel(FOV_x),3);
                FOV_shifted(:,1) = reshape(shifted_x,[],1);
                FOV_shifted(:,2) = reshape(shifted_y,[],1);
                FOV_shifted(:,3) = reshape(shifted_z,[],1);
            end

            % Rotate the FoV for every magnet
            FOV_rotated = zeros(size(FOV_shifted));
            FOV_final_x = zeros(n_mag,N_FOV);
            FOV_final_y = zeros(n_mag,N_FOV);
            FOV_final_z = zeros(n_mag,N_FOV);
            for mag_idx=1:n_mag
                angle_rot = -angle(mag_idx,:);
                idx_start = (mag_idx-1)*N_FOV + 1;
                idx_end = mag_idx*N_FOV;
                FOV_curr = FOV_shifted(idx_start:idx_end,:);
                FOV_rotated(idx_start:idx_end,:) = RotationUtils.rotate3D(FOV_curr,angle_rot,2);
                % Reshape the FoV matrix to separate x/y/z components with shape [n_mag,N_FOV]
                FOV_final_x(mag_idx,:) = reshape(FOV_rotated(idx_start:idx_end,1),1,N_FOV);
			    FOV_final_y(mag_idx,:) = reshape(FOV_rotated(idx_start:idx_end,2),1,N_FOV);
			    FOV_final_z(mag_idx,:) = reshape(FOV_rotated(idx_start:idx_end,3),1,N_FOV);
            end

            % Source points of the magnet
            px = [-magnet_dim(:,1)/2,magnet_dim(:,1)/2];
            py = [-magnet_dim(:,2)/2,magnet_dim(:,2)/2];
            pz = [-magnet_dim(:,3)/2,magnet_dim(:,3)/2];
            p_idx_list = {[1,2],[1,2],[1,2]};
            idx_list_copy = p_idx_list;
            [idx_list_copy{:}] = ndgrid(p_idx_list{:});
            zip_list = cell2mat(cellfun(@(m)m(:),idx_list_copy,'uni',0));
            num_elem = length(zip_list);
            % Calculated the field map
            for elem_idx=1:num_elem
                i = zip_list(elem_idx,1);
                j = zip_list(elem_idx,2);
                k = zip_list(elem_idx,3);
                % Distance between the observation point and the source point
                xd = FOV_final_x-px(:,i);
                yd = FOV_final_y-py(:,j);
                zd = FOV_final_z-pz(:,k);
                r = sqrt((xd.^2)+(yd.^2)+(zd.^2));
                
                % Bx
                % For points aligned with the source points, the value
                % inside log() will be zero, but there is always a pair
                % of such value with opposite sign, so we set it to 0
                tmp_sum = zd+r;
                if sum(sum(tmp_sum==0))~=0
                    tmp_sum(tmp_sum==0) = 1;
                end
                Bx_curr = ((-1)^(i+j+k))*log(tmp_sum);
                Bx_local = Bx_local + Bx_curr;
                % By
                nume = xd.*zd;
                denom = yd.*r;
                By_local = By_local + ((-1)^(i+j+k+1))*(atan2(nume,denom));
                % Bz
                tmp_sum = xd+r;
                if sum(sum(tmp_sum==0))~=0
                    tmp_sum(tmp_sum==0) = 1;
                end
                Bz_curr = ((-1)^(i+j+k))*log(tmp_sum);
                Bz_local = Bz_local + Bz_curr;

            end
            % Change back the coordinates for every magnet
            Bx_all = zeros(size(Bx_local));
            By_all = zeros(size(Bx_local));
            Bz_all = zeros(size(Bx_local));
            for mag_idx=1:n_mag
                angle_rot = angle(mag_idx,:);
                B_all_curr = [Bx_local(mag_idx,:);By_local(mag_idx,:);Bz_local(mag_idx,:)];
                B_all_rot = RotationUtils.rotate3D(B_all_curr',angle_rot,1);
                Bx_all(mag_idx,:) = B_all_rot(:,1);
			    By_all(mag_idx,:) = B_all_rot(:,2);
			    Bz_all(mag_idx,:) = B_all_rot(:,3);
            end

            % Multiply Bx/By/Bz by the common factor -Br/4pi
            Bx_all = -1*Br*Bx_all/(4*pi);
            By_all = -1*Br*By_all/(4*pi);
            Bz_all = -1*Br*Bz_all/(4*pi);
            Bx = reshape(Bx_all,FOV1_len,FOV2_len)';
            By = reshape(By_all,FOV1_len,FOV2_len)';
            Bz = reshape(Bz_all,FOV1_len,FOV2_len)';
        end
        
        % Compute the 2D magnetic field produced by a single fan-shaped magnet
        function [Bx,By,Bz] = Field2DSingleFanOld(self,FOV1_len,FOV2_len,FOV_1,FOV_2,FOV_3,center_loc,angle,magnet_rho,magnet_phi,magnet_z,Br,pol_mode,surface)
        % Compute field from one fan-shaped magnet using the older trapezoid method.
        % Input:
        %   self - MagTetris object.
        %   FOV1_len - Number of points in the first FOV direction.
        %   FOV2_len - Number of points in the second FOV direction.
        %   FOV_1 - First coordinate vector for the observation plane [mm].
        %   FOV_2 - Second coordinate vector for the observation plane [mm].
        %   FOV_3 - Fixed coordinate for the observation plane [mm].
        %   center_loc - Fan local-origin location [mm].
        %   angle - Fan yaw, pitch, and roll angles [degree].
        %   magnet_rho - Inner and outer fan radii [mm].
        %   magnet_phi - Half-angle span of the fan magnet [degree].
        %   magnet_z - Fan axial length [mm].
        %   Br - Fan remanence [T].
        %   pol_mode - Polarization mode, 1 inward or 2 outward.
        %   surface - Plane selector: 'x', 'y', 'z', or 'c'.
        % Output:
        %   Bx - X-component magnetic field map [T].
        %   By - Y-component magnetic field map [T].
        %   Bz - Z-component magnetic field map [T].
        
            % Trivial case:
            if Br == 0
                Bx = zeros(FOV2_len,FOV1_len);
                By = zeros(FOV2_len,FOV1_len);
                Bz = zeros(FOV2_len,FOV1_len);
                return;
            end
            
            % Change the coordinates
            % normal vector = y: XZ slice, z: XY slice, x: YZ slice
            if surface == 'x'
                [FOV_y,FOV_z] = meshgrid(FOV_1,FOV_2);
                shifted_x = FOV_3 - center_loc(1);
                shifted_y = FOV_y - center_loc(2);
                shifted_z = FOV_z - center_loc(3);
                FOV_shifted = ones(numel(FOV_y),3);
                FOV_shifted(:,1) = FOV_shifted(:,1)*shifted_x;
                FOV_shifted(:,2) = reshape(shifted_y,numel(shifted_y),1);
                FOV_shifted(:,3) = reshape(shifted_z,numel(shifted_z),1);
            elseif surface == 'y'
                [FOV_x,FOV_z] = meshgrid(FOV_1,FOV_2);
                shifted_x = FOV_x - center_loc(1);
                shifted_y = FOV_3 - center_loc(2);
                shifted_z = FOV_z - center_loc(3);
                FOV_shifted = ones(numel(FOV_x),3);
                FOV_shifted(:,1) = reshape(shifted_x,numel(shifted_x),1);
                FOV_shifted(:,2) = FOV_shifted(:,2)*shifted_y;
                FOV_shifted(:,3) = reshape(shifted_z,numel(shifted_z),1);
            elseif surface == 'z'
                [FOV_x,FOV_y] = meshgrid(FOV_1,FOV_2);
                shifted_x = FOV_x - center_loc(1);
                shifted_y = FOV_y - center_loc(2);
                shifted_z = FOV_3 - center_loc(3);
                FOV_shifted = ones(numel(FOV_x),3);
                FOV_shifted(:,1) = reshape(shifted_x,numel(shifted_x),1);
                FOV_shifted(:,2) = reshape(shifted_y,numel(shifted_y),1);
                FOV_shifted(:,3) = FOV_shifted(:,3)*shifted_z;
            else
                % Curvy surface
                [FOV_phi,FOV_z] = meshgrid(FOV_1,FOV_2);
                FOV_rho = FOV_3*ones(size(FOV_phi));
                [FOV_x,FOV_y] = pol2cart(FOV_phi+pi/2,FOV_rho);
                shifted_x = FOV_x - center_loc(1);
                shifted_y = FOV_y - center_loc(2);
                shifted_z = FOV_z - center_loc(3);
                FOV_shifted = ones(numel(FOV_x),3);
                FOV_shifted(:,1) = reshape(shifted_x,[],1);
                FOV_shifted(:,2) = reshape(shifted_y,[],1);
                FOV_shifted(:,3) = reshape(shifted_z,[],1);
            end
            
            angle_rot = -angle;
            FOV_rotated = RotationUtils.rotate3D(FOV_shifted,angle_rot,2);
            
            % front/back surface
            B_all_local = zeros(FOV2_len*FOV1_len,3);
            [num_trapz,rot_angle_list,trapz_2sides] = self.Fan2Trapz(magnet_rho,magnet_phi);
            % Discretize to rectangles
            num_rect = self.Trapz2Rect(trapz_2sides,diff(magnet_rho));
            
            z_bounds = [-magnet_z/2,magnet_z/2];
            for idx_trapz=1:num_trapz
                B_trapz = self.FieldTrapz(FOV1_len,FOV2_len,FOV_rotated,magnet_rho,z_bounds,trapz_2sides,num_rect,Br,pol_mode,rot_angle_list(idx_trapz));
                B_all_local = B_all_local + B_trapz;
            end
            
            % Change back the coordinates
            angle_rot = angle;
            B_all = RotationUtils.rotate3D(B_all_local,angle_rot,1);
            Bx = reshape(B_all(:,1),FOV2_len,FOV1_len);
            By = reshape(B_all(:,2),FOV2_len,FOV1_len);
            Bz = reshape(B_all(:,3),FOV2_len,FOV1_len);

        end
    
        % Compute the 2D magnetic field produced by a single fan-shaped magnet
        function [Bx,By,Bz] = Field2DSingleFan(self,FOV1_len,FOV2_len,FOV_1,FOV_2,FOV_3,center_loc,angle,magnet_rho,magnet_phi,magnet_z,Br,pol_mode,surface,n_per_group)
        % Compute field from one fan-shaped magnet using cuboid approximation.
        % Input:
        %   self - MagTetris object.
        %   FOV1_len - Number of points in the first FOV direction.
        %   FOV2_len - Number of points in the second FOV direction.
        %   FOV_1 - First coordinate vector for the observation plane [mm].
        %   FOV_2 - Second coordinate vector for the observation plane [mm].
        %   FOV_3 - Fixed coordinate for the observation plane [mm].
        %   center_loc - Fan local-origin location [mm].
        %   angle - Fan yaw, pitch, and roll angles [degree].
        %   magnet_rho - Inner and outer fan radii [mm].
        %   magnet_phi - Half-angle span of the fan magnet [degree].
        %   magnet_z - Fan axial length [mm].
        %   Br - Fan remanence [T].
        %   pol_mode - Polarization mode, 1 inward or 2 outward.
        %   surface - Plane selector: 'x', 'y', 'z', or 'c'.
        %   n_per_group - Number of approximation cuboids grouped per calculation.
        % Output:
        %   Bx - X-component magnetic field map [T].
        %   By - Y-component magnetic field map [T].
        %   Bz - Z-component magnetic field map [T].
        
            % Trivial case:
            if Br == 0
                Bx = zeros(FOV2_len,FOV1_len);
                By = zeros(FOV2_len,FOV1_len);
                Bz = zeros(FOV2_len,FOV1_len);
                return;
            end
            % Change the coordinates
            % normal vector = y: XZ slice, z: XY slice, x: YZ slice
            if surface == 'x'
                [FOV_y,FOV_z] = meshgrid(FOV_1,FOV_2);
                shifted_x = FOV_3 - center_loc(1);
                shifted_y = FOV_y - center_loc(2);
                shifted_z = FOV_z - center_loc(3);
                FOV_shifted = ones(numel(FOV_y),3);
                FOV_shifted(:,1) = FOV_shifted(:,1)*shifted_x;
                FOV_shifted(:,2) = reshape(shifted_y,numel(shifted_y),1);
                FOV_shifted(:,3) = reshape(shifted_z,numel(shifted_z),1);
            elseif surface == 'y'
                [FOV_x,FOV_z] = meshgrid(FOV_1,FOV_2);
                shifted_x = FOV_x - center_loc(1);
                shifted_y = FOV_3 - center_loc(2);
                shifted_z = FOV_z - center_loc(3);
                FOV_shifted = ones(numel(FOV_x),3);
                FOV_shifted(:,1) = reshape(shifted_x,numel(shifted_x),1);
                FOV_shifted(:,2) = FOV_shifted(:,2)*shifted_y;
                FOV_shifted(:,3) = reshape(shifted_z,numel(shifted_z),1);
            elseif surface == 'z'
                [FOV_x,FOV_y] = meshgrid(FOV_1,FOV_2);
                shifted_x = FOV_x - center_loc(1);
                shifted_y = FOV_y - center_loc(2);
                shifted_z = FOV_3 - center_loc(3);
                FOV_shifted = ones(numel(FOV_x),3);
                FOV_shifted(:,1) = reshape(shifted_x,numel(shifted_x),1);
                FOV_shifted(:,2) = reshape(shifted_y,numel(shifted_y),1);
                FOV_shifted(:,3) = FOV_shifted(:,3)*shifted_z;
            else
                % Curvy surface
                [FOV_phi,FOV_z] = meshgrid(FOV_1,FOV_2);
                FOV_rho = FOV_3*ones(size(FOV_phi));
                [FOV_x,FOV_y] = pol2cart(FOV_phi+pi/2,FOV_rho);
                shifted_x = FOV_x - center_loc(1);
                shifted_y = FOV_y - center_loc(2);
                shifted_z = FOV_z - center_loc(3);
                FOV_shifted = ones(numel(FOV_x),3);
                FOV_shifted(:,1) = reshape(shifted_x,[],1);
                FOV_shifted(:,2) = reshape(shifted_y,[],1);
                FOV_shifted(:,3) = reshape(shifted_z,[],1);
            end
            
            angle_rot = -angle;
            FOV_rotated = RotationUtils.rotate3D(FOV_shifted,angle_rot,2);

            % Produce the list of cuboid magnets
            [num_trapz,rot_angle_list,trapz_2sides] = self.Fan2Trapz(magnet_rho,magnet_phi);
            % Discretize to rectangles
            num_rect = self.Trapz2Rect(trapz_2sides,diff(magnet_rho));
            side_diff = diff(trapz_2sides);
            rect_len_diff = side_diff/num_rect;
            rect_h = diff(magnet_rho)/num_rect;
            % Create the list of magnet dimensions
            num_cub = num_trapz*num_rect;
            x_list = trapz_2sides(1) + (0:num_rect-1)*rect_len_diff;
            magnet_dim_list = ones(num_cub,3);
            magnet_dim_list(:,1) = reshape(repmat(x_list,num_trapz,1),[],1);
            magnet_dim_list(:,2) = magnet_dim_list(:,2)*rect_h;
            magnet_dim_list(:,3) = magnet_dim_list(:,3)*magnet_z;
            % Create the list of location
            loc_list = zeros(num_rect,3*num_trapz);
            loc_orig = zeros(num_rect,3);
            loc_orig(:,2) = magnet_rho(1) + (0:num_rect-1)*rect_h + rect_h/2;
            for idx_trapz=1:num_trapz
                rot_angle_curr = [-rot_angle_list(idx_trapz),0,0];
                loc_list(:,(idx_trapz-1)*3+1:idx_trapz*3) = RotationUtils.rotate3D(loc_orig,rot_angle_curr,2);
            end
            loc_list = reshape(loc_list',3,num_cub)';
            
            % Create the list of Br
            Br_list = ones(1,num_cub)*Br;
            % Create the list of angle
            % loop over trapzoids, then different layers
            angle_list = zeros(num_cub,3);
            angle_list(:,1) = reshape(repmat(-rot_angle_list,1,num_rect),[],1);
            
            % Compute the field
            % Multiple magnets in a group
            num_whole = floor(num_cub/n_per_group);
            n_part = mod(num_cub,n_per_group);
            B_all_local = zeros(FOV2_len*FOV1_len,3);
            for i=0:num_whole
                idx_start = i*n_per_group + 1;
                if i == num_whole
                    loc_curr = loc_list(idx_start:end,:);
                    angle_curr = angle_list(idx_start:end,:);
                    dim_curr = magnet_dim_list(idx_start:end,:);
                    Br_curr = Br_list(idx_start:end);

                    B_all_local_curr = self.Field2DMultiCuboidFan(FOV1_len,FOV2_len,n_part,FOV_rotated,dim_curr,loc_curr,angle_curr,Br_curr);

                    B_all_local = B_all_local + B_all_local_curr;
                else
                    idx_end = (i+1)*n_per_group;
                    loc_curr = loc_list(idx_start:idx_end,:);
                    angle_curr = angle_list(idx_start:idx_end,:);
                    dim_curr = magnet_dim_list(idx_start:idx_end,:);
                    Br_curr = Br_list(idx_start:idx_end);

                    B_all_local_curr = self.Field2DMultiCuboidFan(FOV1_len,FOV2_len,n_per_group,FOV_rotated,dim_curr,loc_curr,angle_curr,Br_curr);

                    B_all_local = B_all_local + B_all_local_curr;
                end
            end
            

            % Change back the coordinates
            angle_rot = angle;
            B_all_local = B_all_local*(-1)^pol_mode;
            B_all = RotationUtils.rotate3D(B_all_local,angle_rot,1);
            Bx = reshape(B_all(:,1),FOV2_len,FOV1_len);
            By = reshape(B_all(:,2),FOV2_len,FOV1_len);
            Bz = reshape(B_all(:,3),FOV2_len,FOV1_len);

        end
        
        % Compute the 2D magnetic field produced by a single fan-shaped magnet
        % The FoV is a given set of observation points
        function [Bx,By,Bz] = Field2DSingleFanFree(self,FOV_x,FOV_y,FOV_z,center_loc,angle,magnet_rho,magnet_phi,magnet_z,Br,pol_mode)
        % Compute field from one fan-shaped magnet at arbitrary points.
        % Input:
        %   self - MagTetris object.
        %   FOV_x - X coordinates of observation points [mm].
        %   FOV_y - Y coordinates of observation points [mm].
        %   FOV_z - Z coordinates of observation points [mm].
        %   center_loc - Fan local-origin location [mm].
        %   angle - Fan yaw, pitch, and roll angles [degree].
        %   magnet_rho - Inner and outer fan radii [mm].
        %   magnet_phi - Half-angle span of the fan magnet [degree].
        %   magnet_z - Fan axial length [mm].
        %   Br - Fan remanence [T].
        %   pol_mode - Polarization mode, 1 inward or 2 outward.
        % Output:
        %   Bx - X-component magnetic field values [T].
        %   By - Y-component magnetic field values [T].
        %   Bz - Z-component magnetic field values [T].
        
            FOV_len = length(FOV_x);
            % Trivial case:
            if Br == 0
                Bx = zeros(FOV_len,1);
                By = zeros(FOV_len,1);
                Bz = zeros(FOV_len,1);
                return;
            end
            % Change the coordinates
            shifted_x = FOV_x - center_loc(1);
            shifted_y = FOV_y - center_loc(2);
            shifted_z = FOV_z - center_loc(3);
            FOV_shifted = [shifted_x,shifted_y,shifted_z];
            
            angle_rot = -angle;
            FOV_rotated = RotationUtils.rotate3D(FOV_shifted,angle_rot,2);

            % Produce the list of cuboid magnets
            [num_trapz,rot_angle_list,trapz_2sides] = self.Fan2Trapz(magnet_rho,magnet_phi);
            % Discretize to rectangles
            num_rect = self.Trapz2Rect(trapz_2sides,diff(magnet_rho));
            side_diff = diff(trapz_2sides);
            rect_len_diff = side_diff/num_rect;
            rect_h = diff(magnet_rho)/num_rect;
            % Create the list of magnet dimensions
            num_cub = num_trapz*num_rect;
            x_list = trapz_2sides(1) + (0:num_rect-1)*rect_len_diff;
            magnet_dim_list = ones(num_cub,3);
            magnet_dim_list(:,1) = reshape(repmat(x_list,num_trapz,1),[],1);
            magnet_dim_list(:,2) = magnet_dim_list(:,2)*rect_h;
            magnet_dim_list(:,3) = magnet_dim_list(:,3)*magnet_z;
            % Create the list of location
            loc_list = zeros(num_rect,3*num_trapz);
            loc_orig = zeros(num_rect,3);
            loc_orig(:,2) = magnet_rho(1) + (0:num_rect-1)*rect_h + rect_h/2;
            for idx_trapz=1:num_trapz
                rot_angle_curr = [-rot_angle_list(idx_trapz),0,0];
                loc_list(:,(idx_trapz-1)*3+1:idx_trapz*3) = RotationUtils.rotate3D(loc_orig,rot_angle_curr,2);
            end
            loc_list = reshape(loc_list',3,num_cub)';
            
            % Create the list of Br
            Br_list = ones(1,num_cub)*Br;
            % Create the list of angle
            % loop over trapzoids, then different layers
            angle_list = zeros(num_cub,3);
            angle_list(:,1) = reshape(repmat(-rot_angle_list,1,num_rect),[],1);
            
            % Compute the field
            % Multiple magnets in a group
            B_all_local = zeros(FOV_len,3);
            for i=1:num_cub
                loc_curr = loc_list(i,:);
                angle_curr = angle_list(i,:);
                dim_curr = magnet_dim_list(i,:);
                Br_curr = Br_list(i);

                B_all_local_curr = self.Field2DSingleCuboidFree(FOV_rotated(:,1),FOV_rotated(:,2),FOV_rotated(:,3),dim_curr,loc_curr,angle_curr,Br_curr);

                B_all_local = B_all_local + B_all_local_curr;
            end
            

            % Change back the coordinates
            angle_rot = angle;
            B_all_local = B_all_local*(-1)^pol_mode;
            B_all = RotationUtils.rotate3D(B_all_local,angle_rot,1);
            Bx = B_all(:,1);
            By = B_all(:,2);
            Bz = B_all(:,3);

        end
        % Compute the 2D magnetic field produced by multiple cuboid magnets
        % approximating the fan-magnets
        function B_all_local = Field2DMultiCuboidFan(self,FOV1_len,FOV2_len,n_mag,FOV_fan,magnet_dim,magnet_loc,angle,Br)
        % Compute local field from cuboids that approximate a fan magnet.
        % Input:
        %   self - MagTetris object.
        %   FOV1_len - Number of points in the first FOV direction.
        %   FOV2_len - Number of points in the second FOV direction.
        %   n_mag - Number of cuboid approximation magnets.
        %   FOV_fan - Observation points in the fan-local coordinate frame [mm].
        %   magnet_dim - Cuboid approximation dimensions [mm].
        %   magnet_loc - Cuboid approximation center locations [mm].
        %   angle - Cuboid approximation yaw, pitch, and roll angles [degree].
        %   Br - Cuboid approximation remanence values [T].
        % Output:
        %   B_all_local - Local magnetic field components at all FOV points [T].

            N_FOV = FOV1_len*FOV2_len;
            Bx_local = zeros(n_mag,N_FOV);
            By_local = zeros(n_mag,N_FOV);
            Bz_local = zeros(n_mag,N_FOV);

            % Change the coordinates
            % normal vector = y: XZ slice, z: XY slice, x: YZ slice
            pos_rep_x = reshape(repmat(reshape(magnet_loc(:,1),1,[]),N_FOV,1),[],1);
            pos_rep_y = reshape(repmat(reshape(magnet_loc(:,2),1,[]),N_FOV,1),[],1);
            pos_rep_z = reshape(repmat(reshape(magnet_loc(:,3),1,[]),N_FOV,1),[],1);
            FOV_shifted = repmat(FOV_fan,n_mag,1) - [pos_rep_x,pos_rep_y,pos_rep_z];
            
            % Rotate the FoV for every magnet
            FOV_rotated = zeros(size(FOV_shifted));
            FOV_final_x = zeros(n_mag,N_FOV);
            FOV_final_y = zeros(n_mag,N_FOV);
            FOV_final_z = zeros(n_mag,N_FOV);
            for mag_idx=1:n_mag
                angle_rot = -angle(mag_idx,:);
                idx_start = (mag_idx-1)*N_FOV + 1;
                idx_end = mag_idx*N_FOV;
                FOV_curr = FOV_shifted(idx_start:idx_end,:);
                FOV_rotated(idx_start:idx_end,:) = RotationUtils.rotate3D(FOV_curr,angle_rot,2);
                % Reshape the FoV matrix to separate x/y/z components with shape [n_mag,N_FOV]
                FOV_final_x(mag_idx,:) = reshape(FOV_rotated(idx_start:idx_end,1),1,N_FOV);
			    FOV_final_y(mag_idx,:) = reshape(FOV_rotated(idx_start:idx_end,2),1,N_FOV);
			    FOV_final_z(mag_idx,:) = reshape(FOV_rotated(idx_start:idx_end,3),1,N_FOV);
            end

            % Source points of the magnet
            px = [-magnet_dim(:,1)/2,magnet_dim(:,1)/2];
            py = [-magnet_dim(:,2)/2,magnet_dim(:,2)/2];
            pz = [-magnet_dim(:,3)/2,magnet_dim(:,3)/2];
            p_idx_list = {[1,2],[1,2],[1,2]};
            idx_list_copy = p_idx_list;
            [idx_list_copy{:}] = ndgrid(p_idx_list{:});
            zip_list = cell2mat(cellfun(@(m)m(:),idx_list_copy,'uni',0));
            num_elem = length(zip_list);
            % Calculated the field map
            for elem_idx=1:num_elem
                i = zip_list(elem_idx,1);
                j = zip_list(elem_idx,2);
                k = zip_list(elem_idx,3);
                % Distance between the observation point and the source point
                xd = FOV_final_x-px(:,i);
                yd = FOV_final_y-py(:,j);
                zd = FOV_final_z-pz(:,k);
                r = sqrt((xd.^2)+(yd.^2)+(zd.^2));
                
                % Bx
                % For points aligned with the source points, the value
                % inside log() will be zero, but there is always a pair
                % of such value with opposite sign, so we set it to 0
                tmp_sum = zd+r;
                if sum(sum(tmp_sum==0))~=0
                    tmp_sum(tmp_sum==0) = 1;
                end
                Bx_curr = ((-1)^(i+j+k))*log(tmp_sum);
                Bx_local = Bx_local + Bx_curr;
                % By
                nume = xd.*zd;
                denom = yd.*r;
                By_local = By_local + ((-1)^(i+j+k+1))*(atan2(nume,denom));
                % Bz
                tmp_sum = xd+r;
                if sum(sum(tmp_sum==0))~=0
                    tmp_sum(tmp_sum==0) = 1;
                end
                Bz_curr = ((-1)^(i+j+k))*log(tmp_sum);
                Bz_local = Bz_local + Bz_curr;

            end
            % Change back the coordinates for every magnet
            Bx_all = zeros(size(Bx_local));
            By_all = zeros(size(Bx_local));
            Bz_all = zeros(size(Bx_local));
            for mag_idx=1:n_mag
                angle_rot = angle(mag_idx,:);
                B_all_curr = [Bx_local(mag_idx,:);By_local(mag_idx,:);Bz_local(mag_idx,:)];
                B_all_rot = RotationUtils.rotate3D(B_all_curr',angle_rot,1);
                Bx_all(mag_idx,:) = B_all_rot(:,1);
			    By_all(mag_idx,:) = B_all_rot(:,2);
			    Bz_all(mag_idx,:) = B_all_rot(:,3);
            end
            
            % Multiply Bx/By/Bz by the common factor -Br/4pi
            Bx_all = -1*Br*Bx_all/(4*pi);
            By_all = -1*Br*By_all/(4*pi);
            Bz_all = -1*Br*Bz_all/(4*pi);
            B_all_local = [Bx_all',By_all',Bz_all'];
        end

        % Compute the 2D magnetic field produced by a trapezoid using cuboid approximation
        function B_trapz = FieldTrapz(self,FOV1_len,FOV2_len,FOV_orig,magnet_rho,z_bounds,trapz_2sides,num_rect,Br,pol_mode,trapz_orient_angle)
        % Compute field from one trapezoid approximation of a fan magnet.
        % Input:
        %   self - MagTetris object.
        %   FOV1_len - Number of points in the first FOV direction.
        %   FOV2_len - Number of points in the second FOV direction.
        %   FOV_orig - Observation points in the fan-local coordinate frame [mm].
        %   magnet_rho - Inner and outer fan radii [mm].
        %   z_bounds - Lower and upper z bounds of the magnet [mm].
        %   trapz_2sides - Short and long side lengths of the trapezoid [mm].
        %   num_rect - Number of rectangles used to discretize the trapezoid.
        %   Br - Magnet remanence [T].
        %   pol_mode - Polarization mode, 1 inward or 2 outward.
        %   trapz_orient_angle - Yaw rotation angle of the trapezoid [degree].
        % Output:
        %   B_trapz - Magnetic field components from the trapezoid [T].
            
            % Rotate the FoV to make the trapezoid at the base location
            % Must use Roll-Pitch-Yaw for the order of rotation
            % Because the base positions (+y/-y, +z/-z) should be obtained first
            angle_rot = [-trapz_orient_angle,0,0];
            FOV_rotated = RotationUtils.rotate3D(FOV_orig,angle_rot,2);
            
            B_all_local = zeros(FOV2_len*FOV1_len,3);
            
            % Calculated the field map
            side_diff = diff(trapz_2sides);
            rect_len_diff = side_diff/num_rect;
            rect_h = diff(magnet_rho)/num_rect;
            for idx_rect=1:num_rect
                % Source points of the magnet
                x_bound = trapz_2sides(1) + (idx_rect-1)*rect_len_diff;
                px = [-x_bound,x_bound]/2;
                y_bound_low = magnet_rho(1) + (idx_rect-1)*rect_h;
                py = [y_bound_low,y_bound_low+rect_h];
                pz = [z_bounds(1),z_bounds(2)];
                for i=1:2
                    for j=1:2
                        for k=1:2
                            % Distance between the observation point and the source point
                            xd = FOV_rotated(:,1)-px(i);
                            yd = FOV_rotated(:,2)-py(j);
                            zd = FOV_rotated(:,3)-pz(k);
                            r = sqrt((xd.^2)+(yd.^2)+(zd.^2));
                            
                            % Bx
                            % For points aligned with the source points, the value
                            % inside log() will be zero, but there is always a pair
                            % of such value with opposite sign, so we set it to 0
                            tmp_sum = zd+r;
                            if sum(sum(tmp_sum==0))~=0
                                tmp_sum(tmp_sum==0) = 1;
                            end
                            Bx_curr = ((-1)^(i+j+k))*log(tmp_sum);
                            B_all_local(:,1) = B_all_local(:,1) + Bx_curr;
                            % By
                            nume = xd.*zd;
                            denom = yd.*r;
                            B_all_local(:,2) = B_all_local(:,2) + ((-1)^(i+j+k+1))*(atan2(nume,denom));
                            % Bz
                            tmp_sum = xd+r;
                            if sum(sum(tmp_sum==0))~=0
                                tmp_sum(tmp_sum==0) = 1;
                            end
                            Bz_curr = ((-1)^(i+j+k))*log(tmp_sum);
                            B_all_local(:,3) = B_all_local(:,3) + Bz_curr;
                        end
                    end
                end
            end
            
            
            % Multiply Bx/By/Bz by the common factor -Br/4pi
            B_all_local = -B_all_local*Br/(4*pi)*(-1)^pol_mode;
            
            % Change back the coordinates
            angle_rot = [trapz_orient_angle,0,0];
            B_trapz = RotationUtils.rotate3D(B_all_local,angle_rot,1);
        end
    
        % ========= Magnetic Force Calculation ========== %
        % Static force acting on a single magnet from arbitrary number of sources
        function F_target = ForceSingle(self,target_idx,source_idx,FOV_del_ratio)
        % Estimate static force on one target magnet from source magnets.
        % Input:
        %   self - MagTetris object.
        %   target_idx - Target index [type, index], where type 1 is cuboid and 2 is fan.
        %   source_idx - Source indices as rows of [type, index].
        %   FOV_del_ratio - Surface discretization ratio for force integration.
        % Output:
        %   F_target - Force vector acting on the target magnet [N].
           
            
            % FOV creation
            % 1 - cuboid magnet: x-z surfaces
            % 2 - fan-shaped magnet: top/bottom curvy surfaces
            if target_idx(1) == 1
                surface = 'y';
                mag_dim_target = self.cub_dim(target_idx(2),:);
                FOV_1 = -mag_dim_target(1)/2:(mag_dim_target(1)/FOV_del_ratio):mag_dim_target(1)/2;
                FOV_2 = -mag_dim_target(3)/2:(mag_dim_target(3)/FOV_del_ratio):mag_dim_target(3)/2;
                FOV_3_list = [-mag_dim_target(2)/2,mag_dim_target(2)/2];
                FOV_del_S = mag_dim_target(1)*mag_dim_target(3)/FOV_del_ratio.^2;
                % Load other parameters
                loc_target = self.cub_loc(target_idx(2),:);
                angle_target = self.cub_angle(target_idx(2),:);
                Br_target = self.cub_Br(target_idx(2));
                pol_target = 1;
            else
                surface = 'c';
                loc_target = self.fan_center_loc(target_idx(2),:);
                angle_target = self.fan_angle(target_idx(2),:);
                rho_target = self.fan_rho(target_idx(2),:);
                phi_target = self.fan_phi(target_idx(2));
                z_target = self.fan_z(target_idx(2));
                Br_target = self.fan_Br(target_idx(2));
                pol_target = (-1)^self.fan_pol(target_idx(2));
                FOV_1 = -deg2rad(phi_target):(2*deg2rad(phi_target)/FOV_del_ratio):deg2rad(phi_target);
                %FOV_1_out = -deg2rad(phi_target):(2*deg2rad(phi_target)/(FOV_del_ratio*rho_target(2))):deg2rad(phi_target);
                FOV_2 = -(z_target/2):(z_target/FOV_del_ratio):(z_target/2);
                FOV_3_list = rho_target;
                FOV_del_S_1 = 2*deg2rad(phi_target)*rho_target(1)*z_target/FOV_del_ratio.^2;
                FOV_del_S_2 = 2*deg2rad(phi_target)*rho_target(2)*z_target/FOV_del_ratio.^2;
            end
            
            % ===== Coordinate transformation =====
            % Load source locations (cuboid: center loc, fan: local origin)
            loc_other_raw = zeros(size(source_idx,1),3);
            angle_other_raw = zeros(size(source_idx,1),3);
            for magnet_idx=1:size(source_idx,1)
                if source_idx(magnet_idx,1) == 1
                    loc_other_raw(magnet_idx,:) = self.cub_loc(source_idx(magnet_idx,2),:);
                    angle_other_raw(magnet_idx,:) = self.cub_angle(source_idx(magnet_idx,2),:);
                else
                    loc_other_raw(magnet_idx,:) = self.fan_center_loc(source_idx(magnet_idx,2),:);
                    angle_other_raw(magnet_idx,:) = self.fan_angle(source_idx(magnet_idx,2),:);
                end
            end
            % Move to the new origin
            loc_other_unrot = loc_other_raw - loc_target;
            angle_other = angle_other_raw - angle_target;
            % Rotate the coordinates by angle_target
            angle_rot = angle_target;
            loc_other = RotationUtils.rotate3D(loc_other_unrot,-angle_rot,2);

            % Force calculation
            F_target = zeros(1,3);
            mu_air = 1.25663753e-6;
            sigma_m = pol_target*Br_target/mu_air;
            
            % Loop through each magnet
            for magnet_idx=1:size(source_idx,1)
                FOV_3_counter = 1;
                for FOV_3=FOV_3_list
                    if target_idx(1) == 1
                        % Surface normal vector direction
                        surface_n = sign(FOV_3);
                    else
                        % Surface normal vector direction
                        surface_n = (-1)^FOV_3_counter;
                        % For fan magnet as target, get the current surface FOV
                        if FOV_3_counter == 1
                            %FOV_1 = FOV_1_in;
                            FOV_del_S = FOV_del_S_1;
                        else
                            %FOV_1 = FOV_1_out;
                            FOV_del_S = FOV_del_S_2;
                        end
                    end

                    loc_source = loc_other(magnet_idx,:);
                    angle_source = angle_other(magnet_idx,:);
                    % Cuboid or fan-shaped source magnet
                    if source_idx(magnet_idx,1) == 1        % Cuboid
                        % Calculate the magnetic field on the surfaces
                        dim_source = self.cub_dim(source_idx(magnet_idx,2),:);
                        Br_source = self.cub_Br(source_idx(magnet_idx,2));
                        [Bx,By,Bz] = self.Field2DSingleCuboid(length(FOV_1),length(FOV_2),FOV_1,FOV_2,FOV_3,dim_source,loc_source,angle_source,Br_source,surface);
                    else                                    % Fan
                        % Calculate the magnetic field on the surfaces
                        rho_source = self.fan_rho(source_idx(magnet_idx,2),:);
                        phi_source = self.fan_phi(source_idx(magnet_idx,2));
                        z_source = self.fan_z(source_idx(magnet_idx,2));
                        Br_source = self.fan_Br(source_idx(magnet_idx,2));
                        pol_source = self.fan_pol(source_idx(magnet_idx,2));
                        [Bx,By,Bz] = self.field2DSingleFan(length(FOV_1),length(FOV_2),FOV_1,FOV_2,FOV_3,loc_source,angle_source,rho_source,phi_source,z_source,Br_source,pol_source,surface);
                    end
                    
                    F_target(1) = F_target(1) + surface_n*sum(Bx,'all')*sigma_m*FOV_del_S*1e-6;
                    F_target(2) = F_target(2) + surface_n*sum(By,'all')*sigma_m*FOV_del_S*1e-6;
                    F_target(3) = F_target(3) + surface_n*sum(Bz,'all')*sigma_m*FOV_del_S*1e-6;

                    FOV_3_counter = FOV_3_counter + 1;
                end
            end
            % Coordinate transformation
            angle_rot = angle_target;
            F_target = RotationUtils.rotate3D(F_target,angle_rot,1);
        end

        % Static force acting on all magnets from all the other magnets
        function F_all_static = ForceAllStatic(self,FOV_del_ratio)
        % Estimate static force on every magnet from all other magnets.
        % Input:
        %   self - MagTetris object.
        %   FOV_del_ratio - Surface discretization ratio for force integration.
        % Output:
        %   F_all_static - Force vectors for all magnets [N].

            % Loop through all magnets
            cub_idx_list = [ones(self.cub_numMag,1),(1:self.cub_numMag)'];
            fan_idx_list = [ones(self.fan_numMag,1),(1:self.fan_numMag)'];

            total_idx_list = [cub_idx_list;fan_idx_list];
            total_numMag = self.cub_numMag + self.fan_numMag;
            F_all_static = zeros(total_numMag,3);
            for mag_idx=1:total_numMag
                curr_mag_idx = total_idx_list(mag_idx,:);
                other_mag_idx = total_idx_list(setdiff(1:total_numMag,mag_idx),:);
                F_all_static(mag_idx,:) = self.ForceSingle(curr_mag_idx,other_mag_idx,FOV_del_ratio);
                if mod(mag_idx,10) == 0 || mag_idx == total_numMag
                    fprintf('Magnet #%d\n',mag_idx);
                end
            end
        end

        % Static force acting on multiple magnets from arbitrary number of sources
        function F_target_list = ForceFree(self,target_idx_list,source_idx_list,FOV_del_ratio)
        % Estimate static forces on selected targets from selected sources.
        % Input:
        %   self - MagTetris object.
        %   target_idx_list - Target indices as rows of [type, index].
        %   source_idx_list - Source indices as rows of [type, index].
        %   FOV_del_ratio - Surface discretization ratio for force integration.
        % Output:
        %   F_target_list - Force vectors for the selected targets [N].

            % Loop through all magnets in the given list
            total_numMag = size(target_idx_list,1);
            F_target_list = zeros(total_numMag,3);
            for mag_idx=1:total_numMag
                curr_mag_idx = target_idx_list(mag_idx,:);
                other_mag_idx = source_idx_list;
                F_target_list(mag_idx,:) = self.ForceSingle(curr_mag_idx,other_mag_idx,FOV_del_ratio);
                if mod(mag_idx,10) == 0 || mag_idx == total_numMag
                    fprintf('Magnet #%d\n',mag_idx);
                end
            end
        end

        % Static force acting on multiple magnets IN A GROUP from arbitrary number of sources
        function F_target = ForceGroup(self,target_idx_list,source_idx_list,FOV_del_ratio)
        % Estimate total static force on a group of target magnets.
        % Input:
        %   self - MagTetris object.
        %   target_idx_list - Target indices as rows of [type, index].
        %   source_idx_list - Source indices as rows of [type, index].
        %   FOV_del_ratio - Surface discretization ratio for force integration.
        % Output:
        %   F_target - Summed force vector for the target group [N].

            % Loop through all magnets in the given list
            total_numMag = size(target_idx_list,1);
            F_target_list = zeros(total_numMag,3);
            for mag_idx=1:total_numMag
                curr_mag_idx = target_idx_list(mag_idx,:);
                other_mag_idx = source_idx_list;
                F_target_list(mag_idx,:) = self.ForceSingle(curr_mag_idx,other_mag_idx,FOV_del_ratio);
                if mod(mag_idx,10) == 0 || mag_idx == total_numMag
                    fprintf('Magnet #%d\n',mag_idx);
                end
            end
            F_target = sum(F_target_list,1);
        end

        % Estimate the total weight of PMA (magnet only) in [kg]
        function weight_total = Weight(self)
        % Estimate total permanent magnet weight from magnet volume.
        % Input:
        %   self - MagTetris object.
        % Output:
        %   weight_total - Estimated total magnet weight [kg].

            % Reference: A 10x10x10mm^3 magnet weights 8g
            weight_ref = 8e-3;         % [kg]
            volume_ref = 1e3;          % [mm^3]
            % Cuboid
            volume_cub = 0;
            if self.cub_numMag > 0
                volume_cub = sum(prod(self.cub_dim,2));
            end
            % Fan
            volume_fan = 0;
            if self.fan_numMag > 0
                fan_rho2 = self.fan_rho.^2;
                volume_fan = sum(deg2rad(self.fan_phi)'.*(fan_rho2(:,2) - fan_rho2(:,1)).*self.fan_z');
            end
            weight_total = (volume_cub + volume_fan)/volume_ref*weight_ref;
        end
    end

    methods (Static)
        % Approximate a fan with trapezoids
        function [num_trapz,rot_angle_list,trapz_2sides] = Fan2Trapz(fan_rho,fan_phi)
        % Approximate a fan sector with equal-angle trapezoids.
        % Input:
        %   fan_rho - Inner and outer fan radii [mm].
        %   fan_phi - Half-angle span of the fan [degree].
        % Output:
        %   num_trapz - Number of trapezoids.
        %   rot_angle_list - Yaw angle for each trapezoid [degree].
        %   trapz_2sides - Short and long side lengths of each trapezoid [mm].
        
            % Get lower bound
            num_trapz = floor(fan_phi/10);
            
            % Area of the fan
            A_fan = (fan_rho(2)^2-fan_rho(1)^2)*deg2rad(2*fan_phi)/2;
            
            A_err = A_fan;
            A_tol = 0.01*A_fan;     % A tolerance of 1%
            
            h_trapz = diff(fan_rho);
            while A_err > A_tol
                num_trapz = num_trapz + 1;
                trapz_phi = fan_phi/num_trapz;
                len_short = 2*fan_rho(1)*tand(trapz_phi);
                len_long = 2*fan_rho(2)*tand(trapz_phi);
                A_trapz = num_trapz*(len_short+len_long)*h_trapz/2;
                A_err = abs(A_fan-A_trapz);
            end
            
            % Get the rotation angles of the trapezoids
            rot_angle_list = (-fan_phi+trapz_phi):(2*trapz_phi):(fan_phi-trapz_phi);
            % Return the lengths of the lower & upper sides
            trapz_2sides = [len_short,len_long];
        end

        % Approximate a trapezoid with rectangles
        function num_rect = Trapz2Rect(trapz_2sides,trapz_h)
        % Approximate a trapezoid with rectangles.
        % Input:
        %   trapz_2sides - Short and long side lengths of the trapezoid [mm].
        %   trapz_h - Height of the trapezoid [mm].
        % Output:
        %   num_rect - Number of rectangles.

            % Get lower bound
            num_rect = floor(trapz_h/3);
            
            % Area of the fan
            A_trapz = (trapz_2sides(1)+trapz_2sides(2))*trapz_h/2;
            
            A_err = A_trapz;
            A_tol = 0.01*A_trapz;     % A tolerance of 1%
            
            side_diff = diff(trapz_2sides);
            while A_err > A_tol
                num_rect = num_rect + 1;
                rect_h = trapz_h/num_rect;
                rect_len_diff = side_diff/num_rect;
                rect_len = trapz_2sides(1):rect_len_diff:(trapz_2sides(2)-rect_len_diff);
                A_rect = sum(rect_len)*rect_h;
                A_err = abs(A_trapz-A_rect);
            end
        end
    end
end
