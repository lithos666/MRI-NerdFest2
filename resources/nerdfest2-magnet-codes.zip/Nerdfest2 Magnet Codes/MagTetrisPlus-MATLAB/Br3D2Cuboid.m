function [loc_list_out,angle_list_out,magnet_dim_list_out,Br_list_out] = Br3D2Cuboid(loc_list,angle_list,magnet_dim_list,Br_3D_list)
% Convert arbitrary 3D remanence vectors into equivalent cuboid magnets.
% Input:
%   loc_list - Source domain center locations [mm].
%   angle_list - Source domain yaw, pitch, and roll angles [degree].
%   magnet_dim_list - Source domain dimensions [mm].
%   Br_3D_list - Source remanence vectors [Br_x, Br_y, Br_z] [T].
% Output:
%   loc_list_out - Equivalent cuboid center locations [mm].
%   angle_list_out - Equivalent cuboid yaw, pitch, and roll angles [degree].
%   magnet_dim_list_out - Equivalent cuboid dimensions [mm].
%   Br_list_out - Equivalent cuboid remanence magnitudes [T].

% loop through Br_3D_list
n_mag_orig = size(Br_3D_list,1);
% Perpare large arrays to allocate enough memory
loc_list_out = zeros(n_mag_orig*3,3);
angle_list_out = zeros(n_mag_orig*3,3);
magnet_dim_list_out = zeros(n_mag_orig*3,3);
Br_list_out = zeros(1,n_mag_orig*3);

counter = 1;
for idx_mag_orig=1:n_mag_orig
    Br_3D_curr = Br_3D_list(idx_mag_orig,:);
    angle_curr = angle_list(idx_mag_orig,:);
    Br_3D_rot = RotationUtils.rotate3D(Br_3D_curr,-angle_curr,2);
    magnet_dim_curr = magnet_dim_list(idx_mag_orig,:);

    % Check Br_x component
    if Br_3D_rot(1) ~= 0
        Br_curr = abs(Br_3D_rot(1));
        %Br_curr = (Br_3D_rot(1));
        magnet_dim_real = [magnet_dim_curr(2),magnet_dim_curr(1),magnet_dim_curr(3)];
        % Get the equivalent rotation matrix
        angle_yaw = angle_curr(1);
        angle_pitch = angle_curr(2);
        angle_roll = angle_curr(3);

        rot_roll = [1,0,0;...
                    0,cosd(angle_roll),-sind(angle_roll);...
                    0,sind(angle_roll),cosd(angle_roll)];
        rot_pitch = [cosd(angle_pitch),0,sind(angle_pitch);...
                     0,1,0;...
                     -sind(angle_pitch),0,cosd(angle_pitch)];
        rot_yaw = [cosd(angle_yaw),-sind(angle_yaw),0;...
                   sind(angle_yaw),cosd(angle_yaw),0;...
                   0,0,1];
        rot_yaw_n90 = [0,1,0;...
                      -1,0,0;...
                       0,0,1];

        rot_mat = rot_yaw*rot_pitch*rot_roll*rot_yaw_n90;
        if sign(Br_3D_rot(1)) == -1
            rot_yaw_n180 = [-1,0,0;...
                            0,-1,0;...
                            0,0,1];
            rot_mat = rot_mat*rot_yaw_n180;
        end
        
        angle_real = RotationUtils.rotMatToAngle(rot_mat);
        
        % Define the equivalent magnet
        loc_list_out(counter,:) = loc_list(idx_mag_orig,:);
        angle_list_out(counter,:) = angle_real;
        magnet_dim_list_out(counter,:) = magnet_dim_real;
        Br_list_out(counter) = Br_curr;
        counter = counter + 1;
    end

    % Check Br_y component
    if Br_3D_rot(2) ~= 0
        Br_curr = abs(Br_3D_rot(2));
        %Br_curr = (Br_3D_rot(2));
        magnet_dim_real = magnet_dim_curr;
        % Get the equivalent rotation matrix
        if Br_3D_rot(2) < 0
            angle_yaw = angle_curr(1);
            angle_pitch = angle_curr(2);
            angle_roll = angle_curr(3);
            rot_roll = [1,0,0;...
                        0,cosd(angle_roll),-sind(angle_roll);...
                        0,sind(angle_roll),cosd(angle_roll)];
            rot_pitch = [cosd(angle_pitch),0,sind(angle_pitch);...
                         0,1,0;...
                         -sind(angle_pitch),0,cosd(angle_pitch)];
            rot_yaw = [cosd(angle_yaw),-sind(angle_yaw),0;...
                       sind(angle_yaw),cosd(angle_yaw),0;...
                       0,0,1];
            rot_yaw_n180 = [-1,0,0;...
                            0,-1,0;...
                            0,0,1];
            rot_mat = rot_yaw*rot_pitch*rot_roll*rot_yaw_n180;
            angle_real = RotationUtils.rotMatToAngle(rot_mat);
        else
            angle_real = angle_curr;
        end
        % Define the equivalent magnet
        loc_list_out(counter,:) = loc_list(idx_mag_orig,:);
        angle_list_out(counter,:) = angle_real;
        magnet_dim_list_out(counter,:) = magnet_dim_real;
        Br_list_out(counter) = Br_curr;
        counter = counter + 1;
    end

    % Check Br_z component
    if Br_3D_rot(3) ~= 0
        Br_curr = abs(Br_3D_rot(3));
        magnet_dim_real = [magnet_dim_curr(1),magnet_dim_curr(3),magnet_dim_curr(2)];
        angle_real = angle_curr;
        angle_real(3) = angle_real(3) + sign(Br_3D_rot(3))*90;      % +90 degree roll
        % Define the equivalent magnet
        loc_list_out(counter,:) = loc_list(idx_mag_orig,:);
        angle_list_out(counter,:) = angle_real;
        magnet_dim_list_out(counter,:) = magnet_dim_real;
        Br_list_out(counter) = Br_curr;
        counter = counter + 1;
    end
end

% Trim the output matrices
loc_list_out = loc_list_out(1:counter-1,:);
angle_list_out = angle_list_out(1:counter-1,:);
magnet_dim_list_out = magnet_dim_list_out(1:counter-1,:);
Br_list_out = Br_list_out(1:counter-1);

end
