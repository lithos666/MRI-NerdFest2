function PlotFieldMap(fig_num, FOV_1, FOV_2, B_field, surface, title_text, color_limits, font_size, reset_figure)
% Plot a 2D magnetic field map
% Input:
%   fig_num - MATLAB figure number to plot into.
%   FOV_1 - First coordinate vector for the field plane [mm].
%   FOV_2 - Second coordinate vector for the field plane [mm].
%   B_field - 2D magnetic field map [mT].
%   surface - Field-plane selector: 'x', 'y', or 'z'.
%   title_text - Plot title.
%   color_limits - Two-element color limit vector [min, max].
%   font_size - Axis, label, title, and colorbar font size.
%   reset_figure - True to clear/reset the figure before plotting.
% Output:
%   None. The function draws into the requested MATLAB figure.

if nargin < 9
    reset_figure = false;
end

figure(fig_num);
if reset_figure
    clf reset
end

pcolor(FOV_1, FOV_2, B_field);
shading flat;
clim(color_limits);
cb = colorbar;
set(get(cb, 'Title'), 'string', 'mT');
cb.FontSize = font_size;
colormap jet;
set(gcf, 'color', 'w');
ax = gca;
ax.FontSize = font_size;

if surface == 'x'
    xlabel('y/mm', 'FontSize', font_size)
    ylabel('z/mm', 'FontSize', font_size);
elseif surface == 'y'
    xlabel('x/mm', 'FontSize', font_size)
    ylabel('z/mm', 'FontSize', font_size);
elseif surface == 'z'
    xlabel('x/mm', 'FontSize', font_size);
    ylabel('y/mm', 'FontSize', font_size);
end

axis on;
title(title_text, 'FontSize', font_size);
end
