clear;
% clc;
%close all;
tic;

%% Permanent-magnet field practice
% This exercise uses the same MagTetris cuboid model as
% Generate_IORing_ShimPractice.m. It starts with one magnet, and each row
% in the control arrays represents one magnet.
%
% Edit the controls, then run the entire script. Every run shows the total
% signed Bx, By, and Bz field components. Duplicate a row in every control
% array to study how the fields from two magnets add together.

%% Controls

magnet_dim = [12, 12, 12];       % [x, y, z] dimensions in mm
magnet_Br = [1.43];                % remanence in tesla
magnet_loc = [0, 40, 0];         % magnet centre [x, y, z] in mm
magnet_angle = [0, 0, 0];        % [yaw, pitch, roll] in degrees

%% Observation plane

FOV_half_mm = 25;
FOV_x = -FOV_half_mm:1:FOV_half_mm;
FOV_y = -FOV_half_mm:1:FOV_half_mm;
FOV_z = 0;
surface = 'z';
n_per_group = 1;

n_magnets = size(magnet_loc, 1);

assert(size(magnet_loc, 2) == 3, ...
    'Each magnet_loc row must contain [x, y, z].');
assert(isequal(size(magnet_angle), [n_magnets, 3]), ...
    'magnet_angle must contain one [yaw, pitch, roll] row per magnet.');
assert(isequal(size(magnet_dim), [n_magnets, 3]), ...
    'magnet_dim must contain one [x, y, z] dimension row per magnet.');
assert(numel(magnet_Br) == n_magnets, ...
    'magnet_Br must contain one remanence value per magnet.');
assert(all(magnet_dim(:) > 0), 'All magnet dimensions must be positive.');
assert(all(magnet_Br(:) > 0), 'All magnet_Br values must be positive.');

%% Calculate the field
mt = MagTetris().AssignCuboid(magnet_loc, magnet_angle, magnet_Br, magnet_dim);

[Bx, By, Bz] = mt.Field2D(FOV_x, FOV_y, FOV_z, surface, n_per_group);

Bx_mT = 1e3 * Bx;
By_mT = 1e3 * By;
Bz_mT = 1e3 * Bz;

% Display-only copies suppress field magnitudes below 0.1 mT. The original
% Bx, By, Bz and their millitesla conversions remain unchanged.
Bx_plot_mT = Bx_mT;
By_plot_mT = By_mT;
Bz_plot_mT = Bz_mT;
Bx_plot_mT(abs(Bx_plot_mT) < 0.1) = 0;
By_plot_mT(abs(By_plot_mT) < 0.1) = 0;
Bz_plot_mT(abs(Bz_plot_mT) < 0.1) = 0;

magnetization_direction = zeros(n_magnets, 3);
for magnet_index = 1:n_magnets
    magnetization_direction(magnet_index, :) = RotationUtils.rotate3D( ...
        [0, 1, 0], magnet_angle(magnet_index, :), 1);
end

fprintf('\nNumber of cuboid magnets: %d\n', n_magnets);
for magnet_index = 1:n_magnets
    fprintf('\nMagnet %d\n', magnet_index);
    fprintf('  Dimensions [x y z]        : [%8.3f %8.3f %8.3f] mm\n', ...
        magnet_dim(magnet_index, :));
    fprintf('  Remanence                 : %8.3f T\n', ...
        magnet_Br(magnet_index));
    fprintf('  Centre [x y z]            : [%8.3f %8.3f %8.3f] mm\n', ...
        magnet_loc(magnet_index, :));
    fprintf('  Yaw, pitch, roll          : [%8.3f %8.3f %8.3f] deg\n', ...
        magnet_angle(magnet_index, :));
    fprintf('  Magnetization unit vector : [%8.4f %8.4f %8.4f]\n', ...
        magnetization_direction(magnet_index, :));
end

%% Figure 1: all three field directions

component_limit = max(abs([Bx_plot_mT(:); By_plot_mT(:); ...
                           Bz_plot_mT(:)]));
if component_limit == 0
    component_limit = 1;
end

figure(1);
clf reset;
tiledlayout(1, 3, 'TileSpacing', 'compact', 'Padding', 'compact');

nexttile;
plot_field_map(FOV_x, FOV_y, Bx_plot_mT, ...
    'Bx field', 'mT');

nexttile;
plot_field_map(FOV_x, FOV_y, By_plot_mT, ...
    'By field', 'mT');

nexttile;
plot_field_map(FOV_x, FOV_y, Bz_plot_mT, ...
    'Bz field', 'mT');

colormap turbo;

if n_magnets == 1
    sgtitle(sprintf(['Single magnet at [%.0f, %.0f, %.0f] mm, ', ...
        'yaw/pitch/roll = [%.0f, %.0f, %.0f] deg'], ...
        magnet_loc, magnet_angle));
else
    sgtitle(sprintf('%d magnets: total signed field components', n_magnets));
end

%% Figure 100: magnet location and magnetization direction

figure(100);
clf reset;
DrawMagnetization(magnet_loc, magnet_angle, magnet_dim, ...
    [0.85, 0.15, 0.15], FOV_x, FOV_y, FOV_z, surface, By_plot_mT);
if n_magnets == 1
    title('Single magnet geometry and magnetization direction');
else
    title(sprintf('%d-magnet geometry and magnetization directions', ...
        n_magnets));
end

toc;

function plot_field_map(x_axis, y_axis, field_mT, plot_title, units)
% Plot one signed Cartesian field component with a zero-centred colour range.

    pcolor(x_axis, y_axis, field_mT);
    shading flat;
    axis equal tight;
    %caxis(limits);
    xlabel('x / mm');
    ylabel('y / mm');
    title(plot_title);
    cb = colorbar;
    set(get(cb, 'Title'), 'String', units);
end
