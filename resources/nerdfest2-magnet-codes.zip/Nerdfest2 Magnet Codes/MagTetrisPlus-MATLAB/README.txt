MATLAB VERSION - NERDFEST2 MAGNET CODES
========================================

SOFTWARE: These files are intended for MathWorks MATLAB. Run the scripts
from this folder, or add this folder to the MATLAB path before running them.
For GNU Octave, use the companion files in the MagTetrisPlus-octave folder.

This folder contains a magnetostatic simulation toolkit for modelling
permanent-magnet arrays, induced magnetization in ferromagnetic objects,
and symmetric IOring field configurations.


MAIN SCRIPTS
============

File                              Purpose
--------------------------------  ------------------------------------------------------------
GenerateSmallIORing_32mT.m        Builds and evaluates the 32 mT small-IOring reference design.
                                  It expands 27 upper-quadrant seed locations into 756 total
                                  10 mm cuboid magnets arranged as 14 magnets per ring. 

GenerateIORing_37mT.m             Builds and evaluates the larger 37 mT reference design. It
                                  expands 31 seed locations into 1,736 total 12 mm cuboid
                                  magnets arranged as 28 magnets per ring. 

Magnet_FieldPractice.m            Configurable single- or multi-cuboid practice script. It
                                  calculates Bx, By, and Bz on an observation plane, prints
                                  each magnet's geometry and magnetization direction, plots all
                                  three signed field components in one figure, and creates a
                                  separate 3-D geometry/magnetization display.

Generate_IORing_ShimPractice.m    IOring shimming exercise with 12 mm main magnets and 10 mm
                                  shim magnets. It checks the design constraints, builds the
                                  main and shim arrays, calculates five-slice Bz fields, and
                                  shows the main-only, shim-only, and final summed field maps
                                  together with their mean, minimum, maximum, and peak-to-peak
                                  homogeneity metrics. It also displays both magnet groups in
                                  3-D using different colours.

ferro_cal_application.m           Example MagTetris+ workflow. It combines a permanent-magnet
                                  array with configurable ferromagnetic objects, solves their
                                  induced magnetization, calculates Bx/By/Bz field maps, and
                                  visualizes the equivalent magnets and field plane.


IORING GEOMETRY FUNCTIONS
=========================

File                              Purpose
--------------------------------  ------------------------------------------------------------
GenerateIORingPairFromQuadrant.m  Expands an upper radial/axial seed layout into complete upper
                                  and symmetry-related lower rings. Each seed may have its own
                                  position, dimensions, magnetization angle, and remanence. The
                                  function validates inputs, rejects positive-volume cuboid
                                  overlaps, and plots the supplied geometry footprints.

GenerateIORingPair.m              Legacy, simpler generator for one symmetric pair of identical
                                  rings. New IOring designs should normally use
                                  GenerateIORingPairFromQuadrant.m.


CORE SIMULATION AND FERROMAGNETIC FUNCTIONS
===========================================

File                              Purpose
--------------------------------  ------------------------------------------------------------
MagTetris.m                       Main simulation class. Stores cuboid and fan-shaped magnets;
                                  rotates and combines arrays; evaluates fields on regular
                                  planes or arbitrary 3-D points; estimates forces; converts
                                  fan geometry into numerical approximations; and calculates
                                  total magnet weight.

MagTetrisPlus.m                   High-level ferromagnetic wrapper. Discretizes each supplied
                                  ferromagnetic object, solves its induced remanence, and
                                  returns the result as equivalent cuboid magnets in a second
                                  MagTetris object.

PrepareFerromagneticDomains.m     Classifies ferromagnetic objects as plate-, rod-, or cube-like
                                  and divides them into smaller cuboid calculation domains.

FerroCalculation.m               Iteratively solves induced domain magnetization using the
                                  initial iron magnetization curve, demagnetization, mutual
                                  coupling, damping, anisotropy approximations, and saturation.

ComputeDemagnetization.m          Calculates approximate cuboid demagnetization factors or
                                  effective local demagnetization tensors for discretized
                                  ferromagnetic domains.

Br3D2Cuboid.m                     Decomposes each arbitrary 3-D remanence vector into as many as
                                  three co-located, axis-aligned equivalent cuboid magnets.

RotationUtils.m                   Provides shared yaw-pitch-roll rotation matrices, vector
                                  rotation, and rotation-matrix-to-angle conversion utilities.


PLOTTING FUNCTIONS
==================

File                              Purpose
--------------------------------  ------------------------------------------------------------
PlotFieldMap.m                    Plots one 2-D magnetic-field component with labelled axes, a
                                  jet colour scale, and a colourbar labelled in millitesla.

DrawMagnetization.m               Draws cuboid geometry, magnetization-direction arrows, and an
                                  optional coloured magnetic-field plane in a 3-D figure.


DOCUMENTATION AND AUXILIARY FILES
=================================

File                              Purpose
--------------------------------  ------------------------------------------------------------
MagTetrisPlus_Introduction.pptx   Introductory presentation for the MagTetrisPlus project.

Generate_IORing_ShimPractice.asv  MATLAB Editor autosave backup. It is not the current shimming
                                  script and normally should not be run directly.


DISPLAY AND DATA CONVENTIONS
============================

- Geometry and locations are expressed in millimetres.
- Magnetic field and remanence values are expressed in tesla unless a
  script explicitly converts them to millitesla for reporting or display.
- An unrotated cuboid magnet is polarized along its local +Y direction.
- Orientations use yaw, pitch, and roll angles in degrees.