function [geometry, unit_thres, ferro_loc, orient_angle, geo_param, sep_idx] = PrepareFerromagneticDomains(PMA_MT, ferro_loc_raw, orient_angle_raw, geo_param_raw, unit_thres_override)
% Classify ferromagnetic geometry and discretize objects into domains.
% Input:
%   PMA_MT - MagTetris object containing the permanent magnet array.
%   ferro_loc_raw - Original ferromagnetic object center locations [mm].
%   orient_angle_raw - Original ferromagnetic yaw, pitch, and roll angles [degree].
%   geo_param_raw - Original ferromagnetic object dimensions [mm].
%   unit_thres_override - Optional domain-size threshold override [mm].
% Output:
%   geometry - Geometry and magnetization-direction classification flags.
%   unit_thres - Domain-size threshold used for discretization [mm].
%   ferro_loc - Discretized domain center locations [mm].
%   orient_angle - Discretized domain yaw, pitch, and roll angles [degree].
%   geo_param - Discretized domain dimensions [mm].
%   sep_idx - End index of each original object in the discretized arrays.

if nargin < 5
    unit_thres_override = [];
end

geometry.plate = 0;
geometry.rod = 0;
geometry.cube = 0;
geometry.singledomain = 0;
geometry.magnetization_along_hard_axis = 0;
geometry.magnetization_along_easy_axis = 0;

sorted = sort(geo_param_raw, 'descend');
long = sorted(1);
middle = sorted(2);
short = sorted(3);

if long / middle >= 3
    geometry.rod = 1;
end
if middle / short >= 3
    geometry.plate = 1;
end
if geometry.rod + geometry.plate == 0
    geometry.cube = 1;
end

classification_unit_thres = 1;
[probe_loc, probe_angle, ~, ~] = discretizeBlock( ...
    ferro_loc_raw, orient_angle_raw, geo_param_raw, classification_unit_thres);

FOV_x = probe_loc(:,1);
FOV_y = probe_loc(:,2);
FOV_z = probe_loc(:,3);
[Bx_PMA, By_PMA, Bz_PMA] = PMA_MT.Field2DFree(FOV_x, FOV_y, FOV_z);

B0_3D = [Bx_PMA, By_PMA, Bz_PMA];
B0_3D_rot = RotationUtils.rotate3D(B0_3D, -probe_angle(1,:), 2);

n_3D_global = ComputeDemagnetization('factors', geo_param_raw);

if geometry.plate == 1 && geometry.rod == 0
    hard_axis_mask = n_3D_global - max(n_3D_global, [], 2);
    hard_axis_mask = (hard_axis_mask == 0);

    B0_3D_rot_sum_percentage = sum(B0_3D_rot);
    B0_3D_rot_sum_percentage = abs(B0_3D_rot_sum_percentage) ./ sum(abs(B0_3D_rot_sum_percentage), 2);

    B0_3D_rot_hard_axis_weight = B0_3D_rot_sum_percentage .* hard_axis_mask;
    B0_3D_rot_hard_axis_weight = sum(B0_3D_rot_hard_axis_weight, 2);
    B0_3D_rot_hard_axis_weight = mean(B0_3D_rot_hard_axis_weight);

    if B0_3D_rot_hard_axis_weight > 0.6
        geometry.magnetization_along_hard_axis = 1;
    else
        geometry.magnetization_along_easy_axis = 1;
    end
end

if geometry.plate == 0 && geometry.rod == 1
    easy_axis_mask = n_3D_global - min(n_3D_global, [], 2);
    easy_axis_mask = (easy_axis_mask == 0);
    hard_axis_mask = ones(size(easy_axis_mask)) - easy_axis_mask;

    B0_3D_rot_copy = B0_3D_rot;
    B0_3D_rot_copy_hard_axis = B0_3D_rot_copy .* hard_axis_mask;
    B0_3D_rot_copy_easy_axis = B0_3D_rot_copy .* easy_axis_mask;
    B0_3D_rot_copy_easy_axis = abs(B0_3D_rot_copy_easy_axis);
    B0_3D_rot_copy = B0_3D_rot_copy_hard_axis + B0_3D_rot_copy_easy_axis;

    B0_3D_rot_sum_percentage = sum(B0_3D_rot_copy);
    B0_3D_rot_sum_percentage = abs(B0_3D_rot_sum_percentage) ./ sum(abs(B0_3D_rot_sum_percentage), 2);

    B0_3D_rot_easy_axis_weight = B0_3D_rot_sum_percentage .* easy_axis_mask;
    B0_3D_rot_easy_axis_weight = sum(B0_3D_rot_easy_axis_weight, 2);
    B0_3D_rot_easy_axis_weight = mean(B0_3D_rot_easy_axis_weight);

    if B0_3D_rot_easy_axis_weight > 0.4
        geometry.magnetization_along_easy_axis = 1;
    else
        geometry.magnetization_along_hard_axis = 1;
    end
end

if geometry.plate == 1 && geometry.rod == 1
    easy_axis_mask = n_3D_global - min(n_3D_global, [], 2);
    easy_axis_mask = (easy_axis_mask == 0);
    hard_axis_mask = n_3D_global - max(n_3D_global, [], 2);
    hard_axis_mask = (hard_axis_mask == 0);
    middle_axis_mask = ones(size(easy_axis_mask)) - easy_axis_mask - hard_axis_mask;

    B0_3D_rot_copy = B0_3D_rot;
    B0_3D_rot_copy_hard_axis = B0_3D_rot_copy .* hard_axis_mask;
    B0_3D_rot_copy_easy_axis = B0_3D_rot_copy .* easy_axis_mask;
    B0_3D_rot_copy_middle_axis = B0_3D_rot_copy .* middle_axis_mask;
    B0_3D_rot_copy_easy_axis = abs(B0_3D_rot_copy_easy_axis);

    B0_3D_rot_copy = B0_3D_rot_copy_hard_axis + B0_3D_rot_copy_easy_axis + B0_3D_rot_copy_middle_axis;

    B0_3D_rot_sum_percentage = sum(B0_3D_rot_copy);
    B0_3D_rot_sum_percentage = abs(B0_3D_rot_sum_percentage) ./ sum(abs(B0_3D_rot_sum_percentage), 2);

    B0_3D_rot_easy_axis_weight = B0_3D_rot_sum_percentage .* easy_axis_mask;
    B0_3D_rot_easy_axis_weight = sum(B0_3D_rot_easy_axis_weight, 2);
    B0_3D_rot_easy_axis_weight = mean(B0_3D_rot_easy_axis_weight);

    B0_3D_rot_hard_axis_weight = B0_3D_rot_sum_percentage .* hard_axis_mask;
    B0_3D_rot_hard_axis_weight = sum(B0_3D_rot_hard_axis_weight, 2);
    B0_3D_rot_hard_axis_weight = mean(B0_3D_rot_hard_axis_weight);

    B0_3D_rot_copy_hard_axis = sum(B0_3D_rot_copy_hard_axis, 2);
    B0_3D_rot_copy_hard_axis_abs = abs(B0_3D_rot_copy_hard_axis);
    B0_3D_rot_copy_hard_axis_abs_sum = sum(B0_3D_rot_copy_hard_axis_abs);
    B0_3D_rot_copy_hard_axis_sum = sum(B0_3D_rot_copy_hard_axis);

    percentage = B0_3D_rot_copy_hard_axis_sum / B0_3D_rot_copy_hard_axis_abs_sum;
    B0_3D_rot_hard_axis_weight = B0_3D_rot_hard_axis_weight * (1 + percentage);

    if B0_3D_rot_hard_axis_weight > 0.6
        geometry.magnetization_along_hard_axis = 1;
    elseif B0_3D_rot_easy_axis_weight > 0.4
        geometry.magnetization_along_easy_axis = 1;
    end

    if geometry.magnetization_along_hard_axis == 1
        geometry.rod = 0;
    end
    if geometry.magnetization_along_easy_axis == 1
        geometry.plate = 0;
    end
end

volume = long * middle * short;
unit_thres = 2;

if geometry.plate == 1
    if short == 1 && volume <= 50
        unit_thres = 0.5;
    elseif short == 2 && volume <= 50
        unit_thres = 1;
    elseif short == 1 && volume > 50
        unit_thres = 1;
    else
        unit_thres = 2;
    end
elseif geometry.cube == 1
    if volume <= 500
        unit_thres = 1;
    else
        unit_thres = 2;
    end
elseif geometry.rod == 1
    if volume <= 4000
        unit_thres = 2;
    elseif volume <= 5000
        unit_thres = 4;
    elseif volume <= 6000
        unit_thres = 6;
    elseif volume <= 7000
        unit_thres = 8;
    else
        unit_thres = 10;
    end
end

if ~isempty(unit_thres_override)
    unit_thres = unit_thres_override;
end

[ferro_loc, orient_angle, geo_param, sep_idx] = discretizeBlock( ...
    ferro_loc_raw, orient_angle_raw, geo_param_raw, unit_thres);
end

function [loc_out, angle_out, mag_dim_out, sep_idx] = discretizeBlock(loc_in, angle_in, mag_dim_in, unit_thres)
% Split cuboid objects into smaller cuboid domain blocks.
% Input:
%   loc_in - Input cuboid center locations [mm].
%   angle_in - Input cuboid yaw, pitch, and roll angles [degree].
%   mag_dim_in - Input cuboid dimensions [mm].
%   unit_thres - Maximum target domain size along each dimension [mm].
% Output:
%   loc_out - Domain center locations [mm].
%   angle_out - Domain yaw, pitch, and roll angles [degree].
%   mag_dim_out - Domain dimensions [mm].
%   sep_idx - End index of each input cuboid in the output arrays.

num_in = size(loc_in, 1);
sep_idx = zeros(num_in, 1);

num_dim = ceil(mag_dim_in / unit_thres);
num_out = sum(prod(num_dim, 2));

loc_out = zeros(num_out, 3);
angle_out = zeros(num_out, 3);
mag_dim_out = zeros(num_out, 3);
n_3D_out = zeros(num_out, 3);

end_idx = 0;
for in_idx = 1:num_in
    num_x = num_dim(in_idx, 1);
    num_y = num_dim(in_idx, 2);
    num_z = num_dim(in_idx, 3);
    num_curr = num_x * num_y * num_z;

    start_idx = end_idx + 1;
    sep_idx(in_idx) = start_idx + num_curr - 1;
    end_idx = sep_idx(in_idx);

    unit_x = mag_dim_in(in_idx, 1) / num_x;
    unit_y = mag_dim_in(in_idx, 2) / num_y;
    unit_z = mag_dim_in(in_idx, 3) / num_z;

    loc_x_list = linspace(-(mag_dim_in(in_idx, 1) - unit_x) / 2, (mag_dim_in(in_idx, 1) - unit_x) / 2, num_x);
    loc_y_list = linspace(-(mag_dim_in(in_idx, 2) - unit_y) / 2, (mag_dim_in(in_idx, 2) - unit_y) / 2, num_y);
    loc_z_list = linspace(-(mag_dim_in(in_idx, 3) - unit_z) / 2, (mag_dim_in(in_idx, 3) - unit_z) / 2, num_z);

    [x_raw, y_raw, z_raw] = meshgrid(loc_x_list, loc_y_list, loc_z_list);
    loc_raw = [x_raw(:), y_raw(:), z_raw(:)];
    loc_curr = RotationUtils.rotate3D(loc_raw, angle_in(in_idx,:), 1);
    loc_curr = loc_curr + loc_in(in_idx,:);

    angle_curr = repmat(angle_in(in_idx,:), num_curr, 1);
    mag_dim_curr = repmat([unit_x, unit_y, unit_z], num_curr, 1);

    loc_out(start_idx:end_idx,:) = loc_curr;
    angle_out(start_idx:end_idx,:) = angle_curr;
    mag_dim_out(start_idx:end_idx,:) = mag_dim_curr;
end
end
