clear;
% clc;
%close all;
tic;

%% Simple IOring permanent-magnet shimming practice

% The field is evaluated across five 1 mm-spaced slices from Z = -2 mm to
% Z = +2 mm. This follows the five-slice convention used by the original
% 37 mT IOring script.
FOV_half = 25;
FOV_1 = -FOV_half:1:FOV_half;
FOV_2 = -FOV_half:1:FOV_half;
FOV_3 = 0;
slice_offsets_mm = [-2, -1, 0, 1, 2,];
surface = 'z';
n_per_group = 1;
font_size = 14;


bar_pitch_deg = 0;
array_rotation_deg = bar_pitch_deg / 2;

%% Main array with 30 mm magnets
% Fill locations as [R, positive Z] in mm, one row per seed.
% Set either location or angle to [] to disable this group.
quadrant_main_loc = [];
quadrant_main_angle = [];

main_dim = [30,30,30];
main_Br = 1.43;
n_bar_main = 8;

%% Shim array with 10 mm magnets
quadrant_shim_loc = [];
quadrant_shim_angle = [];

shim_dim = [10, 10, 10];
shim_Br = 1.43;
n_bar_shim = 40;

%% Optional group activation (no geometric assertion checks)
main_parameters_empty = isempty(quadrant_main_loc) || isempty(quadrant_main_angle);
shim_parameters_empty = isempty(quadrant_shim_loc) || isempty(quadrant_shim_angle);

main_radius_min = NaN;
main_radius_max = NaN;
if ~main_parameters_empty
    main_radius_min = min(quadrant_main_loc(:, 1));
    main_radius_max = max(quadrant_main_loc(:, 1));
end

%% Generate and separate the main and shim arrays

% Treat a magnet group as absent when either member of its location-angle
% pair is empty. This lets students run the main-only or shim-only stages.
if main_parameters_empty
    active_main_loc = zeros(0, 2);
    active_main_angle = zeros(0, 1);
else
    active_main_loc = quadrant_main_loc;
    active_main_angle = quadrant_main_angle;
end

if shim_parameters_empty
    active_quadrant_shim_loc = zeros(0, 2);
    active_quadrant_shim_angle = zeros(0, 1);
else
    active_quadrant_shim_loc = quadrant_shim_loc;
    active_quadrant_shim_angle = quadrant_shim_angle;
end

% Only pass a nonempty design to GenerateIORingPairFromQuadrant.
% Some versions of this helper cannot accept empty input arrays.
Main_MT = [];
Shim_MT = [];
n_main = 0;
n_shim = 0;

if ~main_parameters_empty || ~shim_parameters_empty
    rotation_xy = [cosd(array_rotation_deg), -sind(array_rotation_deg); ...
                   sind(array_rotation_deg),  cosd(array_rotation_deg)];

    if ~main_parameters_empty
        main_quadrant_dim = repmat( ...
            main_dim, size(active_main_loc, 1), 1);
        main_quadrant_Br = main_Br * ones(size(active_main_loc, 1), 1);

        [main_loc, main_angle, main_magnet_dim, main_magnet_Br] = ...
            GenerateIORingPairFromQuadrant( ...
            n_bar_main, active_main_loc, main_quadrant_dim, ...
            active_main_angle, main_quadrant_Br);

        main_loc(:, 1:2) = main_loc(:, 1:2) * rotation_xy.';
        main_angle(:, 1) = mod( ...
            main_angle(:, 1) + array_rotation_deg, 360);
        n_main = size(main_loc, 1);

        % Check for overlaps within the main array.
        assert_no_magnet_overlap(main_loc, main_angle(:,1), ...
            main_magnet_dim, 'main array');

        Main_MT = MagTetris().AssignCuboid( ...
            main_loc, main_angle, main_magnet_Br, main_magnet_dim);
    end

    if ~shim_parameters_empty
        shim_quadrant_dim = repmat( ...
            shim_dim, size(active_quadrant_shim_loc, 1), 1);
        shim_quadrant_Br = shim_Br * ones( ...
            size(active_quadrant_shim_loc, 1), 1);

        [shim_loc, shim_angle, shim_magnet_dim, shim_magnet_Br] = ...
            GenerateIORingPairFromQuadrant( ...
            n_bar_shim, active_quadrant_shim_loc, shim_quadrant_dim, ...
            active_quadrant_shim_angle, shim_quadrant_Br);

        shim_loc(:, 1:2) = shim_loc(:, 1:2) * rotation_xy.';
        shim_angle(:, 1) = mod( ...
            shim_angle(:, 1) + array_rotation_deg, 360);
        n_shim = size(shim_loc, 1);
        % Check for overlaps within the shim array.
        assert_no_magnet_overlap( ...
            shim_loc, shim_angle(:,1), ...
            shim_magnet_dim, 'shim array');

        % Check for overlaps within the shim array.
        assert_no_magnet_overlap(shim_loc, shim_angle(:,1), ...
            shim_magnet_dim, 'shim array');

        Shim_MT = MagTetris().AssignCuboid( ...
            shim_loc, shim_angle, shim_magnet_Br, shim_magnet_dim);
    end

    % Also check for overlaps between main magnets and shim magnets.
    if ~main_parameters_empty && ~shim_parameters_empty
        assert_no_magnet_overlap( ...
            [main_loc; shim_loc], ...
            [main_angle(:,1); shim_angle(:,1)], ...
            [main_magnet_dim; shim_magnet_dim], ...
            'combined main and shim arrays');
    end
else
    fprintf('Both magnet groups are empty; displaying zero field.\n');
end

% Each GenerateIORingPairFromQuadrant call redraws figure 9, so the shim
% call above replaces the main-magnet quadrant plot. Redraw the quadrant
% once with both seed groups after their separate n_bar generations finish.
plot_combined_quadrant( ...
    active_main_loc, active_main_angle, main_dim, ...
    active_quadrant_shim_loc, active_quadrant_shim_angle, shim_dim);

fprintf('Main magnets                : %d\n', n_main);
fprintf('Shim magnets                : %d\n', n_shim);
fprintf('Main radial range           : %.1f to %.1f mm\n', ...
    main_radius_min, main_radius_max);
fprintf('Shim seed rings\n');
for shim_index = 1:size(active_quadrant_shim_loc, 1)
    fprintf('  R = %.1f mm, Z = +/-%.1f mm, angle = %.0f degrees\n', ...
        active_quadrant_shim_loc(shim_index, 1), active_quadrant_shim_loc(shim_index, 2), ...
        active_quadrant_shim_angle(shim_index));
end
fprintf('\n');

%% Calculate the unshimmed and shimmed Bz fields

[Bz_main, Bz_main_slices] = averaged_bz( ...
    Main_MT, FOV_1, FOV_2, slice_offsets_mm, n_per_group);
[Bz_shim, Bz_shim_slices] = averaged_bz( ...
    Shim_MT, FOV_1, FOV_2, slice_offsets_mm, n_per_group);

Bz_total = Bz_main + Bz_shim;
Bz_total_slices = Bz_main_slices + Bz_shim_slices;

% Keep only the circular field of view and convert tesla to millitesla.
[FOV_x, FOV_y] = meshgrid(FOV_1, FOV_2);
outside_FOV = hypot(FOV_x, FOV_y) > FOV_half;

Bz_main_mT = 1e3 * Bz_main;
Bz_shim_mT = 1e3 * Bz_shim;
Bz_total_mT = 1e3 * Bz_total;
Bz_main_mT(outside_FOV) = NaN;
Bz_shim_mT(outside_FOV) = NaN;
Bz_total_mT(outside_FOV) = NaN;

Bz_main_slices_mT = mask_and_scale_field_stack( ...
    Bz_main_slices, outside_FOV, 1e3);
Bz_shim_slices_mT = mask_and_scale_field_stack( ...
    Bz_shim_slices, outside_FOV, 1e3);
Bz_total_slices_mT = mask_and_scale_field_stack( ...
    Bz_total_slices, outside_FOV, 1e3);

metrics_before = calc_B0_homogeneity(Bz_main_slices_mT);
metrics_shim = calc_B0_homogeneity(Bz_shim_slices_mT);
metrics_after = calc_B0_homogeneity(Bz_total_slices_mT);
% ppm and improvement are undefined if the reference mean or variation is zero.
improvement_percent = NaN;
if isfinite(metrics_before.hom_ppm_pp) && ...
        metrics_before.hom_ppm_pp > 0 && isfinite(metrics_after.hom_ppm_pp)
    improvement_percent = 100 * ...
        (1 - metrics_after.hom_ppm_pp / metrics_before.hom_ppm_pp);
end

fprintf('Before shimming\n');
print_metrics(metrics_before);
fprintf('\nShim-only field\n');
print_metrics(metrics_shim);
fprintf('\nAfter shimming\n');
print_metrics(metrics_after);
fprintf('\nPeak-to-peak improvement    : %.2f %%\n\n', improvement_percent);

% Display-only copies suppress field magnitudes below 0.1 mT. All metrics
% continue to use the original unmodified field arrays above.
Bz_main_plot_mT = Bz_main_mT;
Bz_shim_plot_mT = Bz_shim_mT;
Bz_total_plot_mT = Bz_total_mT;
Bz_main_plot_mT(abs(Bz_main_plot_mT) < 0.1) = 0;
Bz_shim_plot_mT(abs(Bz_shim_plot_mT) < 0.1) = 0;
Bz_total_plot_mT(abs(Bz_total_plot_mT) < 0.1) = 0;

%% Plot the main, shim-only, and final Bz fields

figure(2);
clf reset;
tiledlayout(1, 3, 'TileSpacing', 'compact', 'Padding', 'compact');

nexttile;
pcolor(FOV_1, FOV_2, Bz_main_plot_mT);
axis equal tight;
shading flat;
cb = colorbar;
set(get(cb, 'Title'), 'String', 'mT');
colormap jet;
set(gca, 'FontSize', font_size);
xlabel('x / mm');
ylabel('y / mm');
title(field_statistics_title('Main magnets', metrics_before));

nexttile;
pcolor(FOV_1, FOV_2, Bz_shim_plot_mT);
axis equal tight;
shading flat;
cb = colorbar;
set(get(cb, 'Title'), 'String', 'mT');
colormap jet;
set(gca, 'FontSize', font_size);
xlabel('x / mm');
ylabel('y / mm');
title(field_statistics_title('Shim magnets only', metrics_shim));

nexttile;
pcolor(FOV_1, FOV_2, Bz_total_plot_mT);
axis equal tight;
shading flat;
cb = colorbar;
set(get(cb, 'Title'), 'String', 'mT');
colormap jet;
set(gca, 'FontSize', font_size);
xlabel('x / mm');
ylabel('y / mm');
title(field_statistics_title('Final sum', metrics_after));

%% Display the main and shim magnets

figure(100);
clf reset;
if n_main > 0
    DrawMagnetization(Main_MT.cub_loc, Main_MT.cub_angle, ...
        Main_MT.cub_dim, [0.85, 0.15, 0.15], ...
        FOV_1, FOV_2, FOV_3, surface, Bz_total_plot_mT);
end
if n_shim > 0
    DrawMagnetization(Shim_MT.cub_loc, Shim_MT.cub_angle, ...
        Shim_MT.cub_dim, [0.15, 0.35, 0.90], ...
        FOV_1, FOV_2, FOV_3, surface, Bz_total_plot_mT);
end
if n_main == 0 && n_shim == 0
    text(0.5, 0.5, 'No magnets configured', ...
        'Units', 'normalized', 'HorizontalAlignment', 'center');
    axis off;
end
title('Main magnets (red) and shim magnets (blue)');

toc;


function [Bz_average, Bz_slices] = averaged_bz( ...
        mt, axis_1, axis_2, slice_offsets_mm, n_per_group)
% Return zero-field matrices for any absent magnet group.
    n_slice = numel(slice_offsets_mm);
    Bz_slices = zeros(numel(axis_2), numel(axis_1), n_slice);
    if ~isempty(mt) && n_slice > 0
        for slice_index = 1:n_slice
            [~, ~, Bz_slices(:, :, slice_index)] = mt.Field2D( ...
                axis_1, axis_2, slice_offsets_mm(slice_index), ...
                'z', n_per_group);
        end
    end
    if n_slice == 0
        Bz_average = zeros(numel(axis_2), numel(axis_1));
    else
        Bz_average = mean(Bz_slices, 3);
    end
end


function scaled_stack = mask_and_scale_field_stack( ...
        field_stack, outside_mask, scale_factor)
    scaled_stack = scale_factor * field_stack;
    for slice_index = 1:size(scaled_stack, 3)
        slice = scaled_stack(:, :, slice_index);
        slice(outside_mask) = NaN;
        scaled_stack(:, :, slice_index) = slice;
    end
end


function metrics = calc_B0_homogeneity(Bmap)
    B = Bmap(isfinite(Bmap));
    if isempty(B)
        error('Bmap contains no valid finite values.');
    end

    metrics = struct();
    metrics.Bmax = max(B);
    metrics.Bmin = min(B);
    metrics.Bmean = mean(B);
    metrics.Bstd = std(B);
    metrics.deltaB_pp = metrics.Bmax - metrics.Bmin;
    if abs(metrics.Bmean) <= eps
        metrics.hom_ppm_pp = NaN;
        metrics.hom_ppm_std = NaN;
    else
        metrics.hom_ppm_pp = metrics.deltaB_pp / abs(metrics.Bmean) * 1e6;
        metrics.hom_ppm_std = metrics.Bstd / abs(metrics.Bmean) * 1e6;
    end
end


function print_metrics(metrics)
    fprintf('Mean Bz                     : %.6f mT\n', metrics.Bmean);
    fprintf('Maximum Bz                  : %.6f mT\n', metrics.Bmax);
    fprintf('Minimum Bz                  : %.6f mT\n', metrics.Bmin);
    fprintf('Peak-to-peak homogeneity    : %.6f ppm\n', metrics.hom_ppm_pp);
    fprintf('Standard-deviation homogeneity: %.6f ppm\n', ...
        metrics.hom_ppm_std);
end


function title_lines = field_statistics_title(field_name, metrics)
    title_lines = { ...
        field_name; ...
        sprintf('Mean %.4f mT', metrics.Bmean); ...
        sprintf('Min %.4f | Max %.4f mT', metrics.Bmin, metrics.Bmax); ...
        sprintf('Peak-to-peak %.1f ppm', metrics.hom_ppm_pp)};
end


function plot_combined_quadrant( ...
        main_loc, main_angle, main_dim, shim_loc, shim_angle, shim_dim)
% Plot both groups without coupling their separate n_bar values.

    loc = [main_loc; shim_loc];
    angle = [main_angle(:); shim_angle(:)];
    dim = [ ...
        repmat(main_dim, size(main_loc, 1), 1); ...
        repmat(shim_dim, size(shim_loc, 1), 1)];

    if isempty(loc)
        return;
    end

    plot_combined_rz_footprint( ...
        9, loc, angle, dim, ...
        'IOring input quadrant: main and shim magnets', true);

    mirror_rows = loc(:, 2) > 1e-9;
    half_loc = [ ...
        loc; ...
        loc(mirror_rows, 1), -loc(mirror_rows, 2)];
    half_angle = [ ...
        angle; ...
        mod(180 - angle(mirror_rows), 360)];
    half_dim = [dim; dim(mirror_rows, :)];

    plot_combined_rz_footprint( ...
        11, half_loc, half_angle, half_dim, ...
        'IOring half cross-section: main and shim magnets', false);
end


function plot_combined_rz_footprint( ...
        figure_number, loc, angle, dim, title_text, clamp_to_positive_z)
    n_magnet = size(loc, 1);
    r_corners = zeros(n_magnet, 4);
    z_corners = zeros(n_magnet, 4);
    corner_signs = [-1, -1; 1, -1; 1, 1; -1, 1];

    for magnet_index = 1:n_magnet
        % Match the R-Z orientation convention used by
        % GenerateIORingPairFromQuadrant.
        local_y_rz = [ ...
            -cosd(angle(magnet_index)), sind(angle(magnet_index))];
        local_z_rz = [ ...
            sind(angle(magnet_index)), cosd(angle(magnet_index))];
        center = loc(magnet_index, :);

        for corner_index = 1:4
            corner = center + ...
                corner_signs(corner_index, 1) * ...
                dim(magnet_index, 2) / 2 * local_y_rz + ...
                corner_signs(corner_index, 2) * ...
                dim(magnet_index, 3) / 2 * local_z_rz;
            r_corners(magnet_index, corner_index) = corner(1);
            z_corners(magnet_index, corner_index) = corner(2);
        end
    end

    figure(figure_number);
    clf reset;
    hold on;

    for magnet_index = 1:n_magnet
        patch( ...
            r_corners(magnet_index, :), z_corners(magnet_index, :), 'w', ...
            'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1.8);

        unit_r = -cosd(angle(magnet_index));
        unit_z = sind(angle(magnet_index));
        arrow_length = 0.72 * dim(magnet_index, 2);
        tail_offset = 0.40 * dim(magnet_index, 2);
        quiver( ...
            loc(magnet_index, 1) - tail_offset * unit_r, ...
            loc(magnet_index, 2) - tail_offset * unit_z, ...
            arrow_length * unit_r, arrow_length * unit_z, 0, ...
            'Color', 'k', 'LineWidth', 2, 'MaxHeadSize', 3, ...
            'HandleVisibility', 'off');
    end

    yline(0, '--k', 'Z = 0 mirror plane', ...
        'LabelHorizontalAlignment', 'left', 'HandleVisibility', 'off');
    grid on;
    box on;
    axis equal;

    margin_mm = max(0.08 * max(dim(:, 2:3), [], 'all'), 5);
    xlim([max(0, min(r_corners, [], 'all') - margin_mm), ...
          max(r_corners, [], 'all') + margin_mm]);
    z_min = min(z_corners, [], 'all') - margin_mm;
    if clamp_to_positive_z
        z_min = min(0, z_min);
    end
    ylim([z_min, max(z_corners, [], 'all') + margin_mm]);
    xlabel('R / mm');
    ylabel('Z / mm');
    title(title_text);

    ax = gca;
    ax.FontSize = 12;
    ax.GridAlpha = 0.25;
    ax.Layer = 'top';
end


function assert_no_magnet_overlap(loc, angle_deg, dim, group_name)
% Assert that no two cuboid magnets overlap.
% Magnet centres are in loc (N x 3), dimensions in dim (N x 3),
% and angle_deg is the rotation about the z-axis in degrees.
% Face-to-face contact is allowed.

    n = size(loc, 1);

    assert(size(loc,2) == 3, ...
        '%s: magnet locations must have 3 columns.', group_name);
    assert(size(dim,1) == n && size(dim,2) == 3, ...
        '%s: magnet dimensions must be N x 3.', group_name);
    assert(numel(angle_deg) == n, ...
        '%s: need one z-rotation angle per magnet.', group_name);
    assert(all(isfinite(loc(:))) && all(isfinite(dim(:))) && ...
        all(isfinite(angle_deg(:))), ...
        '%s: geometry contains non-finite values.', group_name);
    assert(all(dim(:) > 0), ...
        '%s: magnet dimensions must be positive.', group_name);

    angle_deg = angle_deg(:);
    half_dim = dim / 2;
    tol = 1e-9;  % geometry units are mm

    % Build each cuboid's local coordinate axes in global coordinates.
    axes_all = zeros(3,3,n);
    for k = 1:n
        c = cosd(angle_deg(k));
        s = sind(angle_deg(k));
        axes_all(:,:,k) = [c, -s, 0; ...
                           s,  c, 0; ...
                           0,  0, 1];
    end

    % Separating Axis Theorem (15 candidate axes per cuboid pair).
    for i = 1:n-1
        for j = i+1:n
            A = axes_all(:,:,i);
            B = axes_all(:,:,j);
            hA = half_dim(i,:).';
            hB = half_dim(j,:).';

            R = A.' * B;
            AbsR = abs(R) + 1e-12;
            t = A.' * (loc(j,:).' - loc(i,:).');

            separated = false;

            % Test the three local axes of magnet i.
            for a = 1:3
                ra = hA(a);
                rb = sum(hB .* AbsR(a,:).');
                if abs(t(a)) >= ra + rb - tol
                    separated = true;
                    break;
                end
            end
            if separated
                continue;
            end

            % Test the three local axes of magnet j.
            for b = 1:3
                ra = sum(hA .* AbsR(:,b));
                rb = hB(b);
                distance = abs(t.' * R(:,b));
                if distance >= ra + rb - tol
                    separated = true;
                    break;
                end
            end
            if separated
                continue;
            end

            % Test the nine cross-product axes.
            for a = 1:3
                for b = 1:3
                    a1 = mod(a,3) + 1;
                    a2 = mod(a+1,3) + 1;
                    b1 = mod(b,3) + 1;
                    b2 = mod(b+1,3) + 1;

                    ra = hA(a1)*AbsR(a2,b) + hA(a2)*AbsR(a1,b);
                    rb = hB(b1)*AbsR(a,b2) + hB(b2)*AbsR(a,b1);
                    distance = abs(t(a2)*R(a1,b) - t(a1)*R(a2,b));

                    if distance >= ra + rb - tol
                        separated = true;
                        break;
                    end
                end
                if separated
                    break;
                end
            end

            assert(separated, ...
                '%s: magnets %d and %d overlap.', group_name, i, j);
        end
    end

    fprintf('Overlap check passed: %s (%d magnets).\\n', group_name, n);
end
