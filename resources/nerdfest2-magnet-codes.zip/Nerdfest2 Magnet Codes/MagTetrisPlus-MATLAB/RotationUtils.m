classdef RotationUtils
    % Shared static rotation helpers used by MagTetris and MagTetris+.

    methods (Static)
        function var_final = rotate3D(var_orig, angle_rot, mode)
            % Rotate rows of 3D coordinates, vectors, forces, or fields.
            % Input:
            %   var_orig - N-by-3 matrix of input rows to rotate.
            %   angle_rot - Yaw, pitch, and roll angles [degree].
            %   mode - Rotation order, 1 for yaw-pitch-roll or 2 for roll-pitch-yaw.
            % Output:
            %   var_final - N-by-3 matrix after rotation.
            angle_yaw = angle_rot(1);
            angle_pitch = angle_rot(2);
            angle_roll = angle_rot(3);

            rot_mat = RotationUtils.matrixFromAngles([angle_yaw, angle_pitch, angle_roll], mode);
            var_final = (rot_mat * var_orig')';
        end

        function angle_rot = rotMatToAngle(rot_mat)
            % Generate one yaw-pitch-roll solution from a rotation matrix.
            % Input:
            %   rot_mat - 3-by-3 rotation matrix.
            % Output:
            %   angle_rot - Yaw, pitch, and roll angles [degree].
            pitch = -asind(rot_mat(3,1));
            if rot_mat(3,1) == 1
                pitch = -90;
                yaw = 0;
                roll = atan2d(-rot_mat(1,2), -rot_mat(1,3));
            elseif rot_mat(3,1) == -1
                pitch = 90;
                yaw = 0;
                roll = atan2d(rot_mat(1,2), rot_mat(1,3));
            else
                c_pitch = cosd(pitch);
                roll = atan2d(rot_mat(3,2) / c_pitch, rot_mat(3,3) / c_pitch);
                yaw = atan2d(rot_mat(2,1) / c_pitch, rot_mat(1,1) / c_pitch);
            end

            angle_rot = [yaw, pitch, roll];
        end

        function R = matrixFromAngles(angle_rot, mode)
            % Build a 3D rotation matrix from yaw, pitch, and roll angles.
            % Input:
            %   angle_rot - Yaw, pitch, and roll angles [degree].
            %   mode - Rotation order, 1 for yaw-pitch-roll or 2 for roll-pitch-yaw.
            % Output:
            %   R - 3-by-3 rotation matrix.
            yaw = angle_rot(1);
            pitch = angle_rot(2);
            roll = angle_rot(3);

            Rroll = [1, 0, 0; ...
                     0, cosd(roll), -sind(roll); ...
                     0, sind(roll), cosd(roll)];
            Rpitch = [cosd(pitch), 0, sind(pitch); ...
                      0, 1, 0; ...
                      -sind(pitch), 0, cosd(pitch)];
            Ryaw = [cosd(yaw), -sind(yaw), 0; ...
                    sind(yaw), cosd(yaw), 0; ...
                    0, 0, 1];

            if mode == 1
                R = Ryaw * Rpitch * Rroll;
            elseif mode == 2
                R = Rroll * Rpitch * Ryaw;
            else
                error('RotationUtils:InvalidMode', 'mode must be 1 or 2.');
            end
        end
    end
end
