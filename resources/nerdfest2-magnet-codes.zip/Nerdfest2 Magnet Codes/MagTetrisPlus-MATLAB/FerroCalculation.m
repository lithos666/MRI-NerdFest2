function Br_3D = FerroCalculation(B0_3D,ferro_loc,geo_param,orient_angle,geo_param_raw,geometry,options)
% Solve induced 3D remanence for discretized ferromagnetic domains.
% Input:
%   B0_3D - External field at each domain center [T], as [Bx, By, Bz].
%   ferro_loc - Domain center locations [mm].
%   geo_param - Domain dimensions [mm].
%   orient_angle - Domain yaw, pitch, and roll angles [degree].
%   geo_param_raw - Original ferromagnetic object dimensions [mm].
%   geometry - Geometry flags from PrepareFerromagneticDomains.
%   options - Optional solver settings such as verbose and damping values.
% Output:
%   Br_3D - Induced 3D remanence vectors in global coordinates [T].

if nargin < 7 || isempty(options)
    options = struct();
end

verbose = isfield(options, 'verbose') && options.verbose;
if isfield(options, 'convergence_tolerance')
    convergence_tolerance = options.convergence_tolerance;
else
    convergence_tolerance = 1;
end
if isfield(options, 'max_iterations')
    max_iterations = options.max_iterations;
else
    max_iterations = 20;
end
if isfield(options, 'initial_damping_offset')
    damping_factor_offset = options.initial_damping_offset;
else
    damping_factor_offset = 0;
end
if isfield(options, 'damping_step')
    damping_step = options.damping_step;
else
    damping_step = 0.1;
end

mu_0 = 1.25663753e-6;

if geometry.cube == 1
    [N_tensor] = ComputeDemagnetization('tensor', geo_param, ferro_loc, [], false);
elseif geometry.plate == 1
    [N_tensor] = ComputeDemagnetization('tensor', geo_param, ferro_loc, orient_angle, true);
else
    n_3D_full = ComputeDemagnetization('factors', geo_param_raw);
    num_domains = size(ferro_loc, 1);
    n_3D = repmat(n_3D_full, num_domains, 1);
end

FOV_x = ferro_loc(:,1);
FOV_y = ferro_loc(:,2);
FOV_z = ferro_loc(:,3);

Br_3D_prev = zeros(size(B0_3D));
num_ferro = size(B0_3D);
num_ferro = num_ferro(1);
Br_diff_prev = 0;
counter = 0;
convergence_flag = 0;
Br_convergence_prev = 100;


while convergence_flag == 0

    B0_3D_rot = B0_3D;
    H_in_3D = B0_3D_rot/mu_0;
    coupling_damping_factor = 0;

    
    % Account for coupling effect after first iteration
    %------start of domains coupling----------
    if counter > 0 
        parfor i=1:num_ferro
            %clone the variables into temp variables
            ferro_loc_temp = ferro_loc;
            orient_angle_temp = orient_angle;
            geo_param_temp = geo_param;
            Br_3D_prev_temp = Br_3D_prev;
            
            %remove the current ferro that is being modeled for coupling
            ferro_loc_temp(i,:) = [];
            orient_angle_temp(i,:) = [];
            geo_param_temp(i,:) = [];
            Br_3D_prev_temp(i,:) = [];
            %{
            %}

            %calculate B field due to all other ferros at the current ferro 
            [loc_list_out,angle_list_out,magnet_dim_list_out,Br_list_out] = Br3D2Cuboid(ferro_loc_temp,orient_angle_temp,geo_param_temp,Br_3D_prev_temp);
            Ferro_MT = MagTetris();
            Ferro_MT = Ferro_MT.AssignCuboid(loc_list_out,angle_list_out,Br_list_out,magnet_dim_list_out);
            [Bx_PMA,By_PMA,Bz_PMA] = Ferro_MT.Field2DFree(FOV_x(i,:),FOV_y(i,:),FOV_z(i,:));
            B0_coupling = [Bx_PMA,By_PMA,Bz_PMA];
            B0_coupling_rot = RotationUtils.rotate3D(B0_coupling,-orient_angle(1,:),2);
  
            %factor to damp the coupling effect to help with convergence
            %and prevent explosion of magnetization
            coupling_damping_factor = 1 + damping_factor_offset;
            %disp(["coupling_damp", coupling_damping_factor]);
            H_coupling_effect = (B0_coupling_rot/mu_0) /coupling_damping_factor;

            curr_H_in_3D = H_in_3D(i,:);
            H_in_3D(i,:) = curr_H_in_3D + H_coupling_effect;
        end
    end
    %------end of domains coupling----------
    %{
    %}
    
    B_in_abs = sqrt(sum(H_in_3D.^2,2))*mu_0; 
    [suscept] = HysteresisInitialIron(B_in_abs); 

    % first pass
    if geometry.rod == 1
        Br_3D_rot = suscept./(1+n_3D.*suscept).*(H_in_3D*mu_0);
    elseif (geometry.cube == 1) || (geometry.plate == 1) 
        B_out = zeros(size(H_in_3D));
        parfor i = 1:num_ferro
            Ni  = N_tensor(:,:,i);
            chi = suscept(i);
            A   = (eye(3) + chi*Ni);
            B_out(i,:) = (chi * (A \ (H_in_3D(i,:).')) * mu_0).';
        end
        Br_3D_rot = B_out;
    end
    
    
    % anisotropy approximation
    if geometry.plate == 0
        % Code to calculate angle factor, which is a quick approximation for
        % anisotropy energy
        % 1) Compute the dot product of each row.
        dotp   = sum(Br_3D_rot .* B0_3D_rot, 2);          % [N x 1]
        % 2) Compute norms of each vector:
        normBr = sqrt(sum(Br_3D_rot   .^2, 2));        % [N x 1]
        normB0 = sqrt(sum(B0_3D_rot   .^2, 2));        % [N x 1]
        % 3) Compute cos(theta) and sin(theta) for each domain.
        cosang = dotp ./ (normBr .* normB0);        % [N x 1]
        sinang = sqrt(max(0, 1 - cosang.^2));       % [N x 1]
        % 4) Apply the sine-based angle factor to all three components.
        angle_factor = sinang;
        % factor in anistrophy energy in the form of an angle_factor
        % approximation
        angle_factor = repmat(angle_factor,1,3);
        Br_3D_rot = Br_3D_rot + (angle_factor.*Br_3D_rot);
    end

    Br_3D = Br_3D_rot;

    % Account for saturation
    M_sat = 2.15;
    Br_3D_sat = sqrt(sum(Br_3D   .^2, 2));
    satMask = Br_3D_sat > M_sat;
    scale = ones(size(Br_3D));
    scale(satMask,1) = M_sat ./ Br_3D_sat(satMask);
    scale(satMask,2) = M_sat ./ Br_3D_sat(satMask);
    scale(satMask,3) = M_sat ./ Br_3D_sat(satMask);
    Br_3D_new = Br_3D .* scale;
    Br_3D = Br_3D_new;
    %{
    
    %}

    
    Br_diff = abs((Br_3D-B0_3D));
    Br_diff = mean(Br_diff,'all');
    Br_convergence = abs((Br_diff_prev-Br_diff)./Br_diff)*100;
    
    
    if  (Br_convergence - Br_convergence_prev) > 1
        %oscillation detected
        %restart calculation with larger damping factor
        damping_factor_offset = damping_factor_offset + damping_step;
        counter = 0;
        Br_diff_prev = 0;
        Br_convergence_prev = 100;

        if verbose
            disp(['Br_convergence: ',num2str(Br_convergence)]);
            disp("Oscillation detected!");
            disp("Restart calculation with larger damping factor");
            disp(["Damping factor: ", num2str(1+damping_factor_offset)]);
            disp("=====================");
        end
        continue;
    end
    
    %{
    
    
    %}

    
    % If the change in Br is adequately small, stop the iteration
    % or if max iteration (counter) is reached
    if num_ferro == 1  ...
       ||Br_diff==0 ...
       ||Br_convergence < convergence_tolerance ...
       ||counter == max_iterations ...
       ||(geometry.plate == 1 && geometry.magnetization_along_hard_axis == 1)

        convergence_flag = 1;
    end
    counter = counter + 1;
    Br_3D_prev = Br_3D;
    Br_diff_prev = Br_diff;
    Br_convergence_prev = Br_convergence;
    
    
    if verbose
        disp(['Counter: ',num2str(counter)]);
        disp(['Br_diff: ',num2str(Br_diff)]);
        disp(['Br_convergence: ',num2str(Br_convergence)]);
        disp("-------------")
    end

    
    
    %{
    %}
    
end


end

function [suscept] = HysteresisInitialIron(B_in)
% Compute iron susceptibility from the initial B-to-B hysteresis curve.
% Input:
%   B_in - External field magnitude for each domain [T].
% Output:
%   suscept - Susceptibility value for each input field magnitude.
mu_0 = 1.25663753e-6;
bx = 318300*mu_0;              % Ampere/meter * miu = telsa
by = 2.15;              % Tesla
theta_raw = 1;        % Degree
theta = atand(mu_0*tand(theta_raw));
n = 13;


% Loop through the hysteresis curve to find the correct alpha
% alpha in [0,2*pi)
num_alpha = 1000;
alpha_list = linspace(0,360,num_alpha);        % [degree]
%alpha is a parameter along the hysteresis curve to decide the values of
%both x and y
err_min = 1000*ones(length(B_in),1);
alpha_err_min = zeros(length(B_in),1);
for idx_alpha=1:num_alpha
    alpha_curr = alpha_list(idx_alpha);
    % compute x(alpha) value
    x_alpha = bx*cosd(alpha_curr)^n*cosd(theta) + by*cosd(alpha_curr)*sind(theta);
    %no need for asin(alpha)^m as we are only dealing with initial curve,
    %not the saturation curve
    err_curr = abs((x_alpha - B_in)./B_in)*100;
    %find the difference between B_in, the current magnetic field provided
    %by the manget, and x_alpha, the magnetic field when the parameter
    %alpha is at the current value. The smallest the difference, it means
    %the more accurate alpha is and thus it can be used to compute y_alpha
    err_curr(B_in == 0) = abs(x_alpha);
    idx_update = (err_curr < err_min);
    alpha_err_min(idx_update) = alpha_curr;
    err_min(idx_update) = err_curr(idx_update);
end

% Compute the corresponding y(alpha) value
B_out = -bx*cosd(alpha_err_min).^n*sind(theta) + by*cosd(alpha_err_min).*cosd(theta);
%B_out is the B-field from the magnetized ferromagnetic material

% Compute the susceptibility
suscept = B_out./B_in - 1;
end
