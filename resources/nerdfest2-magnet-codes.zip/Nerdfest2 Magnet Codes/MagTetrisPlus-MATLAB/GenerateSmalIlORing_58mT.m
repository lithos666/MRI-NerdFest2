clear;
% clc;
close all;
tic;

%% Generate and evaluate the 32 mT small IOring reference geometry

FOV_half = 10;

FOV_half_1 = FOV_half;
FOV_1 = -FOV_half_1:1:FOV_half_1;
FOV_half_2 = FOV_half;
FOV_2 = -FOV_half_2:1:FOV_half_2;
FOV_3 = 0;
slice_offsets_mm = [-2, -1, 0, 1, 2];
surface = 'z';
n_per_group = 1;
font_size = 18;
n_bar = 14;


% The same row number across these four arrays describes one seed magnet.
%   quadrant_loc   : [R, Z] in mm
%   quadrant_dim   : local [dim_x, dim_y, dim_z] in mm
%   quadrant_angle : magnetization angle in the R-Z plane, in degrees
%   quadrant_Br    : remanence in T
%
% GenerateIORingPairFromQuadrant creates each complete upper ring and its
% IOring-symmetric lower ring automatically.

% Seed center coordinates: radial position R and axial position Z [mm].
quadrant_loc = [ ...
    100, 169; ...
     90, 169; ...
     80, 169; ...
     70, 169; ...
     60, 169; ...
    100, 143; ...
     90, 143; ...
     80, 143; ...
     70, 143; ...
     60, 143; ...
    100, 117; ...
     90, 117; ...
     80, 117; ...
     70, 117; ...
     60, 117; ...
    100,  91; ...
     90,  91; ...
     80,  91; ...
     70,  91; ...
     60,  91; ...
     92,  65; ...
     82,  65; ...
     63,  65; ...
     94,  39; ...
     77,  39; ...
     60,  39; ...
     99,  13; ...
     89,  13; ...
     79,  13; ...
     60,  13];

quadrant_angle = [ ...
    180 * ones(24, 1); ...
      0; ...
    270; ...
    180 * ones(3, 1); ...
    270];

quadrant_dim = repmat([10, 10, 10], size(quadrant_loc, 1), 1);
quadrant_Br = 1.43 * ones(size(quadrant_loc, 1), 1);

[loc_all_list, angle_all, magnet_dim_all, Br_all] = ...
    GenerateIORingPairFromQuadrant( ...
    n_bar, quadrant_loc, quadrant_dim, quadrant_angle, quadrant_Br);

% Basic geometry checks
n_expected = n_bar * sum(1 + (quadrant_loc(:, 2) > 1e-9));
assert(size(loc_all_list, 1) == n_expected, ...
    'Expected %d magnets, but generated %d.', n_expected, size(loc_all_list, 1));
assert(isequal(size(angle_all), [n_expected, 3]), 'Unexpected angle_all size.');
assert(isequal(size(magnet_dim_all), [n_expected, 3]), ...
    'Unexpected magnet_dim_all size.');
assert(isequal(size(Br_all), [1, n_expected]), 'Unexpected Br_all size.');

generated_radius = hypot(loc_all_list(:, 1), loc_all_list(:, 2));
for layer_index = 1:size(quadrant_loc, 1)
    layer_radius = quadrant_loc(layer_index, 1);
    layer_z = quadrant_loc(layer_index, 2);
    layer_mask = abs(generated_radius - layer_radius) < 1e-9;

    assert(sum(layer_mask & abs(loc_all_list(:, 3) - layer_z) < 1e-9) == n_bar, ...
        'Upper ring %d does not contain n_bar magnets.', layer_index);
    if layer_z > 1e-9
        assert(sum(layer_mask & abs(loc_all_list(:, 3) + layer_z) < 1e-9) == n_bar, ...
            'Lower ring %d does not contain n_bar magnets.', layer_index);
    end
end
assert(all(Br_all >= 0), 'Generated remanence values must be nonnegative.');

fprintf('Geometry checks passed.\n');
fprintf('Quadrant seed magnets       : %d\n', size(quadrant_loc, 1));
fprintf('Total generated magnets     : %d\n', size(loc_all_list, 1));

% Create the MagTetris object and calculate five planes around the center.
% Homogeneity uses every finite sample in the full masked 3-D Bz stack;
% the corresponding-pixel average is retained for plotting.
IOring_MT = MagTetris().AssignCuboid( ...
    loc_all_list, angle_all, Br_all, magnet_dim_all);
%{
% Shimming applications
orient_angle_raw = [0,0,0;0,0,0];
geo_param_raw = [10,10,10;5,5,1];
ferro_loc_raw = [0,0,6;0,10,6;];
Ferro_MT = MagTetrisPlus(IOring_MT, ferro_loc_raw, orient_angle_raw, geo_param_raw, false);
IOring_MT = IOring_MT.ConcatMT(Ferro_MT);
%}
[Bx, By, Bz, Bx_slices, By_slices, Bz_slices] = averaged_field2d( ...
    IOring_MT, FOV_1, FOV_2, slice_offsets_mm, n_per_group);

% Keep only the circular FoV.
[FOV_x, FOV_y] = meshgrid(FOV_1, FOV_2);
outside_FOV = hypot(FOV_x, FOV_y) > FOV_half_1;
Bx(outside_FOV) = NaN;
By(outside_FOV) = NaN;
Bz(outside_FOV) = NaN;

Bx = Bx * 1e3;
By = By * 1e3;
Bz = Bz * 1e3;
Bx_slices = mask_and_scale_field_stack(Bx_slices, outside_FOV, 1e3);
By_slices = mask_and_scale_field_stack(By_slices, outside_FOV, 1e3);
Bz_slices = mask_and_scale_field_stack(Bz_slices, outside_FOV, 1e3);

metrics = calc_B0_homogeneity(Bz_slices);
fprintf('3-D stack slice Z values    : %s mm\n', mat2str(slice_offsets_mm));
fprintf('Mean Bz                     : %.6f mT\n', metrics.Bmean);
fprintf('Max Bz                     : %.6f mT\n', metrics.Bmax);
fprintf('Min Bz                     : %.6f mT\n', metrics.Bmin);
fprintf('Peak-to-peak homogeneity    : %.6f ppm\n', metrics.hom_ppm_pp);
fprintf('Standard-deviation homogeneity: %.6f ppm\n\n', metrics.hom_ppm_std);

% Apply a display-only 0.1 mT deadband. The calculated Bz values and
% homogeneity metrics above remain unchanged.
Bz_plot = Bz;
Bz_plot(abs(Bz_plot) < 0.1) = 0;

% Plot the five-slice averaged field.
figure(2);
%figure('Color', 'w', 'Name', 'Quadrant-generated IOring Bz');
pcolor(FOV_1, FOV_2, Bz_plot);
axis equal tight;
shading flat;
cb = colorbar;
set(get(cb, 'Title'), 'String', 'mT');
colormap jet;
set(gca, 'FontSize', font_size);
xlabel('x / mm');
ylabel('y / mm');
title(sprintf('Average Bz map', ...
    metrics.hom_ppm_pp, metrics.Bmean));

% Display the complete generated magnet array and the averaged field map.
DrawMagnetization(IOring_MT.cub_loc, IOring_MT.cub_angle, ...
    IOring_MT.cub_dim, "red", FOV_1, FOV_2, FOV_3, surface, Bz_plot);
% Display Shims
% DrawMagnetization(Ferro_MT.cub_loc, Ferro_MT.cub_angle, ...
%     Ferro_MT.cub_dim, [0.8 0.8 0.8], FOV_1, FOV_2, FOV_3, surface, Bz);

toc;

function [Bx_average, By_average, Bz_average, ...
        Bx_slices, By_slices, Bz_slices] = averaged_field2d( ...
        mt, axis_1, axis_2, slice_offsets_mm, n_per_group)
% Calculate each parallel Z plane, then average corresponding x-y pixels.
% Units are unchanged from MagTetris.Field2D (tesla).
    n_slice = numel(slice_offsets_mm);
    assert(n_slice > 0, 'slice_offsets_mm cannot be empty.');
    [Bx_slice, By_slice, Bz_slice] = mt.Field2D( ...
        axis_1, axis_2, slice_offsets_mm(1), 'z', n_per_group);
    stack_size = [size(Bz_slice), n_slice];
    Bx_slices = zeros(stack_size);
    By_slices = zeros(stack_size);
    Bz_slices = zeros(stack_size);
    Bx_slices(:, :, 1) = Bx_slice;
    By_slices(:, :, 1) = By_slice;
    Bz_slices(:, :, 1) = Bz_slice;
    for slice_index = 2:n_slice
        [Bx_slices(:, :, slice_index), ...
            By_slices(:, :, slice_index), ...
            Bz_slices(:, :, slice_index)] = mt.Field2D( ...
            axis_1, axis_2, slice_offsets_mm(slice_index), 'z', ...
            n_per_group);
    end
    Bx_average = mean(Bx_slices, 3);
    By_average = mean(By_slices, 3);
    Bz_average = mean(Bz_slices, 3);
end


function scaled_stack = mask_and_scale_field_stack( ...
        field_stack, outside_mask, scale_factor)
    scaled_stack = scale_factor * field_stack;
    for slice_index = 1:size(scaled_stack, 3)
        slice = scaled_stack(:, :, slice_index);
        slice(outside_mask) = NaN;
        scaled_stack(:, :, slice_index) = slice;
    end
end


function metrics = calc_B0_homogeneity(Bmap, B0_ref)
    B = Bmap(isfinite(Bmap));
    if isempty(B)
        error('Bmap contains no valid finite values.');
    end

    if nargin < 2 || isempty(B0_ref)
        B0_ref = mean(B);
    end
    if B0_ref == 0
        error('B0_ref cannot be zero.');
    end

    metrics = struct();
    metrics.B0_ref = B0_ref;
    metrics.Bmax = max(B);
    metrics.Bmin = min(B);
    metrics.Bmean = mean(B);
    metrics.Bstd = std(B);
    metrics.deltaB_pp = metrics.Bmax - metrics.Bmin;
    metrics.hom_ppm_pp = metrics.deltaB_pp / abs(B0_ref) * 1e6;
    metrics.hom_ppm_std = metrics.Bstd / abs(B0_ref) * 1e6;
end
