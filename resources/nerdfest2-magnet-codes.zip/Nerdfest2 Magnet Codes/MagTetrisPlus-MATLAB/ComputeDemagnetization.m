function varargout = ComputeDemagnetization(mode, varargin)
% Compute cuboid demagnetization factors or local demagnetization tensors.
% Input:
%   mode - Calculation mode, either 'factors' or 'tensor'.
%   varargin - Mode-specific inputs.
% Output:
%   varargout - Demagnetization factors or a 3-by-3-by-N tensor array.
%
% Usage:
%   [nx, ny, nz] = ComputeDemagnetization('factors', geo_param)
%   n_3D = ComputeDemagnetization('factors', geo_param)
%   N_tensor = ComputeDemagnetization('tensor', geo_param, ferro_loc, orient_angle, mutual_term)

mode = lower(char(mode));

switch mode
    case {'factor', 'factors'}
        geo_param = varargin{1};
        [n_x, n_y, n_z] = projectionFactors(geo_param);

        if nargout <= 1
            varargout{1} = [n_x, n_y, n_z];
        else
            varargout{1} = n_x;
            varargout{2} = n_y;
            varargout{3} = n_z;
        end

    case {'tensor', 'tensors'}
        geo_param = varargin{1};
        ferro_loc = varargin{2};
        orient_angle = varargin{3};
        mutual_term = varargin{4};
        varargout{1} = localTensor(geo_param, ferro_loc, orient_angle, mutual_term);

    otherwise
        error('ComputeDemagnetization:InvalidMode', ...
            'mode must be ''factors'' or ''tensor''.');
end

end

function [n_x, n_y, n_z] = projectionFactors(geo_param)
% Compute demagnetization factors for cuboids.
% Input:
%   geo_param - Cuboid dimensions [Lx, Ly, Lz] in millimeters.
% Output:
%   n_x - Projection demagnetization factor along x.
%   n_y - Projection demagnetization factor along y.
%   n_z - Projection demagnetization factor along z.

len_x = geo_param(:,1);
len_y = geo_param(:,2);
len_z = geo_param(:,3);

S_z = len_x .* len_y;
S_y = len_x .* len_z;
S_x = len_y .* len_z;
S_total = S_x + S_y + S_z;

n_x = S_x ./ S_total;
n_y = S_y ./ S_total;
n_z = S_z ./ S_total;
end

function N_tensor = localTensor(geo_param, ferro_loc, orient_angle, mutual_term)
% Compute an effective local demagnetization tensor for each domain.
% Input:
%   geo_param - Domain dimensions [mm].
%   ferro_loc - Domain center locations [mm].
%   orient_angle - Domain yaw, pitch, and roll angles [degree].
%   mutual_term - True to include mutual-domain tensor terms.
% Output:
%   N_tensor - Local demagnetization tensor with size 3-by-3-by-N.

domains2 = horzcat(geo_param, ferro_loc);

for i = 1:size(domains2, 1)
    domains(i).Lx = domains2(i, 1); 
    domains(i).Ly = domains2(i, 2); 
    domains(i).Lz = domains2(i, 3); 
    domains(i).x = domains2(i, 4); 
    domains(i).y = domains2(i, 5); 
    domains(i).z = domains2(i, 6); 
end

N = numel(domains);

if isempty(orient_angle)
    orient_angle = zeros(N, 3);
end

rotationMatrix = RotationUtils.matrixFromAngles(orient_angle(1,:), 2);

centers = zeros(N, 3);
volumes = zeros(N, 1);
for k = 1:N
    Lx = domains(k).Lx;
    Ly = domains(k).Ly;
    Lz = domains(k).Lz;
    centers(k,:) = [domains(k).x, domains(k).y, domains(k).z];
    volumes(k) = Lx * Ly * Lz;
end

N_tensor = zeros(3, 3, N);
for i = 1:N
    Ni = zeros(3, 3);
    ri = centers(i,:).';

    for j = 1:N
        N_ij = zeros(3, 3);
        rj = centers(j,:).';

        if i == j
            Lx = domains(i).Lx;
            Ly = domains(i).Ly;
            Lz = domains(i).Lz;
            [Nx_self, Ny_self, Nz_self] = projectionFactors([Lx, Ly, Lz]);
            N_ij = diag([Nx_self, Ny_self, Nz_self]);
        elseif mutual_term
            r = ri - rj;
            R2 = dot(r, r);
            R = sqrt(R2);
            R5 = R2 * R2 * R;
            rrT = r * r.';
            Vj = volumes(j);
            T = 3 * rrT / R5 - eye(3) / (R^3);
            N_ij = - (Vj / (4 * pi)) * T;
        end

        N_ij = rotationMatrix * N_ij;
        Ni = Ni + N_ij;
    end

    N_tensor(:,:,i) = Ni;
end
end
