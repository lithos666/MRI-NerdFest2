clear;
% clc;
%close all;
tic;

%% Simple IOring permanent-magnet shimming practice

% The field is evaluated across five 1 mm-spaced slices from Z = -2 mm to
% Z = +2 mm. This follows the five-slice convention used by the original
% 37 mT IOring script.
FOV_half = 25;
FOV_1 = -FOV_half:1:FOV_half;
FOV_2 = -FOV_half:1:FOV_half;
FOV_3 = 0;
slice_offsets_mm = [-2, -1, 0, 1, 2];
surface = 'z';
n_per_group = 1;
font_size = 14;
n_bar = 10;
target_homogeneity_ppm = 1000;
main_z_spacing_mm = 38;

bar_pitch_deg = 360 / n_bar;
array_rotation_deg = bar_pitch_deg / 2;

%% Main array with 12mm magnets

% Each row is [radial position R, positive axial position Z] in mm.
quadrant_main_loc = [];
quadrant_main_angle = [];

main_dim = [12, 12, 12];
main_Br = 1.43;

%% Shim array with 10mm magnets

% Each row is [radial position R, positive axial position Z] in mm.
quadrant_shim_loc = [];
quadrant_shim_angle = [];

shim_dim = [10, 10, 10];
shim_Br = 1.43;

%% Check the design constraints

% During the staged exercise, an empty location or angle array means that
% magnet group has not yet been entered, so its constraint checks are skipped.
main_parameters_empty = isempty(quadrant_main_loc) || isempty(quadrant_main_angle);
shim_parameters_empty = isempty(quadrant_shim_loc) || isempty(quadrant_shim_angle);

main_z_positions = [];
main_radius_min = NaN;
main_radius_max = NaN;

if ~main_parameters_empty
    main_z_positions = sort(unique(quadrant_main_loc(:, 2)));
    n_main_z_positions = sum(1 + (main_z_positions > 1e-9));
    main_radius_min = min(quadrant_main_loc(:, 1));
    main_radius_max = max(quadrant_main_loc(:, 1));

    assert(all(abs(diff(main_z_positions) - main_z_spacing_mm) < 1e-9), ...
        'Adjacent positive-Z main-magnet planes must be 38 mm apart.');
    assert(abs(2 * main_z_positions(1) - main_z_spacing_mm) < 1e-9, ...
        ['The two main-magnet planes nearest Z = 0 must also be ', ...
         '38 mm apart.']);
    assert(n_main_z_positions <= 10, ...
        'The complete array may use at most 10 main-magnet Z positions.');
    assert(all(quadrant_main_loc(:, 1) > FOV_half), ...
        'Every main-magnet radius must be larger than FOV_half.');
    assert(all(ismember(mod(quadrant_main_angle, 360), [0, 180])), ...
        'Main-magnet angles are restricted to 0 or 180 degrees.');
    assert(numel(unique(mod(quadrant_main_angle, 360))) == 1, ...
        'All main magnets on the positive-Z side must face the same direction.');
    assert_main_radial_spacing(quadrant_main_loc, quadrant_main_angle, main_dim(2));
end

if ~shim_parameters_empty
    assert(all(quadrant_shim_loc(:, 1) > FOV_half), ...
        'Every shim radius must be larger than FOV_half.');
    assert(all(ismember(mod(quadrant_shim_angle, 360), [0, 90, 180, 270])), ...
        'Shim angles must be 0, 90, 180, or 270 degrees.');

    if ~main_parameters_empty
        all_nonnegative_z_positions = unique( ...
            [quadrant_main_loc(:, 2); quadrant_shim_loc(:, 2)]);
        assert(numel(all_nonnegative_z_positions) <= 10, ...
            'The nonnegative-Z design may use at most 10 unique Z positions.');
        assert(all(quadrant_shim_loc(:, 1) >= main_radius_min & ...
                   quadrant_shim_loc(:, 1) <= main_radius_max), ...
            'Shim radii must remain inside the radial range of the main magnets.');
        assert_shim_midplane_placement( ...
            quadrant_shim_loc, main_z_positions, main_dim(3), shim_dim(2:3));
    end
end

%% Generate and separate the main and shim arrays

% Treat a magnet group as absent when either member of its location-angle
% pair is empty. This lets students run the main-only or shim-only stages.
if main_parameters_empty
    active_main_loc = zeros(0, 2);
    active_main_angle = zeros(0, 1);
else
    active_main_loc = quadrant_main_loc;
    active_main_angle = quadrant_main_angle;
end

if shim_parameters_empty
    active_quadrant_shim_loc = zeros(0, 2);
    active_quadrant_shim_angle = zeros(0, 1);
else
    active_quadrant_shim_loc = quadrant_shim_loc;
    active_quadrant_shim_angle = quadrant_shim_angle;
end

if main_parameters_empty && shim_parameters_empty
    warning(['No complete main- or shim-magnet parameter pair was ', ...
             'supplied. Field calculation was skipped.']);
    return;
end

all_quadrant_main_loc = [active_main_loc; active_quadrant_shim_loc];
all_quadrant_main_angle = [active_main_angle; active_quadrant_shim_angle];
all_quadrant_dim = [ ...
    repmat(main_dim, size(active_main_loc, 1), 1); ...
    repmat(shim_dim, size(active_quadrant_shim_loc, 1), 1)];
all_quadrant_Br = [ ...
    main_Br * ones(size(active_main_loc, 1), 1); ...
    shim_Br * ones(size(active_quadrant_shim_loc, 1), 1)];

[loc_all, angle_all, dim_all, Br_all] = ...
    GenerateIORingPairFromQuadrant( ...
    n_bar, all_quadrant_main_loc, all_quadrant_dim, ...
    all_quadrant_main_angle, all_quadrant_Br);

% Apply the same half-bar-pitch rigid rotation as the original 37 mT array.
rotation_xy = [cosd(array_rotation_deg), -sind(array_rotation_deg); ...
               sind(array_rotation_deg),  cosd(array_rotation_deg)];
loc_all(:, 1:2) = loc_all(:, 1:2) * rotation_xy.';
angle_all(:, 1) = mod(angle_all(:, 1) + array_rotation_deg, 360);

n_main = n_bar * sum(1 + (active_main_loc(:, 2) > 1e-9));
main_indices = 1:n_main;
shim_indices = (n_main + 1):size(loc_all, 1);

Main_MT = MagTetris().AssignCuboid( ...
    loc_all(main_indices, :), angle_all(main_indices, :), ...
    Br_all(main_indices), dim_all(main_indices, :));
Shim_MT = MagTetris().AssignCuboid( ...
    loc_all(shim_indices, :), angle_all(shim_indices, :), ...
    Br_all(shim_indices), dim_all(shim_indices, :));

fprintf('Main magnets                : %d\n', Main_MT.cub_numMag);
fprintf('Shim magnets                : %d\n', Shim_MT.cub_numMag);
fprintf('Main radial range           : %.1f to %.1f mm\n', ...
    main_radius_min, main_radius_max);
fprintf('Shim seed rings\n');
for shim_index = 1:size(active_quadrant_shim_loc, 1)
    fprintf('  R = %.1f mm, Z = +/-%.1f mm, angle = %.0f degrees\n', ...
        active_quadrant_shim_loc(shim_index, 1), active_quadrant_shim_loc(shim_index, 2), ...
        active_quadrant_shim_angle(shim_index));
end
fprintf('\n');

%% Calculate the unshimmed and shimmed Bz fields

[Bz_main, Bz_main_slices] = averaged_bz( ...
    Main_MT, FOV_1, FOV_2, slice_offsets_mm, n_per_group);
[Bz_shim, Bz_shim_slices] = averaged_bz( ...
    Shim_MT, FOV_1, FOV_2, slice_offsets_mm, n_per_group);

Bz_total = Bz_main + Bz_shim;
Bz_total_slices = Bz_main_slices + Bz_shim_slices;

% Keep only the circular field of view and convert tesla to millitesla.
[FOV_x, FOV_y] = meshgrid(FOV_1, FOV_2);
outside_FOV = hypot(FOV_x, FOV_y) > FOV_half;

Bz_main_mT = 1e3 * Bz_main;
Bz_shim_mT = 1e3 * Bz_shim;
Bz_total_mT = 1e3 * Bz_total;
Bz_main_mT(outside_FOV) = NaN;
Bz_shim_mT(outside_FOV) = NaN;
Bz_total_mT(outside_FOV) = NaN;

Bz_main_slices_mT = mask_and_scale_field_stack( ...
    Bz_main_slices, outside_FOV, 1e3);
Bz_shim_slices_mT = mask_and_scale_field_stack( ...
    Bz_shim_slices, outside_FOV, 1e3);
Bz_total_slices_mT = mask_and_scale_field_stack( ...
    Bz_total_slices, outside_FOV, 1e3);

metrics_before = calc_B0_homogeneity(Bz_main_slices_mT);
metrics_shim = calc_B0_homogeneity(Bz_shim_slices_mT);
metrics_after = calc_B0_homogeneity(Bz_total_slices_mT);
improvement_percent = 100 * ...
    (1 - metrics_after.hom_ppm_pp / metrics_before.hom_ppm_pp);

if ~main_parameters_empty
    assert(metrics_before.Bmin > 0, ...
        'Main-array Bz must point in the positive Z direction throughout the sampled FOV.');
end

if ~main_parameters_empty && ~shim_parameters_empty
    assert(metrics_after.hom_ppm_pp < metrics_before.hom_ppm_pp, ...
        'The selected shim layout did not improve peak-to-peak homogeneity.');
    assert(metrics_after.hom_ppm_pp < target_homogeneity_ppm, ...
        'The final shimmed field must remain below the 1000 ppm target.');
    assert(metrics_after.Bmin > 0, ...
        'Final Bz must point in the positive Z direction throughout the sampled FOV.');
end

fprintf('Before shimming\n');
print_metrics(metrics_before);
fprintf('\nShim-only field\n');
print_metrics(metrics_shim);
fprintf('\nAfter shimming\n');
print_metrics(metrics_after);
fprintf('\nPeak-to-peak improvement    : %.2f %%\n\n', improvement_percent);

% Display-only copies suppress field magnitudes below 0.1 mT. All metrics
% continue to use the original unmodified field arrays above.
Bz_main_plot_mT = Bz_main_mT;
Bz_shim_plot_mT = Bz_shim_mT;
Bz_total_plot_mT = Bz_total_mT;
Bz_main_plot_mT(abs(Bz_main_plot_mT) < 0.1) = 0;
Bz_shim_plot_mT(abs(Bz_shim_plot_mT) < 0.1) = 0;
Bz_total_plot_mT(abs(Bz_total_plot_mT) < 0.1) = 0;

%% Plot the main, shim-only, and final Bz fields

figure(2);
clf reset;
tiledlayout(1, 3, 'TileSpacing', 'compact', 'Padding', 'compact');

nexttile;
pcolor(FOV_1, FOV_2, Bz_main_plot_mT);
axis equal tight;
shading flat;
cb = colorbar;
set(get(cb, 'Title'), 'String', 'mT');
colormap jet;
set(gca, 'FontSize', font_size);
xlabel('x / mm');
ylabel('y / mm');
title(field_statistics_title('Main magnets', metrics_before));

nexttile;
pcolor(FOV_1, FOV_2, Bz_shim_plot_mT);
axis equal tight;
shading flat;
cb = colorbar;
set(get(cb, 'Title'), 'String', 'mT');
colormap jet;
set(gca, 'FontSize', font_size);
xlabel('x / mm');
ylabel('y / mm');
title(field_statistics_title('Shim magnets only', metrics_shim));

nexttile;
pcolor(FOV_1, FOV_2, Bz_total_plot_mT);
axis equal tight;
shading flat;
cb = colorbar;
set(get(cb, 'Title'), 'String', 'mT');
colormap jet;
set(gca, 'FontSize', font_size);
xlabel('x / mm');
ylabel('y / mm');
title(field_statistics_title('Final sum', metrics_after));

%% Display the main and shim magnets

figure(100);
clf reset;
DrawMagnetization(Main_MT.cub_loc, Main_MT.cub_angle, ...
    Main_MT.cub_dim, [0.85, 0.15, 0.15], ...
    FOV_1, FOV_2, FOV_3, surface, Bz_total_plot_mT);
DrawMagnetization(Shim_MT.cub_loc, Shim_MT.cub_angle, ...
    Shim_MT.cub_dim, [0.15, 0.35, 0.90], ...
    FOV_1, FOV_2, FOV_3, surface, Bz_total_plot_mT);
title('Main magnets (red) and shim magnets (blue)');

toc;


function [Bz_average, Bz_slices] = averaged_bz( ...
        mt, axis_1, axis_2, slice_offsets_mm, n_per_group)
% Calculate parallel Z planes and average corresponding x-y pixels.
    n_slice = numel(slice_offsets_mm);
    assert(n_slice > 0, 'slice_offsets_mm cannot be empty.');

    [~, ~, Bz_slice] = mt.Field2D( ...
        axis_1, axis_2, slice_offsets_mm(1), 'z', n_per_group);
    Bz_slices = zeros([size(Bz_slice), n_slice]);
    Bz_slices(:, :, 1) = Bz_slice;

    for slice_index = 2:n_slice
        [~, ~, Bz_slices(:, :, slice_index)] = mt.Field2D( ...
            axis_1, axis_2, slice_offsets_mm(slice_index), ...
            'z', n_per_group);
    end

    Bz_average = mean(Bz_slices, 3);
end


function scaled_stack = mask_and_scale_field_stack( ...
        field_stack, outside_mask, scale_factor)
    scaled_stack = scale_factor * field_stack;
    for slice_index = 1:size(scaled_stack, 3)
        slice = scaled_stack(:, :, slice_index);
        slice(outside_mask) = NaN;
        scaled_stack(:, :, slice_index) = slice;
    end
end


function metrics = calc_B0_homogeneity(Bmap)
    B = Bmap(isfinite(Bmap));
    if isempty(B)
        error('Bmap contains no valid finite values.');
    end

    metrics = struct();
    metrics.Bmax = max(B);
    metrics.Bmin = min(B);
    metrics.Bmean = mean(B);
    metrics.Bstd = std(B);
    metrics.deltaB_pp = metrics.Bmax - metrics.Bmin;
    metrics.hom_ppm_pp = metrics.deltaB_pp / abs(metrics.Bmean) * 1e6;
    metrics.hom_ppm_std = metrics.Bstd / abs(metrics.Bmean) * 1e6;
end


function print_metrics(metrics)
    fprintf('Mean Bz                     : %.6f mT\n', metrics.Bmean);
    fprintf('Maximum Bz                  : %.6f mT\n', metrics.Bmax);
    fprintf('Minimum Bz                  : %.6f mT\n', metrics.Bmin);
    fprintf('Peak-to-peak homogeneity    : %.6f ppm\n', metrics.hom_ppm_pp);
    fprintf('Standard-deviation homogeneity: %.6f ppm\n', ...
        metrics.hom_ppm_std);
end


function title_lines = field_statistics_title(field_name, metrics)
    title_lines = { ...
        field_name; ...
        sprintf('Mean %.4f mT', metrics.Bmean); ...
        sprintf('Min %.4f | Max %.4f mT', metrics.Bmin, metrics.Bmax); ...
        sprintf('Peak-to-peak %.1f ppm', metrics.hom_ppm_pp)};
end


function assert_main_radial_spacing(quadrant_main_loc, quadrant_main_angle, cube_size)
% Enforce touching equal-angle cubes and a 12 mm edge gap at angle changes.
    spacing_tolerance = 1e-9;
    z_positions = unique(quadrant_main_loc(:, 2));

    for z_index = 1:numel(z_positions)
        rows = find(abs(quadrant_main_loc(:, 2) - z_positions(z_index)) < ...
            spacing_tolerance);
        [sorted_radius, order] = sort(quadrant_main_loc(rows, 1));
        sorted_angle = mod(quadrant_main_angle(rows(order)), 360);

        radial_spacing = diff(sorted_radius);
        same_angle = sorted_angle(1:end-1) == sorted_angle(2:end);

        assert(all(abs(radial_spacing(same_angle) - cube_size) < ...
            spacing_tolerance), ...
            ['Main magnets with the same angle must have center spacing ', ...
             'equal to one cube width so their radial edges touch.']);
        assert(all(radial_spacing(~same_angle) >= ...
            2 * cube_size - spacing_tolerance), ...
            ['Main magnets with different angles must have at least one ', ...
             'cube width of clear radial space between their edges.']);
    end
end


function assert_shim_midplane_placement( ...
        quadrant_shim_loc, main_z_positions, main_axial_size, shim_rz_size)
% Keep one cardinally oriented shim plane at the midpoint of each used gap.
    spacing_tolerance = 1e-9;
    shim_radial_size = shim_rz_size(1);
    shim_axial_size = shim_rz_size(2);
    main_shim_clearance = (main_axial_size + shim_axial_size) / 2;
    gap_midpoints = [0; ...
        (main_z_positions(1:end-1) + main_z_positions(2:end)) / 2];
    midpoint_clearance = [main_z_positions(1); ...
        diff(main_z_positions) / 2];

    for shim_index = 1:size(quadrant_shim_loc, 1)
        shim_z = quadrant_shim_loc(shim_index, 2);
        midpoint_index = find( ...
            abs(gap_midpoints - shim_z) < spacing_tolerance, 1);
        assert(~isempty(midpoint_index), ...
            ['Every shim must be at the exact axial midpoint between ', ...
             'two adjacent main-magnet planes.']);
        assert(midpoint_clearance(midpoint_index) >= ...
                main_shim_clearance - spacing_tolerance, ...
            'A shim does not fit inside its main-magnet axial gap.');
    end

    for first_index = 1:(size(quadrant_shim_loc, 1) - 1)
        for second_index = (first_index + 1):size(quadrant_shim_loc, 1)
            radial_spacing = abs( ...
                quadrant_shim_loc(second_index, 1) - quadrant_shim_loc(first_index, 1));
            axial_spacing = abs( ...
                quadrant_shim_loc(second_index, 2) - quadrant_shim_loc(first_index, 2));
            assert(radial_spacing >= ...
                    shim_radial_size - spacing_tolerance || ...
                   axial_spacing >= ...
                    shim_axial_size - spacing_tolerance, ...
                'Shim cubes must not overlap in the R-Z quadrant.');
        end
    end
end
