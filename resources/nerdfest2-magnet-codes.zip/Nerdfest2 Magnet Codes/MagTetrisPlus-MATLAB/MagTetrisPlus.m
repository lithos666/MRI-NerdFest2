function Ferro_MT = MagTetrisPlus(PMA_MT, ferro_loc_raw, orient_angle_raw, geo_param_raw, solver_options)
% Create equivalent MagTetris magnets for ferromagnetic objects.
% Input:
%   PMA_MT - MagTetris object containing the permanent magnet array.
%   ferro_loc_raw - Original ferromagnetic object center locations [mm].
%   orient_angle_raw - Original ferromagnetic yaw, pitch, and roll angles [degree].
%   geo_param_raw - Original ferromagnetic object dimensions [mm].
%   solver_options - Optional FerroCalculation settings.
% Output:
%   Ferro_MT - MagTetris object containing equivalent ferromagnetic cuboid magnets.

if nargin < 5 || isempty(solver_options)
    solver_options = struct();
end

num_ferro_raw = size(geo_param_raw, 1);

Br_3D_parts = cell(num_ferro_raw, 1);
ferro_loc_parts = cell(num_ferro_raw, 1);
orient_angle_parts = cell(num_ferro_raw, 1);
geo_param_parts = cell(num_ferro_raw, 1);

for idx_ferro = 1:num_ferro_raw
    curr_ferro_loc_raw = ferro_loc_raw(idx_ferro, :);
    curr_orient_angle_raw = orient_angle_raw(idx_ferro, :);
    curr_geo_param_raw = geo_param_raw(idx_ferro, :);

    [geometry, ~, curr_ferro_loc, curr_orient_angle, curr_geo_param] = ...
        PrepareFerromagneticDomains(PMA_MT, curr_ferro_loc_raw, curr_orient_angle_raw, curr_geo_param_raw);

    FOV_x = curr_ferro_loc(:, 1);
    FOV_y = curr_ferro_loc(:, 2);
    FOV_z = curr_ferro_loc(:, 3);
    [Bx_PMA, By_PMA, Bz_PMA] = PMA_MT.Field2DFree(FOV_x, FOV_y, FOV_z);
    curr_B0_3D_all = [Bx_PMA, By_PMA, Bz_PMA];

    curr_Br_3D = FerroCalculation( ...
        curr_B0_3D_all, curr_ferro_loc, curr_geo_param, curr_orient_angle, ...
        curr_geo_param_raw, geometry, solver_options);

    Br_3D_parts{idx_ferro} = curr_Br_3D;
    ferro_loc_parts{idx_ferro} = curr_ferro_loc;
    orient_angle_parts{idx_ferro} = curr_orient_angle;
    geo_param_parts{idx_ferro} = curr_geo_param;
end

if num_ferro_raw == 0
    Br_3D = zeros(0, 3);
    ferro_loc = zeros(0, 3);
    orient_angle = zeros(0, 3);
    geo_param = zeros(0, 3);
else
    Br_3D = vertcat(Br_3D_parts{:});
    ferro_loc = vertcat(ferro_loc_parts{:});
    orient_angle = vertcat(orient_angle_parts{:});
    geo_param = vertcat(geo_param_parts{:});
end

[loc_list_out, angle_list_out, magnet_dim_list_out, Br_list_out] = ...
    Br3D2Cuboid(ferro_loc, orient_angle, geo_param, Br_3D);

Ferro_MT = MagTetris();
Ferro_MT = Ferro_MT.AssignCuboid(loc_list_out, angle_list_out, Br_list_out, magnet_dim_list_out);
end



